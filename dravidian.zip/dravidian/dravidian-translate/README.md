# Dravidian Translate

Translate between **Tamil, Telugu, Kannada, Malayalam and English** from **text, voice or an image**.
Output is shown as text and can be spoken aloud.

```
Text  ───────────────┐
Voice ─▶ ASR ────────┼─▶ (editable text) ─▶ Script detect ─▶ Translate ─▶ Text + TTS
Image ─▶ OCR ────────┘
```

Recognised speech/OCR text is always shown in an editable box *before* translating, because
ASR and OCR errors would otherwise be silently translated.

## Stack

| Layer | Choice |
|---|---|
| Translation | AI4Bharat IndicTrans2 distilled (indic-en 200M, en-indic 200M, indic-indic 320M). Dravidian↔Dravidian is direct, no English pivot |
| Speech to text | AI4Bharat IndicConformer 600M multilingual (CTC) |
| Text to speech | AI4Bharat Indic Parler-TTS |
| OCR | OpenCV preprocessing + Tesseract (tam/tel/kan/mal/eng) |
| Language ID | Unicode script ranges (each language has its own script) |
| Backend | FastAPI (`/api/translate`, `/api/asr`, `/api/ocr`, `/api/tts`) |
| Frontend | React + Vite PWA |

## Run

**Try the UI without downloading models (mock engines, fake output):**
```bash
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements-mock.txt
ENGINE_MODE=mock uvicorn app.main:app --port 8000
# new terminal
cd frontend && npm install && npm run dev      # http://localhost:5173
```

**Real engines (Docker, CPU):**
```bash
docker compose up --build        # UI at http://localhost:8080
```
First request per model downloads weights (about 1-3 GB total) into the `hf-cache` volume.
The first translation/ASR/TTS call is slow while the model loads; later calls are fast.

**Real engines without Docker:** install `tesseract-ocr` + `tesseract-ocr-{tam,tel,kan,mal,eng}` and
(optional: `ffmpeg`; `imageio-ffmpeg` in requirements bundles one), then `pip install -r requirements.txt` and run uvicorn with `ENGINE_MODE=real`.

## Evaluation (for the project report)

```bash
pip install -r backend/requirements-dev.txt && cd backend
python -m eval.eval_translation --src tam --tgt eng --src-file <tam.devtest> --ref-file <eng.devtest>
python -m eval.eval_asr --lang tam --manifest eval/data/asr_tam/manifest.tsv
python -m eval.eval_ocr --lang tam --manifest eval/data/ocr_tam/manifest.tsv
```
- **Translation:** BLEU + chrF++ on FLORES-200 devtest (line-aligned files). chrF++ is the headline
  metric for Dravidian targets because agglutination makes word-level BLEU harsh. Run all 20 directions.
- **ASR:** WER + CER on your own recordings (50-100 clips per language, several speakers, report clean vs noisy).
- **OCR:** CER on printed documents, signboards and angled phone photos, reported separately.
- Results are written as JSON to `backend/eval/results/`.

## Morphological analysis

Rule-based analyser for Tamil, Telugu, Kannada, Malayalam and English (`backend/app/morph*.py`).
Words are converted to a phoneme-level form so morpheme boundaries can fall inside a letter
(வீடு + இல் = வீட்டில்); every inflected form of every lexicon entry is generated and indexed,
so analysis is an exact lookup returning lemma, POS, segmentation and Leipzig-style tags
(PL, ACC, DAT, PRES, 1SG ...). Words outside the lexicon get a suffix-rule guess and are
returned with `confidence: "heuristic"` (shown as a **guess** badge in the UI) - never presented as certain.
English homographs (love, help, this, no) are resolved from the neighbouring words.

```bash
cd backend
PYTHONPATH=. python -m eval.eval_morph            # accuracy on the gold sets, all languages
PYTHONPATH=. python -m eval.eval_morph --lang tel -v   # list every mismatch
```
Gold data: `backend/tests/data/morph_gold_*.txt` (token | lemma | POS | morphemes:TAGS | features).
Scoring is strict token-level: lemma, POS, every morph surface, tag and feature must match.
**The 100% figure is on this gold set (478 tokens = every word the app's built-in phrase data
produces, plus common inflections). The gold was annotated by the developer assistant, not a native
linguist - have a native speaker review it before quoting the number in a report.**
To extend coverage add entries to the lexicon in the language module and a line to the gold file.

## Audio input

Recording is converted in the browser to 16 kHz mono WAV and uploaded as `speech.wav`; the server
decodes WAV in pure Python, so no ffmpeg is needed for the normal path. Other formats use
ffmpeg on PATH, then the bundled `imageio-ffmpeg`, then PyAV. If none exists the API answers
HTTP 415 with an install hint instead of an OS error such as `[WinError 2]`.
In `ENGINE_MODE=mock` the transcript is a placeholder; real speech-to-text needs `ENGINE_MODE=real`.

## What has and hasn't been tested

| Component | Status |
|---|---|
| Script-based language ID, sentence splitting | Unit-tested |
| Morphological analysis (5 languages) | 100% on the 478-token gold set; 69 pytest tests pass (gold, recompose invariants, regressions, API) |
| Audio decoding incl. missing-ffmpeg case | Unit + API tests (WAV, resampling, simulated WinError 2) |
| API routes, validation, size limits, audio decoding (ffmpeg), WAV output | Tested against **mock** engines |
| Tesseract OCR + preprocessing | Run on an **English** image only (95.8% confidence). Tamil/Telugu/Kannada/Malayalam packs were not available where it was built |
| Frontend | Production build succeeds. **Not tested in a browser**: mic recording, camera upload and audio playback need a manual check on a real device |
| IndicTrans2, IndicConformer, Indic Parler-TTS integrations | **Untested.** Written from the models' published usage; weights could not be downloaded where this was built. Expect small API fixes on first run (pinned `transformers<4.50` for remote-code compatibility) |
| Translation / ASR / OCR accuracy | **Not measured.** Run the eval scripts and report real numbers |
| Docker build | **Untested** |

## Known limitations

- Romanised input ("Tanglish") is detected as English; transliteration is not supported.
- OCR is weak on handwriting, stylised fonts and low-light photos.
- ASR does not auto-detect language; the user picks it. Dialects and background noise reduce accuracy.
- TTS uses one default voice; long text (>1000 chars) is rejected for speech.
- No auth or rate limiting; add both before any public deployment.
- Mixed-language sentences are translated as one source language.

## Layout
```
backend/app/        FastAPI app, language ID, engines (real + mock)
backend/tests/      pytest suite (mock mode)
backend/eval/       BLEU/chrF++, WER, CER scripts
frontend/src/       React PWA (text / voice / image tabs)
```
