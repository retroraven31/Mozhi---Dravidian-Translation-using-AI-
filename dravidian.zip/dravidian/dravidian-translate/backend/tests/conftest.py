import os
import sys

os.environ["ENGINE_MODE"] = "mock"  # must be set before the app imports config
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
