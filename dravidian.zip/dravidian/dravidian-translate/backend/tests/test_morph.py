"""Morphological analyser tests.

* gold-standard accuracy per language (hand-annotated, see tests/data/morph_gold_*.txt),
* structural invariants (segments recompose into the token),
* regression cases for the bugs reported against the old analyser,
* the /api/morph endpoint.
"""
import pytest
from fastapi.testclient import TestClient

from app import knowledge_dataset as kd
from app import morph, morph_script as ms
from app.main import app
from eval import eval_morph as ev

client = TestClient(app)
LANGS = ["tam", "tel", "kan", "mal", "eng"]
DRAV = ["tam", "tel", "kan", "mal"]


@pytest.mark.parametrize("lang", LANGS)
def test_gold_standard_is_100_percent(lang):
    res = ev.evaluate(lang)
    assert res["correct"] == res["tokens"], f"{lang}: {res['wrong'] if 'wrong' in res else res}"
    assert res["tokens"] >= 90


@pytest.mark.parametrize("lang", DRAV)
def test_gold_tokens_recompose(lang):
    """Concatenated morphs rebuild exactly the surface token (no characters lost or invented)."""
    for g in ev.load_gold(lang):
        phon = "".join(m for m, _ in g.morphs)
        assert ms.from_phon(phon, lang) == g.token, g.token


@pytest.mark.parametrize("lang", DRAV)
def test_every_analysis_recomposes_to_its_token(lang):
    for form, readings in morph._index(lang).items():
        for a in readings:
            assert "".join(m for m, _ in a.morphs) == form, (lang, a.lemma)


@pytest.mark.parametrize("lang", DRAV)
def test_phon_roundtrip(lang):
    for g in ev.load_gold(lang):
        assert ms.from_phon(ms.to_phon(g.token, lang), lang) == g.token


def _tok(text, lang, i=0):
    return morph.analyse(text, lang).tokens[i]


def test_tamil_old_bugs():
    t = _tok("வீட்டில்", "tam")
    assert (t["stem"], t["pos"]) == ("வீடு", "noun")
    assert [m["tag"] for m in t["morphs"]] == ["root", "LOC"]
    t = _tok("பேசுகிறேன்", "tam")
    assert t["pos"] == "verb" and t["stem"] == "பேசு"
    assert [m["tag"] for m in t["morphs"]] == ["root", "PRES", "1SG"]
    t = _tok("நான்", "tam")
    assert t["pos"] == "pronoun"


def test_english_old_bugs():
    t = _tok("houses", "eng")
    assert (t["stem"], t["pos"]) == ("house", "noun")
    assert [m["text"] for m in t["morphs"]] == ["house", "s"]
    assert _tok("the", "eng")["pos"] == "determiner"
    assert _tok("went", "eng")["stem"] == "go"
    assert _tok("children", "eng")["stem"] == "child"
    t = _tok("running", "eng")
    assert t["stem"] == "run" and t["pos"] == "verb"
    t = _tok("Don't", "eng")
    assert t["stem"] == "do" and [m["tag"] for m in t["morphs"]] == ["root", "NEG"]


@pytest.mark.parametrize("sentence,idx,pos", [
    ("I love you", 1, "verb"),
    ("Love is beautiful", 0, "noun"),
    ("Please help me", 1, "verb"),
    ("This is good", 0, "pronoun"),
    ("this book", 0, "determiner"),
])
def test_english_context_disambiguation(sentence, idx, pos):
    assert _tok(sentence, "eng", idx)["pos"] == pos


def test_unknown_words_are_flagged_not_hidden():
    t = _tok("ஃபோன்களை", "tam")          # not in the lexicon
    assert t["confidence"] == "heuristic"
    t = _tok("hello", "tam")              # Latin word inside Dravidian text
    assert t["pos"] == "foreign"


def test_numbers_and_punctuation():
    toks = morph.analyse("நான் 3 புத்தகம்", "tam").tokens
    assert toks[1]["pos"] == "numeral"


@pytest.mark.parametrize("lang", DRAV)
def test_datasets_have_no_mixed_script_words(lang):
    """Regression: a Malayalam dataset entry once mixed Tamil letters into a Malayalam word."""
    scripts = {"tam": (0x0B80, 0x0BFF), "tel": (0x0C00, 0x0C7F), "kan": (0x0C80, 0x0CFF), "mal": (0x0D00, 0x0D7F)}
    lo, hi = scripts[lang]
    other = [r for k, r in scripts.items() if k != lang]
    values = [e[lang] for e in kd.LEXICON.values() if lang in e]
    for e in kd.PARALLEL_DATASET:
        if isinstance(e, dict) and lang in e:
            values.append(e[lang])
    for v in values:
        for ch in v:
            assert not any(a <= ord(ch) <= b for a, b in other), (lang, v)


@pytest.mark.parametrize("lang", DRAV)
def test_morph_endpoint(lang):
    sample = {"tam": "நான் தமிழ் பேசுகிறேன்", "tel": "నేను భాషలను ప్రేమిస్తున్నాను",
              "kan": "ನಾನು ಮನೆಗೆ ಹೋಗುತ್ತಿದ್ದೇನೆ", "mal": "ഞാൻ വീട്ടിലേക്ക് പോകുന്നു"}[lang]
    r = client.post("/api/morph", json={"text": sample, "lang": lang})
    assert r.status_code == 200
    body = r.json()
    assert len(body["tokens"]) == 3
    assert all(t["confidence"] == "exact" for t in body["tokens"])
    assert any(t["suffixes"] for t in body["tokens"])


def test_morph_endpoint_validation():
    assert client.post("/api/morph", json={"text": "  ", "lang": "tam"}).status_code == 422
    assert client.post("/api/morph", json={"text": "x", "lang": "xxx"}).status_code in (400, 422)
