"""API-level tests against MOCK engines. They verify routing, validation, language
handling and audio decoding - not translation/ASR/OCR quality."""
import io
import math
import struct
import wave

import pytest
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def make_wav(seconds=1.0, sr=16000) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(b"".join(
            struct.pack("<h", int(8000 * math.sin(2 * math.pi * 440 * i / sr)))
            for i in range(int(sr * seconds))))
    return buf.getvalue()


def test_health_and_languages():
    assert client.get("/api/health").json()["engine_mode"] == "mock"
    codes = {l["code"] for l in client.get("/api/languages").json()}
    assert codes == {"tam", "tel", "kan", "mal", "eng"}


def test_translate_auto_detect():
    r = client.post("/api/translate", json={"text": "வணக்கம்", "tgt": "eng"})
    assert r.status_code == 200
    body = r.json()
    assert body["src"] == "tam" and body["tgt"] == "eng"
    # the mock engine answers known phrases from the parallel dataset
    assert body["translation"] == "Hello"


@pytest.mark.parametrize("src", ["tam", "tel", "kan", "mal", "eng"])
@pytest.mark.parametrize("tgt", ["tam", "tel", "kan", "mal", "eng"])
def test_translate_supported_language_pairs(src, tgt):
    if src == tgt:
        pytest.skip("Same-language translations are rejected by design.")

    hello_by_language = {
        "tam": "வணக்கம்",
        "tel": "నమస్కారం",
        "kan": "ನಮಸ್ಕಾರ",
        "mal": "നമസ്കാരം",
        "eng": "Hello",
    }
    response = client.post(
        "/api/translate",
        json={"text": hello_by_language[src], "src": src, "tgt": tgt},
    )

    assert response.status_code == 200, response.text
    assert response.json()["src"] == src
    assert response.json()["tgt"] == tgt
    assert response.json()["translation"].strip()


def test_translate_multi_sentence_keeps_lines():
    r = client.post("/api/translate", json={"text": "One. Two.", "src": "eng", "tgt": "tel"})
    assert r.json()["translation"].count("\n") == 1


def test_translate_same_language_rejected():
    r = client.post("/api/translate", json={"text": "Hello", "src": "eng", "tgt": "eng"})
    assert r.status_code == 422


def test_translate_unknown_language_rejected():
    r = client.post("/api/translate", json={"text": "Hello", "tgt": "xx"})
    assert r.status_code == 422


def test_translate_warns_on_script_mismatch():
    r = client.post("/api/translate", json={"text": "வணக்கம்", "src": "tel", "tgt": "eng"})
    assert r.status_code == 200 and r.json()["warning"]


def test_translate_too_long():
    r = client.post("/api/translate", json={"text": "a" * 6000, "tgt": "tam"})
    assert r.status_code == 413


def test_asr_decodes_audio():
    r = client.post("/api/asr", files={"file": ("a.wav", make_wav(1.0), "audio/wav")}, data={"lang": "tam"})
    assert r.status_code == 200
    assert r.json()["seconds"] == 1.0


def test_asr_rejects_garbage():
    r = client.post("/api/asr", files={"file": ("a.webm", b"not audio", "audio/webm")}, data={"lang": "tam"})
    assert r.status_code == 422


def test_asr_rejects_too_short():
    r = client.post("/api/asr", files={"file": ("a.wav", make_wav(0.1), "audio/wav")}, data={"lang": "tam"})
    assert r.status_code == 422


def test_ocr_roundtrip():
    r = client.post("/api/ocr", files={"file": ("x.png", b"\x89PNGfake", "image/png")}, data={"lang": "kan"})
    assert r.status_code == 200 and r.json()["lang"] == "kan"


def test_ocr_empty_file_rejected():
    r = client.post("/api/ocr", files={"file": ("x.png", b"", "image/png")})
    assert r.status_code == 422


def test_tts_returns_wav():
    r = client.post("/api/tts", json={"text": "வணக்கம்", "lang": "tam"})
    assert r.status_code == 200
    assert r.headers["content-type"] == "audio/wav"
    with wave.open(io.BytesIO(r.content)) as w:
        assert w.getnframes() > 0
