"""Audio decoding tests - including the 'ffmpeg missing' situation behind
``[WinError 2] The system cannot find the file specified``."""
import io
import math
import struct
import wave

import numpy as np
import pytest
from fastapi.testclient import TestClient

from app import audio
from app.main import app

client = TestClient(app)


def make_wav(seconds=1.0, sr=16000, channels=1, width=2) -> bytes:
    buf = io.BytesIO()
    n = int(sr * seconds)
    with wave.open(buf, "wb") as w:
        w.setnchannels(channels)
        w.setsampwidth(width)
        w.setframerate(sr)
        frames = []
        for i in range(n):
            v = math.sin(2 * math.pi * 440 * i / sr)
            for _ in range(channels):
                if width == 1:
                    frames.append(struct.pack("<B", int(128 + 100 * v)))
                else:
                    frames.append(struct.pack("<h", int(8000 * v)))
        w.writeframes(b"".join(frames))
    return buf.getvalue()


@pytest.fixture
def no_ffmpeg(monkeypatch):
    """Simulate a Windows machine without ffmpeg: every attempt to start it raises WinError 2."""
    def boom(*a, **k):
        raise FileNotFoundError(2, "The system cannot find the file specified")
    monkeypatch.setattr(audio.subprocess, "run", boom)
    monkeypatch.setattr(audio.shutil, "which", lambda name: "ffmpeg.exe" if name == "ffmpeg" else None)
    monkeypatch.setattr(audio, "_ffmpeg_candidates", lambda: ["ffmpeg.exe"])
    monkeypatch.setitem(__import__("sys").modules, "av", None)   # PyAV unavailable too


def test_wav_decodes_without_any_external_tool(no_ffmpeg):
    x = audio.to_pcm16k(make_wav(1.0))
    assert x.dtype == np.float32 and abs(len(x) - 16000) <= 1
    assert 0.1 < float(np.abs(x).max()) < 1.0


@pytest.mark.parametrize("sr", [8000, 22050, 44100, 48000])
def test_wav_resampled_to_16k(sr, no_ffmpeg):
    x = audio.to_pcm16k(make_wav(1.0, sr=sr))
    assert abs(len(x) - 16000) <= 2


def test_stereo_and_8bit_wav(no_ffmpeg):
    assert abs(len(audio.to_pcm16k(make_wav(1.0, channels=2))) - 16000) <= 1
    assert abs(len(audio.to_pcm16k(make_wav(1.0, width=1))) - 16000) <= 1


def test_non_wav_without_decoder_gives_helpful_error_not_winerror(no_ffmpeg):
    with pytest.raises(audio.DecoderUnavailable) as ei:
        audio.to_pcm16k(b"\x1a\x45\xdf\xa3 webm-bytes " * 50)
    msg = str(ei.value)
    assert "WinError" not in msg and "imageio-ffmpeg" in msg


def test_empty_upload():
    with pytest.raises(audio.AudioDecodeError):
        audio.to_pcm16k(b"")


def test_api_asr_wav_ok_even_without_ffmpeg(no_ffmpeg):
    r = client.post("/api/asr", files={"file": ("speech.wav", make_wav(1.5), "audio/wav")}, data={"lang": "tam"})
    assert r.status_code == 200, r.text
    assert r.json()["seconds"] == 1.5 and r.json()["text"]


def test_api_asr_webm_without_ffmpeg_is_clean_error(no_ffmpeg):
    r = client.post("/api/asr", files={"file": ("speech.webm", b"\x1a\x45\xdf\xa3" * 300, "audio/webm")},
                    data={"lang": "tam"})
    assert r.status_code == 415
    assert "WinError" not in r.text and "ffmpeg" in r.text


def test_api_asr_too_short_and_garbage():
    r = client.post("/api/asr", files={"file": ("s.wav", make_wav(0.1), "audio/wav")}, data={"lang": "tam"})
    assert r.status_code == 422
    r = client.post("/api/asr", files={"file": ("s.wav", b"RIFF1234WAVEjunk", "audio/wav")}, data={"lang": "tam"})
    assert r.status_code == 422 and "WinError" not in r.text


def test_real_ffmpeg_path_if_available(tmp_path):
    """If any ffmpeg exists here, a non-WAV container (FLAC via ffmpeg) must decode."""
    import shutil
    import subprocess
    exe = shutil.which("ffmpeg")
    if not exe:
        pytest.skip("ffmpeg not installed in this environment")
    wav = tmp_path / "a.wav"
    wav.write_bytes(make_wav(1.0, sr=44100))
    ogg = subprocess.run([exe, "-v", "error", "-i", str(wav), "-f", "ogg", "-c:a", "libvorbis", "pipe:1"],
                         capture_output=True).stdout
    if not ogg:
        pytest.skip("ffmpeg lacks vorbis encoder")
    assert abs(len(audio.to_pcm16k(ogg)) - 16000) < 1500
