import pytest

from app import langid
from app.textutil import split_sentences


@pytest.mark.parametrize("text,expected", [
    ("வணக்கம், நீங்கள் எப்படி இருக்கிறீர்கள்?", "tam"),
    ("నమస్కారం, మీరు ఎలా ఉన్నారు?", "tel"),
    ("ನಮಸ್ಕಾರ, ನೀವು ಹೇಗಿದ್ದೀರಿ?", "kan"),
    ("നമസ്കാരം, സുഖമാണോ?", "mal"),
    ("Hello, how are you?", "eng"),
])
def test_detects_script(text, expected):
    d = langid.detect(text)
    assert d.lang == expected
    assert d.confidence > 0.95


def test_mixed_text_picks_majority_and_lowers_confidence():
    d = langid.detect("வணக்கம் hello hello hello")
    assert d.lang == "eng"
    assert d.confidence < 1.0


def test_no_letters_returns_none():
    assert langid.detect("1234 !?").lang is None


def test_sentence_split_keeps_all_text():
    text = "First one. Second one?\nThird one! நான்காவது வாக்கியம்।"
    parts = split_sentences(text)
    assert parts == ["First one.", "Second one?", "Third one!", "நான்காவது வாக்கியம்।"]


def test_long_run_on_is_wrapped():
    parts = split_sentences("word " * 300, max_len=100)
    assert all(len(p) <= 100 for p in parts)
