"""Kannada morphology: lexicon, paradigm generators, irregular forms, OOV fallback.

Same architecture as ``morph_tam``: regular forms are generated from the lexicon and indexed
by surface form; irregular, pronominal and compound forms are listed in FIXED; unknown words
fall back to suffix chains and are flagged ``confidence = heuristic``.
"""
from __future__ import annotations

from .morph_common import Analysis, kv, lex_lines
from .morph_gen import drop_final, finish_build, make_P, with_question

L = "kan"
P = make_P(L)


def drop_any_vowel(p: str) -> str:
    return drop_final(p, L)


# invariant words: word | pos | gloss | feats
WORDS = """
ಅದು | pronoun | it | type=demonstrative-distal
ಅವನು | pronoun | he | person=3rd;gender=masculine
ಅವರು | pronoun | they | person=3rd;number=plural/honorific
ಅವಳು | pronoun | she | person=3rd;gender=feminine
ಆಸ್ಪತ್ರೆ | noun | 
ಆಹಾರ | noun | food
ಇಂದು | adverb | 
ಇದು | pronoun |  | type=demonstrative-proximal
ಇಲ್ಲ | verb |  | polarity=negative
ಈಗ | adverb | 
ಊಟ | noun | 
ಊರು | noun | 
ಎಲ್ಲಿ | adverb | where | type=interrogative
ಎಷ್ಟು | adverb |  | type=interrogative
ಏಕೆ | adverb | why | type=interrogative
ಏನು | pronoun | what | type=interrogative
ಒಳ್ಳೆಯ | adjective | good
ಕೆಟ್ಟ | adjective | bad
ಚಂದ್ರ | noun | moon
ಚಿಕ್ಕ | adjective | small
ತುಂಬಾ | adverb | 
ದಯವಿಟ್ಟು | interjection | 
ದಿನ | noun | day
ದೇಶ | noun | country
ದೊಡ್ಡ | adjective | big
ದ್ರಾವಿಡ | adjective | 
ಧನ್ಯವಾದಗಳು | interjection | 
ನಗರ | noun | city
ನಮಸ್ಕಾರ | interjection | 
ನಾನು | pronoun | i | person=1st;number=singular
ನಾವು | pronoun | we | person=1st;number=plural
ನಿಲ್ದಾಣ | noun | 
ನೀರು | noun | water
ನೀವು | pronoun | you | person=2nd
ಪುಸ್ತಕ | noun | book
ಪ್ರೀತಿ | noun | love
ಬೆಲೆ | noun | 
ಭಾಷೆ | noun | language
ಮತ್ತೆ | adverb | 
ಮಧ್ಯಾಹ್ನ | noun | 
ಮನೆ | noun | house
ಯಾರು | pronoun | who | type=interrogative
ಯಾವ | determiner |  | type=interrogative
ಯಾವಾಗ | adverb | when | type=interrogative
ಯಾವುದು | pronoun |  | type=interrogative
ರಾತ್ರಿ | noun | night
ರೈಲ್ವೆ | noun | 
ಶಾಲೆ | noun | school
ಶುಭ | adjective | 
ಶುಭರಾತ್ರಿ | interjection | 
ಶುಭೋದಯ | interjection | 
ಸಂಜೆ | noun | 
ಸಮಯ | noun | time
ಸಹಾಯ | noun | 
ಸೂರ್ಯ | noun | sun
ಸ್ನೇಹಿತ | noun | friend
ಸ್ವಾಗತ | interjection | 
ಹಳೆಯ | adjective | old
ಹೆಸರು | noun | name
ಹೇಗೆ | adverb | how | type=interrogative
ಹೊಸ | adjective | new
ಹೌದು | particle | 
"""

# irregular / suppletive / closed-class forms: token | lemma | pos | morphs | feats | gloss
FIXED = """
ಅರ್ಥವಾಗುತ್ತಿಲ್ಲ | ಅರ್ಥವಾಗು | verb | ಅರ್ಥವಾಗು ತ್ತಿಲ್ಲ:NEG | tense=present
ಅರ್ಥವಾಯಿತು | ಅರ್ಥವಾಗು | verb | ಅರ್ಥವಾ ಯಿ:PAST ತು:3SGN
ಆಯ್ತಾ | ಆಗು | verb | ಆ ಯ್ತ್:PAST.3SGN ಆ:Q
ಇದರ | ಇದು | pronoun | ಇದ್ ಅರ:GEN
ಎಲ್ಲಿಗೆ | ಎಲ್ಲಿ | adverb | ಎಲ್ಲಿ ಗೆ:DAT
ಎಲ್ಲಿದೆ | ಎಲ್ಲಿ | phrase | ಎಲ್ಲಿ ದೆ:COP
ಗೊತ್ತಿಲ್ಲ | ಗೊತ್ತು | noun | ಗೊತ್ತ್ ಇಲ್ಲ:NEG
ಚೆನ್ನಾಗಿದೆ | ಚೆನ್ನಾಗಿರು | verb | ಚೆನ್ನಾಗಿ ದೆ:COP
ಚೆನ್ನಾಗಿದ್ದೇನೆ | ಚೆನ್ನಾಗಿರು | verb | ಚೆನ್ನಾಗಿ ದ್ದ್:COP ಏನೆ:1SG
ಜಾಗರೂಕರಾಗಿರಿ | ಜಾಗರೂಕರಾಗಿರು | verb | ಜಾಗರೂಕರ್ ಆಗಿ:VBP ರಿ:IMP.HON
ನನಗೆ | ನಾನು | pronoun | ನನ ಗೆ:DAT | person=1st;case=dative
ನನ್ನ | ನಾನು | pronoun | ನನ್ನ | person=1st;case=genitive
ನಮ್ಮ | ನಾವು | pronoun | ನಮ್ಮ | person=1st;number=plural;case=genitive
ನಿನ್ನನ್ನು | ನೀನು | pronoun | ನಿನ್ನ್ ಅನ್ನು:ACC | person=2nd
ನಿಮ್ಮ | ನೀವು | pronoun | ನಿಮ್ಮ | person=2nd;case=genitive
ಭೇಟಿಯಾಗೋಣ | ಭೇಟಿಯಾಗು | verb | ಭೇಟಿಯಾಗ್ ಓಣ:HORT
ಸಂತೋಷವಾಗಿದ್ದೇನೆ | ಸಂತೋಷವಾಗಿರು | verb | ಸಂತೋಷವಾಗಿ ದ್ದ್:COP ಏನೆ:1SG
ಹೆಸರೇನು | ಹೆಸರು | phrase | ಹೆಸರ್ ಏನು:WORD
ಹೇಗಿದ್ದೀರಿ | ಹೇಗಿರು | verb | ಹೇಗಿ ದ್ದ್:COP ಈರಿ:2PL
"""

# noun | pos | gloss | class (A = -a final, E = -e/-i final, U = -u final) [| flag]
NOUNS = """
ಅಭಿನಂದನೆ | noun | congratulation | E
ಶುಭಾಶಯ | noun | good wish | A
ಭಾಷೆ | noun | language | E
ಮನೆ | noun | house | E
ಪುಸ್ತಕ | noun | book | A
ದೇಶ | noun | country | A
ನಗರ | noun | city | A
ಸಮಯ | noun | time | A
ಸಹಾಯ | noun | help | A
ಆಹಾರ | noun | food | A
ಹುಟ್ಟುಹಬ್ಬ | noun | birthday | A
ಶಾಲೆ | noun | school | E
ಆಸ್ಪತ್ರೆ | noun | hospital | E
ಸಂಜೆ | noun | evening | E
ಬೆಲೆ | noun | price | E
ನೀರು | noun | water | U
ಊರು | noun | town | U
ಹೆಸರು | noun | name | U
ಸುಂದರ | adjective | beautiful | A | adj
"""

# verb | gloss | spec ; spec = root+marker (person endings and Q are generated)
VERBS = """
ಪ್ರೀತಿಸು | love | pres=ಪ್ರೀತಿಸು+ತ್ತ್
ಬಯಸು | want | pres=ಬಯಸು+ತ್ತ್
ಮಾಡು | do | prs.cont=ಮಾಡು+ತ್ತಿದ್ದ್ abil=ಮಾಡ+ಬಹುದ್ imp=ಮಾಡ್+ಇ
ಹೋಗು | go | prs.cont=ಹೋಗು+ತ್ತಿದ್ದ್ imp=ಹೋಗ್+ಇ
ಕೊಡು | give | imp=ಕೊಡ್+ಇ
ಕಲಿ | learn | inf=ಕಲಿ+ಯಲು
ಬರು | come | pres=ಬರು+ತ್ತ್ imp=ಬನ್ನ್+ಇ
ನೋಡು | see | pres=ನೋಡು+ತ್ತ್ imp=ನೋಡ್+ಇ
ತಿನ್ನು | eat | pres=ತಿನ್ನು+ತ್ತ್ imp=ತಿನ್ನ್+ಇ
"""

PNG = [("ಏನೆ", "1SG"), ("ಈಯೆ", "2SG"), ("ಆನೆ", "3SGM"), ("ಆಳೆ", "3SGF"),
       ("ಏವೆ", "1PL"), ("ಈರಿ", "2PL"), ("ಆರೆ", "3PL"), ("ಅದೆ", "3SGN")]
Q = P("ಆ")

# nouns: tag -> suffix per class
_CASES = {
    "A": [("ವನ್ನು", "ACC"), ("ಕ್ಕೆ", "DAT"), ("ದಲ್ಲಿ", "LOC"), ("ದ", "GEN"), ("ದಿಂದ", "INS")],
    "E": [("ಯನ್ನು", "ACC"), ("ಗೆ", "DAT"), ("ಯಲ್ಲಿ", "LOC"), ("ಯ", "GEN"), ("ಯಿಂದ", "INS")],
}


def _noun_forms(lemma, pos, gloss, cls, flag=""):
    out = []
    Lm = P(lemma)

    def add(morphs, pos_=None):
        out.append(("".join(m for m, _ in morphs), Analysis(lemma, pos_ or pos, morphs, gloss, {}, "lexicon", 5)))

    if cls in ("A", "E"):
        add([(Lm, ""), (P("ಗಳು"), "PL")])
        add([(Lm, ""), (P("ಗಳ್"), "PL"), (P("ಅನ್ನು"), "ACC")])
        add([(Lm, ""), (P("ಗಳ್"), "PL"), (P("ಇಗೆ"), "DAT")])
        for suf, tag in _CASES[cls]:
            add([(Lm, ""), (P(suf), tag)])
        if flag == "adj":
            add([(Lm, ""), (P("ವಾದ"), "ADJZ")], "adjective")
    elif cls == "U":
        stem = Lm[:-1]
        add([(Lm, ""), (P("ಗಳು"), "PL")])
        add([(stem, ""), (P("ಅನ್ನು"), "ACC")])
    return out


def _verb_forms(lemma, gloss, spec):
    out = []

    def mk(morphs):
        return Analysis(lemma, "verb", morphs, gloss, {}, "lexicon", 5)

    def add(morphs, finite=False):
        out.append(("".join(m for m, _ in morphs), mk(morphs)))
        if finite:
            q = with_question(morphs, Q, L, drop_any_vowel)
            out.append(("".join(m for m, _ in q), mk(q)))

    def split(s):
        a, _, b = s.partition("+")
        return P(a), P(b)

    for key, tag in (("pres", "PRES"), ("prs.cont", "PRS.CONT")):
        if key in spec:
            root, marker = split(spec[key])
            for png, ptag in PNG:
                add([(root, ""), (marker, tag), (P(png), ptag)], True)
    if "abil" in spec:
        root, marker = split(spec["abil"])
        add([(root, ""), (marker, "ABIL")], True)
    if "inf" in spec:
        root, marker = split(spec["inf"])
        add([(root, ""), (marker, "INF")])
    if "imp" in spec:
        root, marker = split(spec["imp"])
        add([(root, ""), (marker, "IMP.HON")])
    return out


def build():
    def gen():
        for row in lex_lines(NOUNS):
            yield from _noun_forms(row[0], row[1], row[2], row[3], row[4] if len(row) > 4 else "")
        for row in lex_lines(VERBS):
            lemma, gloss = row[0], row[1]
            yield from _verb_forms(lemma, gloss, kv(row[2]) if len(row) > 2 else {})
    return finish_build(L, WORDS, FIXED, gen())


def heuristic_chains():
    chains = []
    for suf, tag in _CASES["A"] + _CASES["E"]:
        chains.append((P(suf), [(P(suf), tag)], "noun"))
    chains.append((P("ಗಳು"), [(P("ಗಳು"), "PL")], "noun"))
    chains.append((P("ಅನ್ನು"), [(P("ಅನ್ನು"), "ACC")], "noun"))
    for png, ptag in PNG:
        chains.append((P("ತ್ತ್") + P(png), [(P("ತ್ತ್"), "PRES"), (P(png), ptag)], "verb"))
    chains.append((P("ವಾದ"), [(P("ವಾದ"), "ADJZ")], "adjective"))
    chains.append((P("ಆಗಿ"), [(P("ಆಗಿ"), "ADVZ")], "adverb"))
    chains.sort(key=lambda c: -len(c[0]))
    return chains
