"""Script layer for the morphological analyser.

Dravidian scripts are abugidas: a consonant letter carries an inherent vowel and a
vowel sign (matra) *replaces* it. That is why naive string-suffix stripping fails
("வீடு"+"இல்" is written வீட்டில் - the suffix இல் never appears as a substring).

To do morphology correctly we convert words to a *phoneme-level* form in which every
vowel is explicit:

    consonant + VIRAMA + independent-vowel          (க + ி  ->  க ் இ)
    consonant + VIRAMA                              (a bare consonant, e.g. ம்)

Morpheme boundaries can then fall between any two phonemes, and the surface form is
recovered with ``from_phon``. ``from_phon(to_phon(x)) == x`` for NFC text; this is
unit-tested for every analysed token.
"""
from __future__ import annotations

import unicodedata

# (independent vowels, {matra: independent vowel}, virama, consonant range(s), inherent vowel)
_SCRIPTS: dict[str, dict] = {
    "tam": {
        "vowels": "அஆஇஈஉஊஎஏஐஒஓஔ",
        "matras": {"ா": "ஆ", "ி": "இ", "ீ": "ஈ", "ு": "உ", "ூ": "ஊ", "ெ": "எ", "ே": "ஏ",
                   "ை": "ஐ", "ொ": "ஒ", "ோ": "ஓ", "ௌ": "ஔ"},
        "virama": "்",
        "cons": [(0x0B95, 0x0BB9)],
        "a": "அ",
        "signs": "ஂஃ",
        "front": "இஈஎஏஐ",
    },
    "tel": {
        "vowels": "అఆఇఈఉఊఋౠఎఏఐఒఓఔ",
        "matras": {"ా": "ఆ", "ి": "ఇ", "ీ": "ఈ", "ు": "ఉ", "ూ": "ఊ", "ృ": "ఋ", "ౄ": "ౠ",
                   "ె": "ఎ", "ే": "ఏ", "ై": "ఐ", "ొ": "ఒ", "ో": "ఓ", "ౌ": "ఔ"},
        "virama": "్",
        "cons": [(0x0C15, 0x0C39)],
        "a": "అ",
        "signs": "ఁంః",
        "front": "ఇఈఎఏఐ",
    },
    "kan": {
        "vowels": "ಅಆಇಈಉಊಋೠಎಏಐಒಓಔ",
        "matras": {"ಾ": "ಆ", "ಿ": "ಇ", "ೀ": "ಈ", "ು": "ಉ", "ೂ": "ಊ", "ೃ": "ಋ", "ೄ": "ೠ",
                   "ೆ": "ಎ", "ೇ": "ಏ", "ೈ": "ಐ", "ೊ": "ಒ", "ೋ": "ಓ", "ೌ": "ಔ"},
        "virama": "್",
        "cons": [(0x0C95, 0x0CB9)],
        "a": "ಅ",
        "signs": "ಁಂಃ",
        "front": "ಇಈಎಏಐ",
    },
    "mal": {
        "vowels": "അആഇഈഉഊഋൠഎഏഐഒഓഔ",
        "matras": {"ാ": "ആ", "ി": "ഇ", "ീ": "ഈ", "ു": "ഉ", "ൂ": "ഊ", "ൃ": "ഋ",
                   "െ": "എ", "േ": "ഏ", "ൈ": "ഐ", "ൊ": "ഒ", "ോ": "ഓ", "ൌ": "ഔ"},
        "virama": "്",
        "cons": [(0x0D15, 0x0D3A)],
        "a": "അ",
        "signs": "ംഃ",
        "front": "ഇഈഎഏഐ",
    },
}

# Malayalam atomic chillu letters keep their own identity (they are consonants without
# a vowel and are not the same as consonant+virama in running text).
MAL_CHILLU = {"ൺ": "ണ", "ൻ": "ന", "ർ": "ര", "ൽ": "ല", "ൾ": "ള", "ൿ": "ക"}
_MAL_ZWJ_CHILLU = {"ണ": "ൺ", "ന": "ൻ", "ര": "ർ", "ല": "ൽ", "ള": "ൾ", "ക": "ൿ"}

_REV = {lang: {v: k for k, v in d["matras"].items()} for lang, d in _SCRIPTS.items()}
_CONS = {lang: {chr(c) for lo, hi in d["cons"] for c in range(lo, hi + 1)} for lang, d in _SCRIPTS.items()}
_CONS["mal"] |= set(MAL_CHILLU)  # chillus behave as vowel-less consonants


def supported(lang: str) -> bool:
    return lang in _SCRIPTS


def virama(lang: str) -> str:
    return _SCRIPTS[lang]["virama"]


def inherent(lang: str) -> str:
    return _SCRIPTS[lang]["a"]


def vowels(lang: str) -> str:
    return _SCRIPTS[lang]["vowels"]


def is_vowel(ch: str, lang: str) -> bool:
    return bool(ch) and ch in _SCRIPTS[lang]["vowels"]


def is_front_vowel(ch: str, lang: str) -> bool:
    return bool(ch) and ch in _SCRIPTS[lang]["front"]


def is_consonant(ch: str, lang: str) -> bool:
    return bool(ch) and ch in _CONS[lang]


def normalise(text: str, lang: str) -> str:
    """NFC + repair of Malayalam old-style chillus (consonant+virama+ZWJ)."""
    text = unicodedata.normalize("NFC", text)
    if lang == "mal":
        v = _SCRIPTS["mal"]["virama"]
        for base, chillu in _MAL_ZWJ_CHILLU.items():
            text = text.replace(base + v + "‍", chillu)
    return text.replace("‍", "").replace("‌", "")


def to_phon(text: str, lang: str) -> str:
    """Script text -> phoneme-level string (every vowel explicit)."""
    sc = _SCRIPTS[lang]
    vir, a, matras, cons = sc["virama"], sc["a"], sc["matras"], _CONS[lang]
    s = normalise(text, lang)
    out: list[str] = []
    i, n = 0, len(s)
    while i < n:
        ch = s[i]
        if ch in cons:
            if ch in MAL_CHILLU:           # atomic vowel-less consonant
                out.append(ch)
                i += 1
                continue
            nxt = s[i + 1] if i + 1 < n else ""
            if nxt in matras:
                out += [ch, vir, matras[nxt]]
                i += 2
            elif nxt == vir:
                out += [ch, vir]
                i += 2
            else:                           # inherent vowel
                out += [ch, vir, a]
                i += 1
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def from_phon(phon: str, lang: str) -> str:
    """Phoneme-level string -> ordinary script text."""
    sc = _SCRIPTS[lang]
    vir, a, rev, cons, vowels_ = sc["virama"], sc["a"], _REV[lang], _CONS[lang], sc["vowels"]
    out: list[str] = []
    i, n = 0, len(phon)
    while i < n:
        ch = phon[i]
        if (ch in cons and ch not in MAL_CHILLU and i + 2 < n
                and phon[i + 1] == vir and phon[i + 2] in vowels_):
            v = phon[i + 2]
            out.append(ch if v == a else ch + rev[v])
            i += 3
        else:
            out.append(ch)
            i += 1
    return "".join(out)


# ── small helpers used by the paradigm generators ───────────────────────────────
def ends_with_vowel(phon: str, lang: str) -> bool:
    return bool(phon) and phon[-1] in _SCRIPTS[lang]["vowels"]


def starts_with_vowel(phon: str, lang: str) -> bool:
    return bool(phon) and phon[0] in _SCRIPTS[lang]["vowels"]


def drop_final_vowel(phon: str, lang: str, which: str | None = None) -> str:
    """Remove a final independent vowel (and keep the preceding C+virama)."""
    if ends_with_vowel(phon, lang) and (which is None or phon[-1] in which):
        return phon[:-1]
    return phon


def unchillu(phon: str) -> str:
    """Malayalam: replace a final atomic chillu by consonant + virama (so a vowel can follow)."""
    if phon and phon[-1] in MAL_CHILLU:
        return phon[:-1] + MAL_CHILLU[phon[-1]] + _SCRIPTS["mal"]["virama"]
    return phon
