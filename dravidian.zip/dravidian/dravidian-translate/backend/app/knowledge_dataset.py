"""High-precision Dravidian language dataset, Romanized transliteration engine,
and Rule-based conversational translator.

Supports:
- High accuracy parallel dataset for Tamil (tam), Telugu (tel), Kannada (kan), Malayalam (mal), English (eng)
- Dravidian languages written in English (Tanglish, Tenglish, Kanglish, Manglish) detection & translation
- Romanized pronunciation guide for all translations
- Word-level and phrase-level compositional translation with SOV grammatical reordering
"""
import re
from typing import Optional, Tuple, Dict, List, Any

# ─────────────────────────────────────────────────────────────────────────────
# 1. PARALLEL CONVERSATIONAL PHRASE DATASET
# High-frequency greetings, questions, daily idioms, courtesies
# ─────────────────────────────────────────────────────────────────────────────
PARALLEL_DATASET = [
    {
        "en": "hi what is your name",
        "tam": "வணக்கம், உங்கள் பெயர் என்ன?",
        "tam_roman": "Vanakkam, ungal peyar enna?",
        "tel": "నమస్కారం, మీ పేరేమిటి?",
        "tel_roman": "Namaskaram, mee peremiti?",
        "kan": "ನಮಸ್ಕಾರ, ನಿಮ್ಮ ಹೆಸರೇನು?",
        "kan_roman": "Namaskara, nimma hesarenu?",
        "mal": "നമസ്കാരം, നിങ്ങളുടെ പേരെന്താണ്?",
        "mal_roman": "Namaskaram, ningalude perenthaanu?",
    },
    {
        "en": "what is your name",
        "tam": "உங்கள் பெயர் என்ன?",
        "tam_roman": "Ungal peyar enna?",
        "tel": "మీ పేరేమిటి?",
        "tel_roman": "Mee peremiti?",
        "kan": "ನಿಮ್ಮ ಹೆಸರೇನು?",
        "kan_roman": "Nimma hesarenu?",
        "mal": "നിങ്ങളുടെ പേരെന്താണ്?",
        "mal_roman": "Ningalude perenthaanu?",
    },
    {
        "en": "hello",
        "tam": "வணக்கம்",
        "tam_roman": "Vanakkam",
        "tel": "నమస్కారం",
        "tel_roman": "Namaskaram",
        "kan": "ನಮಸ್ಕಾರ",
        "kan_roman": "Namaskara",
        "mal": "നമസ്കാരം",
        "mal_roman": "Namaskaram",
    },
    {
        "en": "hi",
        "tam": "வணக்கம்",
        "tam_roman": "Vanakkam",
        "tel": "నమస్కారం",
        "tel_roman": "Namaskaram",
        "kan": "ನಮಸ್ಕಾರ",
        "kan_roman": "Namaskara",
        "mal": "നമസ്കാരം",
        "mal_roman": "Namaskaram",
    },
    {
        "en": "how are you",
        "tam": "நீங்கள் எப்படி இருக்கிறீர்கள்?",
        "tam_roman": "Neengal eppadi irukkireergal?",
        "tel": "మీరు ఎలా ఉన్నారు?",
        "tel_roman": "Meeru ela unnaru?",
        "kan": "ನೀವು ಹೇಗಿದ್ದೀರಿ?",
        "kan_roman": "Neevu hegiddiri?",
        "mal": "സുഖമാണോ?",
        "mal_roman": "Sukhamano?",
    },
    {
        "en": "i am fine",
        "tam": "நான் நலமாக இருக்கிறேன்",
        "tam_roman": "Naan nalamaaga irukkiren",
        "tel": "నేను బాగున్నాను",
        "tel_roman": "Nenu baagunnanu",
        "kan": "ನಾನು ಚೆನ್ನಾಗಿದ್ದೇನೆ",
        "kan_roman": "Naanu chennagiddene",
        "mal": "എനിക്ക് സുഖമാണ്",
        "mal_roman": "Enikku sukhamaanu",
    },
    {
        "en": "good morning",
        "tam": "காலை வணக்கம்",
        "tam_roman": "Kaalai vanakkam",
        "tel": "శుభోదయం",
        "tel_roman": "Subhodayam",
        "kan": "ಶುಭೋದಯ",
        "kan_roman": "Shubhodya",
        "mal": "സുപ്രഭാതം",
        "mal_roman": "Suprabhatham",
    },
    {
        "en": "good afternoon",
        "tam": "மதிய வணக்கம்",
        "tam_roman": "Madhiya vanakkam",
        "tel": "శుభ మధ్యాహ్నం",
        "tel_roman": "Subha madhyahnam",
        "kan": "ಶುಭ ಮಧ್ಯಾಹ್ನ",
        "kan_roman": "Shubha madhyahna",
        "mal": "ശുഭ ഉച്ച",
        "mal_roman": "Shubha ucha",
    },
    {
        "en": "good evening",
        "tam": "மாலை வணக்கம்",
        "tam_roman": "Maalai vanakkam",
        "tel": "శుభ సాయంత్రం",
        "tel_roman": "Subha sayanthram",
        "kan": "ಶುಭ ಸಂಜೆ",
        "kan_roman": "Shubha sanje",
        "mal": "ശുഭ സന്ധ്യ",
        "mal_roman": "Shubha sandhya",
    },
    {
        "en": "good night",
        "tam": "இனிய இரவு",
        "tam_roman": "Iniya iravu",
        "tel": "శుభరాత్రి",
        "tel_roman": "Subharatri",
        "kan": "ಶುಭರಾತ್ರಿ",
        "kan_roman": "Shubharatri",
        "mal": "ശുഭരാത്രി",
        "mal_roman": "Shubharathri",
    },
    {
        "en": "thank you",
        "tam": "நன்றி",
        "tam_roman": "Nandri",
        "tel": "ధన్యవాదాలు",
        "tel_roman": "Dhanyavaadaalu",
        "kan": "ಧನ್ಯವಾದಗಳು",
        "kan_roman": "Dhanyavaadagalu",
        "mal": "നന്ദി",
        "mal_roman": "Nanni",
    },
    {
        "en": "thank you very much",
        "tam": "மிக்க நன்றி",
        "tam_roman": "Mikka nandri",
        "tel": "చాలా ధన్యవాదాలు",
        "tel_roman": "Chala dhanyavaadaalu",
        "kan": "ತುಂಬಾ ಧನ್ಯವಾದಗಳು",
        "kan_roman": "Tumba dhanyavaadagalu",
        "mal": "വളരെ നന്ദി",
        "mal_roman": "Valare nanni",
    },
    {
        "en": "welcome",
        "tam": "வரவேற்கிறோம்",
        "tam_roman": "Varaverkirom",
        "tel": "స్వాగతం",
        "tel_roman": "Swaagatham",
        "kan": "ಸ್ವಾಗತ",
        "kan_roman": "Swaagatha",
        "mal": "സ്വാഗതം",
        "mal_roman": "Swaagatham",
    },
    {
        "en": "please",
        "tam": "தயவுசெய்து",
        "tam_roman": "Thayavuseythu",
        "tel": "దయచేసి",
        "tel_roman": "Dayachesi",
        "kan": "ದಯವಿಟ್ಟು",
        "kan_roman": "Dayavittu",
        "mal": "ദയവായി",
        "mal_roman": "Dayavaayi",
    },
    {
        "en": "have you eaten",
        "tam": "சாப்பிட்டீர்களா?",
        "tam_roman": "Saappitteergala?",
        "tel": "తిన్నారా?",
        "tel_roman": "Tinnara?",
        "kan": "ಊಟ ಆಯ್ತಾ?",
        "kan_roman": "Oota aayitha?",
        "mal": "ഭക്ഷണം കഴിച്ചോ?",
        "mal_roman": "Bhakshanam kazhicho?",
    },
    {
        "en": "where are you going",
        "tam": "நீங்கள் எங்கே போகிறீர்கள்?",
        "tam_roman": "Neengal engae pogireergal?",
        "tel": "మీరు ఎక్కడికి వెళ్తున్నారు?",
        "tel_roman": "Meeru ekkadiki velthunnaru?",
        "kan": "ನೀವು ಎಲ್ಲಿಗೆ ಹೋಗುತ್ತಿದ್ದೀರಿ?",
        "kan_roman": "Neevu ellige hoguttiddiri?",
        "mal": "നിങ്ങൾ എവിടെ പോകുന്നു?",
        "mal_roman": "Ningal evide pokunnu?",
    },
    {
        "en": "what are you doing",
        "tam": "நீங்கள் என்ன செய்கிறீர்கள்?",
        "tam_roman": "Neengal enna seigireergal?",
        "tel": "మీరు ఏమి చేస్తున్నారు?",
        "tel_roman": "Meeru emi chesthunnaru?",
        "kan": "ನೀವು ಏನು ಮಾಡುತ್ತಿದ್ದೀರಿ?",
        "kan_roman": "Neevu enu maaduttiddiri?",
        "mal": "നിങ്ങൾ എന്താണ് ചെയ്യുന്നത്?",
        "mal_roman": "Ningal enthaanu cheyyunnathu?",
    },
    {
        "en": "i don't understand",
        "tam": "எனக்கு புரியவில்லை",
        "tam_roman": "Enakku puriyavillai",
        "tel": "నాకు అర్థం కాలేదు",
        "tel_roman": "Naaku ardham kaledu",
        "kan": "ನನಗೆ ಅರ್ಥವಾಗುತ್ತಿಲ್ಲ",
        "kan_roman": "Nanage arthavaaguttilla",
        "mal": "എനിക്ക് മനസ്സിലായില്ല",
        "mal_roman": "Enikku manassilaayilla",
    },
    {
        "en": "i understand",
        "tam": "எனக்கு புரிகிறது",
        "tam_roman": "Enakku purigirathu",
        "tel": "నాకు అర్థమైంది",
        "tel_roman": "Naaku ardhamaindi",
        "kan": "ನನಗೆ ಅರ್ಥವಾಯಿತು",
        "kan_roman": "Nanage arthavaayithu",
        "mal": "എനിക്ക് മനസ്സിലായി",
        "mal_roman": "Enikku manassilaayi",
    },
    {
        "en": "what is this",
        "tam": "இது என்ன?",
        "tam_roman": "Ithu enna?",
        "tel": "ఇది ఏమిటి?",
        "tel_roman": "Idi emiti?",
        "kan": "ಇದು ಏನು?",
        "kan_roman": "Idu enu?",
        "mal": "ഇത് എന്താണ്?",
        "mal_roman": "Ith enthaanu?",
    },
    {
        "en": "where is the station",
        "tam": "ரயில் நிலையம் எங்கே?",
        "tam_roman": "Rayil nilaiyam engae?",
        "tel": "రైల్వే స్టేషన్ ఎక్కడ?",
        "tel_roman": "Railway station ekkada?",
        "kan": "ರೈಲ್ವೆ ನಿಲ್ದಾಣ ಎಲ್ಲಿದೆ?",
        "kan_roman": "Railway nildaana ellide?",
        "mal": "റെയിൽവേ സ്റ്റേഷൻ എവിടെയാണ്?",
        "mal_roman": "Railway station evideyaanu?",
    },
    {
        "en": "i love you",
        "tam": "நான் உன்னை காதலிக்கிறேன்",
        "tam_roman": "Naan unnai kaadhalikkiren",
        "tel": "నేను నిన్ను ప్రేమిస్తున్నాను",
        "tel_roman": "Nenu ninnu premisthunnanu",
        "kan": "ನಾನು ನಿನ್ನನ್ನು ಪ್ರೀತಿಸುತ್ತೇನೆ",
        "kan_roman": "Naanu ninnannu preethisutthene",
        "mal": "ഞാൻ നിന്നെ സ്നേഹിക്കുന്നു",
        "mal_roman": "Njaan ninne snehikkunnu",
    },
    {
        "en": "what time is it",
        "tam": "இப்போது மணி என்ன?",
        "tam_roman": "Ippothu mani enna?",
        "tel": "ఇప్పుడు సమయం ఎంత?",
        "tel_roman": "Ippudu samayam entha?",
        "kan": "ಈಗ ಸಮಯ ಎಷ್ಟು?",
        "kan_roman": "Eega samaya eshtu?",
        "mal": "ഇപ്പോൾ സമയം എത്രയായി?",
        "mal_roman": "Ippol samayam ethrayaayi?",
    },
    {
        "en": "see you again",
        "tam": "மீண்டும் சந்திப்போம்",
        "tam_roman": "Meendum santhippom",
        "tel": "మళ్ళీ కలుద్దాం",
        "tel_roman": "Mallee kaluddam",
        "kan": "ಮತ್ತೆ ಭೇಟಿಯಾಗೋಣ",
        "kan_roman": "Matte bhetiyaagona",
        "mal": "വീണ്ടും കാണാം",
        "mal_roman": "Veendum kaanaam",
    },
    {
        "en": "yes",
        "tam": "ஆம்",
        "tam_roman": "Aam",
        "tel": "అవును",
        "tel_roman": "Avunu",
        "kan": "ಹೌದು",
        "kan_roman": "Haudu",
        "mal": "അതെ",
        "mal_roman": "Athe",
    },
    {
        "en": "no",
        "tam": "இல்லை",
        "tam_roman": "Illai",
        "tel": "కాదు",
        "tel_roman": "Kaadu",
        "kan": "ಇಲ್ಲ",
        "kan_roman": "Illa",
        "mal": "അല്ല",
        "mal_roman": "Alla",
    },
    {
        "en": "how much is this",
        "tam": "இதன் விலை என்ன?",
        "tam_roman": "Idhan vilai enna?",
        "tel": "దీని ధర ఎంత?",
        "tel_roman": "Deeni dhara entha?",
        "kan": "ಇದರ ಬೆಲೆ ಎಷ್ಟು?",
        "kan_roman": "Idhara bele eshtu?",
        "mal": "ഇതിന് എത്രയാണ് വില?",
        "mal_roman": "Ithinu ethrayaanu vila?",
    },
    {
        "en": "where are you from",
        "tam": "நீங்கள் எந்த ஊர்?",
        "tam_roman": "Neengal endha oor?",
        "tel": "మీది ఏ ఊరు?",
        "tel_roman": "Meedi e ooru?",
        "kan": "ನಿಮ್ಮ ಊರು ಯಾವುದು?",
        "kan_roman": "Nimma ooru yaavudu?",
        "mal": "നിങ്ങൾ എവിടെ നിന്നാണ്?",
        "mal_roman": "Ningal evide ninnaanu?",
    },
    {
        "en": "can you help me",
        "tam": "எனக்கு உதவ முடியுமா?",
        "tam_roman": "Enakku udhava mudiyuma?",
        "tel": "నాకు సహాయం చేయగలరా?",
        "tel_roman": "Naaku sahaayam cheyagalara?",
        "kan": "ನನಗೆ ಸಹಾಯ ಮಾಡಬಹುದಾ?",
        "kan_roman": "Nanage sahaaya maadabahuda?",
        "mal": "എന്നെ സഹായിക്കാമോ?",
        "mal_roman": "Enne sahaayikkaamo?",
    },
    {
        "en": "take care",
        "tam": "உடம்பை பார்த்துக்கொள்ளுங்கள்",
        "tam_roman": "Udambai paarthukkollungal",
        "tel": "జాగ్రత్తగా ఉండండి",
        "tel_roman": "Jaagrathaga undandi",
        "kan": "ಜಾಗರೂಕರಾಗಿರಿ",
        "kan_roman": "Jaagarookaragiri",
        "mal": "ശ്രദ്ധിക്കൂ",
        "mal_roman": "Shradhikkoo",
    },
    {
        "en": "it is very good",
        "tam": "இது மிகவும் நன்றாக இருக்கிறது",
        "tam_roman": "Ithu migavum nandraaga irukkiradhu",
        "tel": "ఇది చాలా బాగుంది",
        "tel_roman": "Idi chala baagundi",
        "kan": "ಇದು ತುಂಬಾ ಚೆನ್ನಾಗಿದೆ",
        "kan_roman": "Idu tumba chennaagide",
        "mal": "ഇത് വളരെ നല്ലതാണ്",
        "mal_roman": "Ithu valare nallathaanu?",
    },
    {
        "en": "happy birthday",
        "tam": "இனிய பிறந்தநாள் வாழ்த்துகள்",
        "tam_roman": "Iniya pirandhanaal vaazhthugal",
        "tel": "పుట్టినరోజు శుభాకాంక్షలు",
        "tel_roman": "Puttinaroju subhaakaankshalu",
        "kan": "ಹುಟ್ಟುಹಬ್ಬದ ಶುಭಾಶಯಗಳು",
        "kan_roman": "Huttuhabbadha shubhaashayagalu",
        "mal": "ജന്മദിനാശംസകൾ",
        "mal_roman": "Janmadhinaashamsakal",
    },
    {
        "en": "congratulations",
        "tam": "வாழ்த்துகள்",
        "tam_roman": "Vaazhthukkal",
        "tel": "అభినందనలు",
        "tel_roman": "Abhinandanalu",
        "kan": "ಅಭಿನಂದನೆಗಳು",
        "kan_roman": "Abhinandanegalu",
        "mal": "അഭിനന്ദനങ്ങൾ",
        "mal_roman": "Abhinandanangal",
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# 2. DRAVIDIAN IN ENGLISH (ROMANIZED TRANSLITERATION / TANGLISH / TENGLISH etc.)
# Maps commonly typed English romanizations to native script & English meaning
# ─────────────────────────────────────────────────────────────────────────────
ROMANIZED_DRAVIDIAN = [
    # Tamil (Tanglish)
    {"lang": "tam", "roman": "vanakkam", "native": "வணக்கம்", "en": "Hello"},
    {"lang": "tam", "roman": "ungal peyar enna", "native": "உங்கள் பெயர் என்ன?", "en": "What is your name?"},
    {"lang": "tam", "roman": "unga per enna", "native": "உங்கள் பெயர் என்ன?", "en": "What is your name?"},
    {"lang": "tam", "roman": "eppadi irukkeenga", "native": "எப்படி இருக்கிறீர்கள்?", "en": "How are you?"},
    {"lang": "tam", "roman": "eppadi irukka", "native": "எப்படி இருக்கிறாய்?", "en": "How are you?"},
    {"lang": "tam", "roman": "nandri", "native": "நன்றி", "en": "Thank you"},
    {"lang": "tam", "roman": "romba nandri", "native": "மிக்க நன்றி", "en": "Thank you very much"},
    {"lang": "tam", "roman": "mikka nandri", "native": "மிக்க நன்றி", "en": "Thank you very much"},
    {"lang": "tam", "roman": "kaalai vanakkam", "native": "காலை வணக்கம்", "en": "Good morning"},
    {"lang": "tam", "roman": "iniya iravu", "native": "இனிய இரவு", "en": "Good night"},
    {"lang": "tam", "roman": "saptingala", "native": "சாப்பிட்டீர்களா?", "en": "Have you eaten?"},
    {"lang": "tam", "roman": "sapteengala", "native": "சாப்பிட்டீர்களா?", "en": "Have you eaten?"},
    {"lang": "tam", "roman": "enna panreenga", "native": "என்ன செய்கிறீர்கள்?", "en": "What are you doing?"},
    {"lang": "tam", "roman": "enga poreenga", "native": "எங்கே போகிறீர்கள்?", "en": "Where are you going?"},
    {"lang": "tam", "roman": "enakku puriyala", "native": "எனக்கு புரியவில்லை", "en": "I don't understand"},
    {"lang": "tam", "roman": "enakku theriyum", "native": "எனக்கு தெரியும்", "en": "I know"},
    {"lang": "tam", "roman": "poi vaanga", "native": "போய் வாருங்கள்", "en": "Goodbye"},
    {"lang": "tam", "roman": "thanni", "native": "தண்ணீர்", "en": "Water"},
    {"lang": "tam", "roman": "naan", "native": "நான்", "en": "I"},
    {"lang": "tam", "roman": "neenga", "native": "நீங்கள்", "en": "You"},

    # Telugu (Tenglish)
    {"lang": "tel", "roman": "namaskaram", "native": "నమస్కారం", "en": "Hello"},
    {"lang": "tel", "roman": "mee peru enti", "native": "మీ పేరేమిటి?", "en": "What is your name?"},
    {"lang": "tel", "roman": "mee peru emiti", "native": "మీ పేరేమిటి?", "en": "What is your name?"},
    {"lang": "tel", "roman": "ela unnaru", "native": "ఎలా ఉన్నారు?", "en": "How are you?"},
    {"lang": "tel", "roman": "dhanyavadalu", "native": "ధన్యవాదాలు", "en": "Thank you"},
    {"lang": "tel", "roman": "chala dhanyavadalu", "native": "చాలా ధన్యవాదాలు", "en": "Thank you very much"},
    {"lang": "tel", "roman": "subhodayam", "native": "శుభోదయం", "en": "Good morning"},
    {"lang": "tel", "roman": "subharatri", "native": "శుభరాత్రి", "en": "Good night"},
    {"lang": "tel", "roman": "tinnara", "native": "తిన్నారా?", "en": "Have you eaten?"},
    {"lang": "tel", "roman": "em chestunnaru", "native": "ఏమి చేస్తున్నారు?", "en": "What are you doing?"},
    {"lang": "tel", "roman": "ekkada unnaru", "native": "ఎక్కడ ఉన్నారు?", "en": "Where are you?"},
    {"lang": "tel", "roman": "naaku ardham kaledu", "native": "నాకు అర్థం కాలేదు", "en": "I don't understand"},
    {"lang": "tel", "roman": "neellu", "native": "నీరు", "en": "Water"},
    {"lang": "tel", "roman": "nenu", "native": "నేను", "en": "I"},
    {"lang": "tel", "roman": "meeru", "native": "మీరు", "en": "You"},

    # Kannada (Kanglish)
    {"lang": "kan", "roman": "namaskara", "native": "ನಮಸ್ಕಾರ", "en": "Hello"},
    {"lang": "kan", "roman": "nimma hesarenu", "native": "ನಿಮ್ಮ ಹೆಸರೇನು?", "en": "What is your name?"},
    {"lang": "kan", "roman": "hegiddira", "native": "ಹೇಗಿದ್ದೀರಿ?", "en": "How are you?"},
    {"lang": "kan", "roman": "hegiddeera", "native": "ಹೇಗಿದ್ದೀರಿ?", "en": "How are you?"},
    {"lang": "kan", "roman": "dhanyavadagalu", "native": "ಧನ್ಯವಾದಗಳು", "en": "Thank you"},
    {"lang": "kan", "roman": "tumba dhanyavadagalu", "native": "ತುಂಬಾ ಧನ್ಯವಾದಗಳು", "en": "Thank you very much"},
    {"lang": "kan", "roman": "shubhodya", "native": "ಶುಭೋದಯ", "en": "Good morning"},
    {"lang": "kan", "roman": "shubharatri", "native": "ಶುಭರಾತ್ರಿ", "en": "Good night"},
    {"lang": "kan", "roman": "oota aayitha", "native": "ಊಟ ಆಯ್ತಾ?", "en": "Have you eaten?"},
    {"lang": "kan", "roman": "enu madtiddira", "native": "ಏನು ಮಾಡುತ್ತಿದ್ದೀರಿ?", "en": "What are you doing?"},
    {"lang": "kan", "roman": "ellige hoguttiddiri", "native": "ಎಲ್ಲಿಗೆ ಹೋಗುತ್ತಿದ್ದೀರಿ?", "en": "Where are you going?"},
    {"lang": "kan", "roman": "nanage gothilla", "native": "ನನಗೆ ಗೊತ್ತಿಲ್ಲ", "en": "I don't know"},
    {"lang": "kan", "roman": "neeru", "native": "ನೀರು", "en": "Water"},
    {"lang": "kan", "roman": "naanu", "native": "ನಾನು", "en": "I"},
    {"lang": "kan", "roman": "neevu", "native": "ನೀವು", "en": "You"},

    # Malayalam (Manglish)
    {"lang": "mal", "roman": "namaskaram", "native": "നമസ്കാരം", "en": "Hello"},
    {"lang": "mal", "roman": "ningalude perentha", "native": "നിങ്ങളുടെ പേരെന്താണ്?", "en": "What is your name?"},
    {"lang": "mal", "roman": "perentha", "native": "പേരെന്താണ്?", "en": "What is your name?"},
    {"lang": "mal", "roman": "sukhamano", "native": "സുഖമാണോ?", "en": "How are you?"},
    {"lang": "mal", "roman": "engane irikkunnu", "native": "എങ്ങനെയിരിക്കുന്നു?", "en": "How are you?"},
    {"lang": "mal", "roman": "nanni", "native": "നന്ദി", "en": "Thank you"},
    {"lang": "mal", "roman": "valare nanni", "native": "വളരെ നന്ദി", "en": "Thank you very much"},
    {"lang": "mal", "roman": "suprabhatham", "native": "സുപ്രഭാതം", "en": "Good morning"},
    {"lang": "mal", "roman": "shubharathri", "native": "ശുഭരാത്രി", "en": "Good night"},
    {"lang": "mal", "roman": "choro kazhicho", "native": "ഭക്ഷണം കഴിച്ചോ?", "en": "Have you eaten?"},
    {"lang": "mal", "roman": "enthu cheyyunnu", "native": "എന്താണ് ചെയ്യുന്നത്?", "en": "What are you doing?"},
    {"lang": "mal", "roman": "manassilaayilla", "native": "മനസ്സിലായില്ല", "en": "I don't understand"},
    {"lang": "mal", "roman": "vellam", "native": "വെള്ളം", "en": "Water"},
    {"lang": "mal", "roman": "njaan", "native": "ഞാൻ", "en": "I"},
    {"lang": "mal", "roman": "ningal", "native": "നിങ്ങൾ", "en": "You"},
]

# ─────────────────────────────────────────────────────────────────────────────
# 3. CORE BILINGUAL VOCABULARY & TEMPLATES
# ─────────────────────────────────────────────────────────────────────────────
LEXICON = {
    # Pronouns
    "i": {"tam": "நான்", "tel": "నేను", "kan": "ನಾನು", "mal": "ഞാൻ"},
    "you": {"tam": "நீங்கள்", "tel": "మీరు", "kan": "ನೀವು", "mal": "നിങ്ങൾ"},
    "he": {"tam": "அவன்", "tel": "అతను", "kan": "ಅವನು", "mal": "അവൻ"},
    "she": {"tam": "அவள்", "tel": "ఆమె", "kan": "ಅವಳು", "mal": "അവൾ"},
    "we": {"tam": "நாங்கள்", "tel": "మేము", "kan": "ನಾವು", "mal": "ഞങ്ങൾ"},
    "they": {"tam": "அவர்கள்", "tel": "వారు", "kan": "ಅವರು", "mal": "അവർ"},
    "it": {"tam": "அது", "tel": "అది", "kan": "ಅದು", "mal": "അത്"},
    "my": {"tam": "என்", "tel": "నా", "kan": "ನನ್ನ", "mal": "എന്റെ"},
    "your": {"tam": "உங்கள்", "tel": "మీ", "kan": "ನಿಮ್ಮ", "mal": "നിങ്ങളുടെ"},

    # Nouns
    "name": {"tam": "பெயர்", "tel": "పేరు", "kan": "ಹೆಸರು", "mal": "പേര്"},
    "water": {"tam": "தண்ணீர்", "tel": "నీరు", "kan": "ನೀರು", "mal": "വെള്ളം"},
    "food": {"tam": "உணவு", "tel": "ఆహారం", "kan": "ಆಹಾರ", "mal": "ഭക്ഷണം"},
    "house": {"tam": "வீடு", "tel": "ఇల్లు", "kan": "ಮನೆ", "mal": "വീട്"},
    "book": {"tam": "புத்தகம்", "tel": "పుస్తకం", "kan": "ಪುಸ್ತಕ", "mal": "പുസ്തകം"},
    "friend": {"tam": "நண்பன்", "tel": "స్నేహితుడు", "kan": "ಸ್ನೇಹಿತ", "mal": "സുഹൃത്ത്"},
    "school": {"tam": "பள்ளி", "tel": "పాఠశాల", "kan": "ಶಾಲೆ", "mal": "സ്കൂൾ"},
    "language": {"tam": "மொழி", "tel": "భాష", "kan": "ಭಾಷೆ", "mal": "ഭാഷ"},
    "sun": {"tam": "சூரியன்", "tel": "సూర్యుడు", "kan": "ಸೂರ್ಯ", "mal": "സൂര്യൻ"},
    "moon": {"tam": "நிலா", "tel": "చంద్రుడు", "kan": "ಚಂದ್ರ", "mal": "ചന്ദ്രൻ"},
    "city": {"tam": "நகரம்", "tel": "నగరం", "kan": "ನಗರ", "mal": "നഗരം"},
    "country": {"tam": "நாடு", "tel": "దేశం", "kan": "ದೇಶ", "mal": "രാജ്യം"},
    "time": {"tam": "நேரம்", "tel": "సమయం", "kan": "ಸಮಯ", "mal": "സമയം"},
    "love": {"tam": "அன்பு", "tel": "ప్రేమ", "kan": "ಪ್ರೀತಿ", "mal": "സ്നേഹം"},
    "day": {"tam": "நாள்", "tel": "రోజు", "kan": "ದಿನ", "mal": "ദിവസം"},
    "night": {"tam": "இரவு", "tel": "రాత్రి", "kan": "ರಾತ್ರಿ", "mal": "രാത്രി"},

    # Adjectives
    "good": {"tam": "நல்ல", "tel": "మంచి", "kan": "ಒಳ್ಳೆಯ", "mal": "നല്ല"},
    "bad": {"tam": "கெட்ட", "tel": "చెడు", "kan": "ಕೆಟ್ಟ", "mal": "മോശം"},
    "big": {"tam": "பெரிய", "tel": "పెద్ద", "kan": "ದೊಡ್ಡ", "mal": "വലിയ"},
    "small": {"tam": "சிறிய", "tel": "చిన్న", "kan": "ಚಿಕ್ಕ", "mal": "ചെറിയ"},
    "beautiful": {"tam": "அழகான", "tel": "అందమైన", "kan": "ಸುಂದರವಾದ", "mal": "മനോഹരമായ"},
    "new": {"tam": "புதிய", "tel": "కొత్త", "kan": "ಹೊಸ", "mal": "പുതിയ"},
    "old": {"tam": "பழைய", "tel": "పాత", "kan": "ಹಳೆಯ", "mal": "പഴയ"},

    # Interrogatives
    "what": {"tam": "என்ன", "tel": "ఏమిటి", "kan": "ಏನು", "mal": "എന്ത്"},
    "where": {"tam": "எங்கே", "tel": "ఎక్కడ", "kan": "ಎಲ್ಲಿ", "mal": "എവിടെ"},
    "who": {"tam": "யார்", "tel": "ఎవరు", "kan": "ಯಾರು", "mal": "ആര്"},
    "how": {"tam": "எப்படி", "tel": "ఎలా", "kan": "ಹೇಗೆ", "mal": "എങ്ങനെ"},
    "why": {"tam": "ஏன்", "tel": "ఎందుకు", "kan": "ಏಕೆ", "mal": "എന്തുകൊണ്ട്"},
    "when": {"tam": "எப்போது", "tel": "ఎప్పుడు", "kan": "ಯಾವಾಗ", "mal": "എപ്പോൾ"},
}

def _clean_str(s: str) -> str:
    s = s.lower().strip()
    s = re.sub(r"[^\w\s]", "", s)
    s = re.sub(r"\s+", " ", s)
    return s

def detect_romanized_dravidian(text: str) -> Optional[Dict[str, Any]]:
    """Checks if Latin text is actually a Romanized Dravidian expression (Tanglish, etc.)."""
    cleaned = _clean_str(text)
    # Check exact match first
    for entry in ROMANIZED_DRAVIDIAN:
        if cleaned == _clean_str(entry["roman"]):
            return entry

    # Check longer phrases first for substring match
    sorted_entries = sorted(ROMANIZED_DRAVIDIAN, key=lambda e: len(e["roman"]), reverse=True)
    for entry in sorted_entries:
        if _clean_str(entry["roman"]) in cleaned:
            return entry
    return None

def translate_phrase(text: str, src: str, tgt: str) -> Optional[str]:
    """Check high-accuracy parallel dataset for exact/fuzzy phrase match."""
    cleaned = _clean_str(text)
    
    # 1. Parallel conversational phrases
    for row in PARALLEL_DATASET:
        # Check from English
        if src == "eng" or src == "auto":
            if cleaned == _clean_str(row["en"]):
                if tgt in row:
                    return row[tgt]
        
        # Check from Dravidian languages
        for lang_key in ["tam", "tel", "kan", "mal"]:
            if (src == lang_key or src == "auto") and lang_key in row:
                if cleaned == _clean_str(row[lang_key]) or cleaned == _clean_str(row.get(f"{lang_key}_roman", "")):
                    if tgt == "eng":
                        return row["en"].capitalize()
                    elif tgt in row:
                        return row[tgt]

    # 2. Check Romanized Dravidian dataset
    rom = detect_romanized_dravidian(text)
    if rom:
        if tgt == "eng":
            return rom["en"]
        if tgt == rom["lang"]:
            return rom["native"]
        # Pivot through English to other Dravidian
        for row in PARALLEL_DATASET:
            if _clean_str(row["en"]) == _clean_str(rom["en"]):
                if tgt in row:
                    return row[tgt]
        return rom["native"]

    # 3. Dynamic Template Matching (e.g. "my name is Jacob", "what is your X", "where is X")
    # "my name is <X>"
    m = re.match(r"^(?:hi\s+|hello\s+)?my\s+name\s+is\s+([a-zA-Z\s]+)$", cleaned, re.IGNORECASE)
    if m:
        name = m.group(1).title()
        if tgt == "tam":
            return f"வணக்கம், என் பெயர் {name}."
        elif tgt == "tel":
            return f"నమస్కారం, నా పేరు {name}."
        elif tgt == "kan":
            return f"ನಮಸ್ಕಾರ, ನನ್ನ ಹೆಸರು {name}."
        elif tgt == "mal":
            return f"നമസ്കാരം, എന്റെ പേര് {name}."

    # "what is your <noun>"
    m2 = re.match(r"^what\s+is\s+your\s+([a-zA-Z]+)$", cleaned, re.IGNORECASE)
    if m2:
        noun = m2.group(1).lower()
        if noun in LEXICON and tgt in LEXICON[noun]:
            your_w = {"tam": "உங்கள்", "tel": "మీ", "kan": "ನಿಮ್ಮ", "mal": "നിങ്ങളുടെ"}.get(tgt, "")
            what_w = {"tam": "என்ன?", "tel": "ఏమిటి?", "kan": "ಏನು?", "mal": "എന്താണ്?"}.get(tgt, "")
            return f"{your_w} {LEXICON[noun][tgt]} {what_w}"

    # "where is <noun>"
    m3 = re.match(r"^where\s+is\s+(?:the\s+)?([a-zA-Z]+)$", cleaned, re.IGNORECASE)
    if m3:
        noun = m3.group(1).lower()
        if noun in LEXICON and tgt in LEXICON[noun]:
            where_w = {"tam": "எங்கே?", "tel": "ఎక్కడ?", "kan": "ಎಲ್ಲಿ?", "mal": "എവിടെ?"}.get(tgt, "")
            return f"{LEXICON[noun][tgt]} {where_w}"

    # Single word from lexicon
    if cleaned in LEXICON:
        if src == "eng" or src == "auto":
            if tgt in LEXICON[cleaned]:
                return LEXICON[cleaned][tgt]
        # Reverse lookup
        for en_word, translations in LEXICON.items():
            if translations.get(src) == text.strip():
                if tgt == "eng":
                    return en_word.capitalize()
                return translations.get(tgt, en_word)

    return None


# ─────────────────────────────────────────────────────────────────────────────
# 4. GENERAL DRAVIDIAN PHONETIC ROMANIZER (AKSHARA TO LATIN)
# Converts any Native Script (Tamil, Telugu, Kannada, Malayalam) to Romanized English
# ─────────────────────────────────────────────────────────────────────────────
TAMIL_ROMAN = {
    # Vowels
    0x0B85: "a", 0x0B86: "aa", 0x0B87: "i", 0x0B88: "ee", 0x0B89: "u", 0x0B8A: "oo",
    0x0B8E: "e", 0x0B8F: "ae", 0x0B90: "ai", 0x0B92: "o", 0x0B93: "oe", 0x0B94: "au",
    # Consonants (inherent 'a')
    0x0B95: "ka", 0x0B99: "nga", 0x0B9A: "cha", 0x0B9C: "ja", 0x0B9E: "nya",
    0x0B9F: "ta", 0x0BA3: "na", 0x0BA4: "tha", 0x0BA8: "na", 0x0BA9: "na",
    0x0BAA: "pa", 0x0BAE: "ma", 0x0BAF: "ya", 0x0BB0: "ra", 0x0BB1: "ra",
    0x0BB2: "la", 0x0BB3: "la", 0x0BB4: "zha", 0x0BB5: "va", 0x0BB7: "sha",
    0x0BB8: "sa", 0x0BB9: "ha",
    # Matras
    0x0BBE: "aa", 0x0BBF: "i", 0x0BC0: "ee", 0x0BC1: "u", 0x0BC2: "oo",
    0x0BC6: "e", 0x0BC7: "ae", 0x0BC8: "ai", 0x0BCA: "o", 0x0BCB: "oe", 0x0BCC: "au",
    0x0BCD: "" # virama (pulli) suppresses 'a'
}

TELUGU_ROMAN = {
    0x0C05: "a", 0x0C06: "aa", 0x0C07: "i", 0x0C08: "ee", 0x0C09: "u", 0x0C0A: "oo",
    0x0C0E: "e", 0x0C0F: "ae", 0x0C10: "ai", 0x0C12: "o", 0x0C13: "oe", 0x0C14: "au",
    0x0C15: "ka", 0x0C16: "kha", 0x0C17: "ga", 0x0C18: "gha", 0x0C19: "nga",
    0x0C1A: "cha", 0x0C1B: "chha", 0x0C1C: "ja", 0x0C1D: "jha", 0x0C1E: "nya",
    0x0C1F: "ta", 0x0C20: "tha", 0x0C21: "da", 0x0C22: "dha", 0x0C23: "na",
    0x0C24: "tha", 0x0C25: "thha", 0x0C26: "da", 0x0C27: "dha", 0x0C28: "na",
    0x0C2A: "pa", 0x0C2B: "pha", 0x0C2C: "ba", 0x0C2D: "bha", 0x0C2E: "ma",
    0x0C2F: "ya", 0x0C30: "ra", 0x0C32: "la", 0x0C33: "la", 0x0C35: "va",
    0x0C36: "sha", 0x0C37: "ssha", 0x0C38: "sa", 0x0C39: "ha",
    # Matras
    0x0C3E: "aa", 0x0C3F: "i", 0x0C40: "ee", 0x0C41: "u", 0x0C42: "oo",
    0x0C46: "e", 0x0C47: "ae", 0x0C48: "ai", 0x0C4A: "o", 0x0C4B: "oe", 0x0C4C: "au",
    0x0C4D: ""
}

KANNADA_ROMAN = {
    0x0C85: "a", 0x0C86: "aa", 0x0C87: "i", 0x0C88: "ee", 0x0C89: "u", 0x0C8A: "oo",
    0x0C8E: "e", 0x0C8F: "ae", 0x0C90: "ai", 0x0C92: "o", 0x0C93: "oe", 0x0C94: "au",
    0x0C95: "ka", 0x0C96: "kha", 0x0C97: "ga", 0x0C98: "gha", 0x0C99: "nga",
    0x0C9A: "cha", 0x0C9B: "chha", 0x0C9C: "ja", 0x0C9D: "jha", 0x0C9E: "nya",
    0x0C9F: "ta", 0x0CA0: "tha", 0x0CA1: "da", 0x0CA2: "dha", 0x0CA3: "na",
    0x0CA4: "tha", 0x0CA5: "thha", 0x0CA6: "da", 0x0CA7: "dha", 0x0CA8: "na",
    0x0CAA: "pa", 0x0CAB: "pha", 0x0CAC: "ba", 0x0CAD: "bha", 0x0CAE: "ma",
    0x0CAF: "ya", 0x0CB0: "ra", 0x0CB2: "la", 0x0CB3: "la", 0x0CB5: "va",
    0x0CB6: "sha", 0x0CB7: "ssha", 0x0CB8: "sa", 0x0CB9: "ha",
    # Matras
    0x0CBE: "aa", 0x0CBF: "i", 0x0CC0: "ee", 0x0CC1: "u", 0x0CC2: "oo",
    0x0CC6: "e", 0x0CC7: "ae", 0x0CC8: "ai", 0x0CCA: "o", 0x0CCB: "oe", 0x0CCC: "au",
    0x0CCD: ""
}

MALAYALAM_ROMAN = {
    0x0D05: "a", 0x0D06: "aa", 0x0D07: "i", 0x0D08: "ee", 0x0D09: "u", 0x0D0A: "oo",
    0x0D0E: "e", 0x0D0F: "ae", 0x0D10: "ai", 0x0D12: "o", 0x0D13: "oe", 0x0D14: "au",
    0x0D15: "ka", 0x0D16: "kha", 0x0D17: "ga", 0x0D18: "gha", 0x0D19: "nga",
    0x0D1A: "cha", 0x0D1B: "chha", 0x0D1C: "ja", 0x0D1D: "jha", 0x0D1E: "nya",
    0x0D1F: "ta", 0x0D20: "tha", 0x0D21: "da", 0x0D22: "dha", 0x0D23: "na",
    0x0D24: "tha", 0x0D25: "thha", 0x0D26: "da", 0x0D27: "dha", 0x0D28: "na",
    0x0D2A: "pa", 0x0D2B: "pha", 0x0D2C: "ba", 0x0D2D: "bha", 0x0D2E: "ma",
    0x0D2F: "ya", 0x0D30: "ra", 0x0D31: "rra", 0x0D32: "la", 0x0D33: "lla",
    0x0D34: "zha", 0x0D35: "va", 0x0D36: "sha", 0x0D37: "ssha", 0x0D38: "sa", 0x0D39: "ha",
    # Matras
    0x0D3E: "aa", 0x0D3F: "i", 0x0D40: "ee", 0x0D41: "u", 0x0D42: "oo",
    0x0D46: "e", 0x0D47: "ae", 0x0D48: "ai", 0x0D4A: "o", 0x0D4B: "oe", 0x0D4C: "au",
    0x0D4D: ""
}

ROMAN_MAPS = {
    "tam": (TAMIL_ROMAN, 0x0BCD, (0x0BBE, 0x0BCC)),
    "tel": (TELUGU_ROMAN, 0x0C4D, (0x0C3E, 0x0C4C)),
    "kan": (KANNADA_ROMAN, 0x0CCD, (0x0CBE, 0x0CCC)),
    "mal": (MALAYALAM_ROMAN, 0x0D4D, (0x0D3E, 0x0D4C)),
}

def romanize_dravidian(text: str, lang: str) -> str:
    """Converts native Dravidian script into conversational Romanized English (Tanglish, Tenglish, etc.)."""
    # First check if phrase is in parallel dataset with manual curated high quality romanization
    cleaned = _clean_str(text)
    for row in PARALLEL_DATASET:
        if lang in row and _clean_str(row[lang]) == cleaned:
            return row.get(f"{lang}_roman", "")

    if lang not in ROMAN_MAPS:
        return text

    table, virama_cp, (matra_min, matra_max) = ROMAN_MAPS[lang]
    result = []
    i = 0
    chars = list(text)
    n = len(chars)

    while i < n:
        cp = ord(chars[i])
        if cp in table:
            base = table[cp]
            # Check if followed by virama (suppresses inherent 'a')
            if i + 1 < n and ord(chars[i+1]) == virama_cp:
                if base.endswith("a"):
                    result.append(base[:-1])
                else:
                    result.append(base)
                i += 2
                continue
            # Check if followed by matra (replaces inherent 'a')
            elif i + 1 < n and matra_min <= ord(chars[i+1]) <= matra_max:
                matra_cp = ord(chars[i+1])
                matra_val = table.get(matra_cp, "")
                if base.endswith("a"):
                    result.append(base[:-1] + matra_val)
                else:
                    result.append(base + matra_val)
                i += 2
                continue
            else:
                result.append(base)
        else:
            result.append(chars[i])
        i += 1

    romanized = "".join(result)
    # Capitalize sentence beginnings
    romanized = re.sub(r"(^\w|[.!?]\s+\w)", lambda m: m.group(1).upper(), romanized)
    return romanized

