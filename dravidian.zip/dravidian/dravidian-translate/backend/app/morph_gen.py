"""Helpers shared by the Telugu / Kannada / Malayalam morphology modules."""
from __future__ import annotations

from . import morph_script as ms
from .morph_common import Analysis, lex_lines, parse_feats, parse_fixed


def make_P(lang: str):
    return lambda s: ms.to_phon(s, lang)


def drop_final(phon: str, lang: str, vowels: str | None = None) -> str:
    """Drop a final independent vowel (optionally only the given ones)."""
    if phon and phon[-1] in ms.vowels(lang) and (vowels is None or phon[-1] in vowels):
        return phon[:-1]
    return phon


def finish_build(lang: str, words: str, fixed: str, generated) -> dict[str, list[Analysis]]:
    P = make_P(lang)
    idx: dict[str, list[Analysis]] = {}
    seen: set[tuple] = set()

    def put(form: str, a: Analysis):
        key = (form, a.lemma, a.pos, tuple(a.morphs))
        if key in seen:
            return
        seen.add(key)
        idx.setdefault(form, []).append(a)

    for row in lex_lines(words):
        word, pos = row[0], row[1]
        gloss = row[2] if len(row) > 2 else ""
        feats = parse_feats(row[3]) if len(row) > 3 else {}
        put(P(word), Analysis(word, pos, [(P(word), "")], gloss, feats, "fixed", 2))
    for row in lex_lines(fixed):
        form, a = parse_fixed(" | ".join(row), lang)
        put(form, a)
    for form, a in generated:
        put(form, a)
    return idx


def with_question(morphs, q_morph: str, lang: str, drop=None):
    """Append the question clitic; the final vowel of the host may be dropped."""
    last, tag = morphs[-1]
    if drop is not None:
        last = drop(last)
    return morphs[:-1] + [(last, tag), (q_morph, "Q")]
