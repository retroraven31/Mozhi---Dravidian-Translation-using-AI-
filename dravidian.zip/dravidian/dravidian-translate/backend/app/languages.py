"""Single source of truth for supported languages and the codes each engine expects.

Each Language dataclass carries both engine-integration fields (flores, asr, tess)
and rich linguistic metadata (family, branch, speakers, script facts, etc.) useful
for the /api/morph endpoint and any front-end info panels.
"""
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Language:
    code: str        # our API code (ISO 639-2 style)
    name: str
    native: str
    flores: str      # IndicTrans2 / FLORES-200 code
    asr: str         # IndicConformer language code
    tess: str        # Tesseract traineddata name
    script: str

    # ── Rich linguistic metadata ──────────────────────────────────────────
    family: str = "Dravidian"
    branch: str = ""
    speakers: str = ""
    script_name: str = ""
    script_direction: str = "left-to-right"
    unicode_block: str = ""
    romanization: str = ""
    grammar_type: str = "agglutinative"
    word_order: str = "SOV"
    interesting_facts: tuple = field(default_factory=tuple)
    english_description: str = ""


LANGUAGES: dict[str, Language] = {
    "tam": Language(
        code="tam",
        name="Tamil",
        native="தமிழ்",
        flores="tam_Taml",
        asr="ta",
        tess="tam",
        script="Tamil",
        family="Dravidian",
        branch="South Dravidian I",
        speakers="80 million",
        script_name="Tamil script",
        script_direction="left-to-right",
        unicode_block="U+0B80–U+0BFF",
        romanization="ISO 15919 / Transliteration (Tamil)",
        grammar_type="agglutinative",
        word_order="SOV",
        interesting_facts=(
            "Tamil is one of the longest-surviving classical languages in the world, "
            "with literary records dating back to at least the 3rd century BCE (Sangam literature).",
            "Tamil exhibits strict diglossia: the written/formal register (centamil) differs "
            "significantly from spoken colloquial Tamil (koduntamil).",
            "Tamil has a unique set of letters not found in other Indic scripts, including "
            "retroflex laterals and the special character 'ழ' (zha), absent from most other languages.",
        ),
        english_description=(
            "Tamil is a Dravidian language spoken predominantly in the Indian state of Tamil Nadu "
            "and in Sri Lanka, Singapore, Malaysia, and diaspora communities worldwide. It is one of "
            "the official languages of India, Sri Lanka, and Singapore. Tamil has an unbroken literary "
            "tradition spanning over two millennia, making it one of the world's oldest living classical "
            "languages. The language is agglutinative: words are formed by stacking suffixes onto a root, "
            "encoding case, number, tense, person, and gender in a single word-form. Tamil uses its own "
            "abugida script, written left-to-right, whose Unicode block spans U+0B80–U+0BFF."
        ),
    ),

    "tel": Language(
        code="tel",
        name="Telugu",
        native="తెలుగు",
        flores="tel_Telu",
        asr="te",
        tess="tel",
        script="Telugu",
        family="Dravidian",
        branch="South Dravidian II",
        speakers="96 million",
        script_name="Telugu script",
        script_direction="left-to-right",
        unicode_block="U+0C00–U+0C7F",
        romanization="ISO 15919 / ITRANS",
        grammar_type="agglutinative",
        word_order="SOV",
        interesting_facts=(
            "Telugu is sometimes called the 'Italian of the East' because an unusually high proportion "
            "of its native words end in vowels, giving the language a melodic quality.",
            "Telugu has a three-gender system (masculine, feminine, neuter) that also encodes social "
            "rank and animacy, making agreement patterns more complex than in Tamil or Kannada.",
            "Telugu inscriptions from the 7th century CE make it one of the earliest-attested Dravidian "
            "languages in written form; its script evolved from the Brahmi family.",
        ),
        english_description=(
            "Telugu is the most widely spoken Dravidian language and is the official language of the Indian "
            "states of Andhra Pradesh and Telangana. With approximately 96 million native speakers, it ranks "
            "among the top 15 most spoken languages in the world. Telugu belongs to the South-Central "
            "(South Dravidian II) subgroup of the Dravidian family and is closely related to Gondi and Kondh. "
            "Like all Dravidian languages, Telugu is agglutinative and strictly verb-final. Its script, "
            "derived from the southern variety of the ancient Brahmi script, shares many visual features "
            "with the Kannada script and covers the Unicode range U+0C00–U+0C7F."
        ),
    ),

    "kan": Language(
        code="kan",
        name="Kannada",
        native="ಕನ್ನಡ",
        flores="kan_Knda",
        asr="kn",
        tess="kan",
        script="Kannada",
        family="Dravidian",
        branch="South Dravidian I",
        speakers="58 million",
        script_name="Kannada script",
        script_direction="left-to-right",
        unicode_block="U+0C80–U+0CFF",
        romanization="ISO 15919 / Kannada IAST",
        grammar_type="agglutinative",
        word_order="SOV",
        interesting_facts=(
            "The Halmidi inscription (c. 450 CE) is the earliest known Kannada inscription and predates "
            "comparable records in many other Indian languages.",
            "Kannada has absorbed a large number of Sanskrit loanwords (Tatsamas) due to centuries of "
            "literary and courtly use, yet retains a strongly Dravidian grammatical core.",
            "The Kannada script and the Telugu script are sister scripts, both descended from the southern "
            "Brahmi tradition; a skilled reader of one can often recognise letters in the other.",
        ),
        english_description=(
            "Kannada is a Dravidian language spoken mainly in Karnataka, an Indian state whose official "
            "language it is. It has approximately 58 million native speakers and an additional 15 million "
            "who use it as a second language. Kannada belongs to the South Dravidian I subgroup alongside "
            "Tamil and Malayalam, though it has absorbed considerable Sanskrit vocabulary through literary "
            "tradition. The language is agglutinative with SOV word order, and its morphology encodes "
            "three genders, three numbers, and an extensive case system through suffixation. The Kannada "
            "script occupies the Unicode block U+0C80–U+0CFF."
        ),
    ),

    "mal": Language(
        code="mal",
        name="Malayalam",
        native="മലയാളം",
        flores="mal_Mlym",
        asr="ml",
        tess="mal",
        script="Malayalam",
        family="Dravidian",
        branch="South Dravidian I",
        speakers="38 million",
        script_name="Malayalam script",
        script_direction="left-to-right",
        unicode_block="U+0D00–U+0D7F",
        romanization="ISO 15919 / Manglish (informal)",
        grammar_type="agglutinative",
        word_order="SOV",
        interesting_facts=(
            "Malayalam has the highest density of consonant clusters among Dravidian languages, "
            "making gemination (consonant doubling) a systematic grammatical feature.",
            "Malayalam is the official language of Kerala and the union territory of Lakshadweep; "
            "it is closely related to Tamil, sharing a common ancestor in Old Tamil-Malayalam.",
            "The Malayalam script is unique in that it has the largest number of letters among all "
            "Indian scripts, with dedicated glyphs for many consonant clusters.",
        ),
        english_description=(
            "Malayalam is the official language of the Indian state of Kerala and the union territory "
            "of Lakshadweep, with roughly 38 million native speakers. It belongs to the South Dravidian I "
            "subgroup and is the closest living relative of Tamil, sharing significant lexical and "
            "grammatical similarities. Malayalam separated from Tamil around the 9th–13th centuries CE, "
            "developing its own rich script and literary tradition; the earliest known literary text is "
            "the Ramacharitam (c. 13th century). The language is agglutinative with SOV word order, "
            "and is notable for its phonological complexity, including an extensive system of geminate "
            "consonants and retroflex sounds. The Malayalam Unicode block is U+0D00–U+0D7F."
        ),
    ),

    "eng": Language(
        code="eng",
        name="English",
        native="English",
        flores="eng_Latn",
        asr="en",
        tess="eng",
        script="Latin",
        family="Indo-European",
        branch="West Germanic",
        speakers="1.5 billion (L1+L2)",
        script_name="Latin script",
        script_direction="left-to-right",
        unicode_block="U+0000–U+007F (Basic Latin)",
        romanization="N/A",
        grammar_type="analytic (mildly inflectional)",
        word_order="SVO",
        interesting_facts=(
            "English is a West Germanic language that has absorbed enormous numbers of loanwords "
            "from French, Latin, Greek, and many other languages, making it unusually lexically diverse.",
            "English has largely lost its case system (retaining only pronoun cases), relying instead "
            "on word order and prepositions where Dravidian languages use suffixes.",
        ),
        english_description=(
            "English is a West Germanic language originating in medieval England and now the dominant "
            "global lingua franca. It serves as the pivot language for translation in this application, "
            "providing a bridge between Dravidian languages. Unlike Dravidian languages, English is "
            "analytic, using word order and function words rather than extensive suffixation."
        ),
    ),
}

DRAVIDIAN: set[str] = {"tam", "tel", "kan", "mal"}


def get(code: str) -> Language:
    try:
        return LANGUAGES[code]
    except KeyError:
        raise ValueError(f"Unsupported language '{code}'. Supported: {sorted(LANGUAGES)}")


def language_info(code: str) -> dict:
    """Return a serialisable dict of rich metadata for a language."""
    lang = get(code)
    return {
        "code":               lang.code,
        "name":               lang.name,
        "native":             lang.native,
        "family":             lang.family,
        "branch":             lang.branch,
        "speakers":           lang.speakers,
        "script_name":        lang.script_name,
        "script_direction":   lang.script_direction,
        "unicode_block":      lang.unicode_block,
        "romanization":       lang.romanization,
        "grammar_type":       lang.grammar_type,
        "word_order":         lang.word_order,
        "interesting_facts":  list(lang.interesting_facts),
        "english_description": lang.english_description,
    }
