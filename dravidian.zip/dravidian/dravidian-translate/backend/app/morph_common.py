"""Shared building blocks for the per-language morphology modules."""
from __future__ import annotations

from dataclasses import dataclass, field

from . import morph_script as ms

# Gloss tags -> (grammatical role, human-readable feature). Used for the UI badges and for
# the flat ``grammatical_features`` dict. Tags follow the Leipzig glossing conventions.
TAGS: dict[str, tuple[str, str]] = {
    # number / case
    "PL": ("number", "plural"),
    "ACC": ("case", "accusative"),
    "DAT": ("case", "dative"),
    "LOC": ("case", "locative"),
    "ABL": ("case", "ablative"),
    "INS": ("case", "instrumental"),
    "GEN": ("case", "genitive"),
    "SOC": ("case", "sociative"),
    "ALL": ("case", "allative (towards)"),
    "VOC": ("case", "vocative"),
    # tense / aspect
    "PRES": ("tense", "present"),
    "PAST": ("tense", "past"),
    "FUT": ("tense", "future"),
    "PRS.CONT": ("tense", "present continuous"),
    "PRF": ("aspect", "perfect"),
    "PROG": ("aspect", "progressive"),
    # person / number / gender agreement
    "1SG": ("agreement", "1st person singular"),
    "2SG": ("agreement", "2nd person singular"),
    "3SGM": ("agreement", "3rd person singular masculine"),
    "3SGF": ("agreement", "3rd person singular feminine"),
    "3SGH": ("agreement", "3rd person singular honorific"),
    "3SGN": ("agreement", "3rd person singular neuter"),
    "3SG": ("agreement", "3rd person singular"),
    "1PL": ("agreement", "1st person plural"),
    "2PL": ("agreement", "2nd person plural/honorific"),
    "3PL": ("agreement", "3rd person plural"),
    "3PLN": ("agreement", "3rd person plural neuter"),
    "3": ("agreement", "3rd person"),
    # mood / non-finite forms
    "IMP": ("mood", "imperative"),
    "IMP.HON": ("mood", "polite imperative"),
    "HORT": ("mood", "hortative (let us)"),
    "OPT": ("mood", "optative"),
    "COND": ("mood", "conditional"),
    "NEG": ("polarity", "negative"),
    "ABIL": ("modality", "ability / permission"),
    "OBLIG": ("modality", "obligation"),
    "INF": ("form", "infinitive"),
    "VBP": ("form", "verbal participle (conjunctive)"),
    "PTCP": ("form", "relative participle"),
    # derivation / clitics / other
    "ADVZ": ("derivation", "adverbializer"),
    "ADJZ": ("derivation", "adjectivalizer"),
    "NMLZ": ("derivation", "nominalizer"),
    "Q": ("clitic", "question marker"),
    "EMPH": ("clitic", "emphatic / additive"),
    "QUOT": ("clitic", "quotative"),
    "COP": ("copula", "copula (to be)"),
    "AUX": ("auxiliary", "auxiliary verb"),
    "SANDHI": ("euphony", "sandhi consonant (gemination from the next word)"),
    # English
    "PLURAL": ("number", "plural"),
    "3SG.PRES": ("agreement", "3rd person singular present"),
    "PAST.EN": ("tense", "past"),
    "PASTPTCP": ("form", "past participle"),
    "PRESPTCP": ("form", "present participle / gerund"),
    "COMP": ("degree", "comparative"),
    "SUPER": ("degree", "superlative"),
    "POSS": ("case", "possessive"),
    "ADVL": ("derivation", "adverbializer (-ly)"),
}


@dataclass
class Analysis:
    """One morphological analysis of a word form."""
    lemma: str                              # dictionary form (script)
    pos: str
    morphs: list[tuple[str, str]]           # [(phon surface, TAG or "")]; first = stem allomorph
    gloss: str = ""
    features: dict[str, str] = field(default_factory=dict)
    source: str = "lexicon"                 # fixed | lexicon | rule | heuristic
    priority: int = 5                       # lower wins when a form is ambiguous

    def surface_phon(self) -> str:
        return "".join(m for m, _ in self.morphs)


def parse_feats(s: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for part in filter(None, (p.strip() for p in s.split(";"))):
        k, _, v = part.partition("=")
        out[k.strip()] = v.strip()
    return out


def morphs_from_text(text: str, lang: str) -> list[tuple[str, str]]:
    """'இரு க்கிற்:PRES ஏன்:1SG' -> [(phon, tag), ...]"""
    out = []
    for piece in text.split():
        surf, _, tag = piece.partition(":")
        out.append((ms.to_phon(surf, lang), tag))
    return out


def parse_fixed(line: str, lang: str, source: str = "fixed") -> tuple[str, Analysis]:
    """token | lemma | pos | morphs [| feats [| gloss]]  (same layout as the gold files)."""
    p = [x.strip() for x in line.split("|")]
    token, lemma, pos, morphs = p[0], p[1], p[2], p[3]
    feats = parse_feats(p[4]) if len(p) > 4 else {}
    gloss = p[5] if len(p) > 5 else ""
    return ms.to_phon(token, lang), Analysis(lemma, pos, morphs_from_text(morphs, lang),
                                             gloss, feats, source, priority=1)


def lex_lines(block: str) -> list[list[str]]:
    rows = []
    for raw in block.strip().splitlines():
        raw = raw.strip()
        if raw and not raw.startswith("#"):
            rows.append([x.strip() for x in raw.split("|")])
    return rows


def kv(s: str) -> dict[str, str]:
    """'pres=க்கிற் past=ந்த்' -> dict  (space separated key=value)."""
    out = {}
    for part in s.split():
        k, _, v = part.partition("=")
        out[k] = v
    return out


def tag_features(morphs: list[tuple[str, str]]) -> tuple[list[dict], dict[str, str]]:
    """Turn morph tags into the ``suffixes`` list and the flat feature dict."""
    sufs, feats = [], {}
    for _, tag in morphs:
        if not tag or tag in ("",):
            continue
        role, feat = TAGS.get(tag, ("other", tag))
        feats[role] = feat if role not in feats else f"{feats[role]}; {feat}"
        sufs.append({"tag": tag, "gram_role": role, "feature": feat})
    return sufs, feats
