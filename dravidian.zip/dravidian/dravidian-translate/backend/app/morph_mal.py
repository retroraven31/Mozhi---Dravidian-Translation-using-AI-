"""Malayalam morphology: lexicon, paradigm generators, irregular forms, OOV fallback.

Chillu letters (ൻ ർ ൽ ൾ ൺ) are atomic in the script layer; before a vowel-initial suffix they
revert to consonant + virama (സന്തുഷ്ടൻ + ആണ് -> സന്തുഷ്ടന് ആണ്, ഞങ്ങൾ + ഉടെ -> ഞങ്ങള് ഉടെ).
Same architecture as ``morph_tam``; unknown words are flagged ``confidence = heuristic``.
"""
from __future__ import annotations

from . import morph_script as ms
from .morph_common import Analysis, kv, lex_lines
from .morph_gen import drop_final, finish_build, make_P

L = "mal"
P = make_P(L)
ANUSVARA = "ം"
VIR = "്"


def before_vowel(p: str) -> str:
    """Stem allomorph before a vowel-initial suffix: chillu -> C+virama, final -ം -> -മ്."""
    p = ms.unchillu(p)
    if p.endswith(ANUSVARA):
        return p[:-1] + P("മ്")
    return p


def drop_u(p: str) -> str:
    return drop_final(p, L, "ഉ")


# invariant words: word | pos | gloss | feats
WORDS = """
അതെ | particle | 
അത് | pronoun | it | type=demonstrative-distal
അല്ല | verb |  | polarity=negative
അവൻ | pronoun | he | person=3rd;gender=masculine
അവർ | pronoun | they | person=3rd;number=plural
അവൾ | pronoun | she | person=3rd;gender=feminine
ആര് | pronoun | who | type=interrogative
ആശുപത്രി | noun | 
ഇത് | pronoun |  | type=demonstrative-proximal
ഇന്ന് | adverb | 
ഇപ്പോൾ | adverb | 
ഉച്ച | noun | 
എങ്ങനെ | adverb | how | type=interrogative
എന്തുകൊണ്ട് | adverb | why
എന്ത് | pronoun | what | type=interrogative
എപ്പോൾ | adverb | when | type=interrogative
എവിടെ | adverb | where | type=interrogative
ഏത് | determiner |  | type=interrogative
ചന്ദ്രൻ | noun | moon
ചെറിയ | adjective | small
ഞങ്ങൾ | pronoun | we | person=1st;number=plural
ഞാൻ | pronoun | i | person=1st;number=singular
ദയവായി | interjection | 
ദിവസം | noun | day
ദ്രാവിഡ | adjective | 
നഗരം | noun | city
നന്ദി | interjection | 
നമസ്കാരം | interjection | 
നല്ല | adjective | good
നിങ്ങൾ | pronoun | you | person=2nd
പഴയ | adjective | old
പുതിയ | adjective | new
പുസ്തകം | noun | book
പേര് | noun | name
ഭക്ഷണം | noun | food
ഭാഷ | noun | language
മോശം | adjective | bad
രാജ്യം | noun | country
രാത്രി | noun | night
റെയിൽവേ | noun | 
വലിയ | adjective | big
വളരെ | adverb | 
വില | noun | 
വീട് | noun | house
വീണ്ടും | adverb | 
വെള്ളം | noun | water
ശുഭ | adjective | 
ശുഭരാത്രി | interjection | 
സന്ധ്യ | noun | 
സമയം | noun | time
സുപ്രഭാതം | interjection | 
സുഹൃത്ത് | noun | friend
സൂര്യൻ | noun | sun
സ്കൂൾ | noun | school
സ്നേഹം | noun | love
സ്റ്റേഷൻ | noun | 
സ്വാഗതം | interjection | 
"""

# irregular / suppletive / closed-class forms: token | lemma | pos | morphs | feats | gloss
FIXED = """
ഇതിന് | ഇത് | pronoun | ഇത് ഇന്:DAT | type=demonstrative-proximal
എത്രയാണ് | എത്ര | adverb | എത്ര യാണ്:COP
എത്രയായി | എത്ര | adverb | എത്ര യായി:PAST
എനിക്ക് | ഞാൻ | pronoun | എനി ക്ക്:DAT | person=1st;case=dative
എന്താണ് | എന്ത് | pronoun | എന്ത് ആണ്:COP
എന്നെ | ഞാൻ | pronoun | എന്ന് എ:ACC | person=1st;case=accusative
എന്റെ | ഞാൻ | pronoun | എന്റെ | person=1st;case=genitive
എവിടെയാണ് | എവിടെ | adverb | എവിടെ യാണ്:COP
ഞങ്ങളുടെ | ഞങ്ങൾ | pronoun | ഞങ്ങള് ഉടെ:GEN | person=1st;number=plural;case=genitive
തരൂ | തരുക | verb | തര് ഊ:IMP
നിങ്ങളുടെ | നിങ്ങൾ | pronoun | നിങ്ങള് ഉടെ:GEN | person=2nd;case=genitive
നിന്നാണ് | നിന്ന് | postposition | നിന്ന് ആണ്:COP
നിന്നെ | നീ | pronoun | നിന്ന് എ:ACC | person=2nd;case=accusative
പേരെന്താണ് | പേര് | phrase | പേര് എന്താണ്:WORD
മനസ്സിലായി | മനസ്സിലാകുക | verb | മനസ്സില് ആയി:PAST
മനസ്സിലായില്ല | മനസ്സിലാകുക | verb | മനസ്സില് ആയ്:PAST ഇല്ല:NEG
മനോഹരമായ | മനോഹരം | adjective | മനോഹരമ് ആയ:ADJZ
"""

# noun | pos | gloss | class   V = vowel-final, M = final -ം, C = consonant-final (…്),
#                              N = chillu-final, T = -ട്/-റ്-final that doubles before a vowel
NOUNS = """
അഭിനന്ദനം | noun | congratulation | M
ജന്മദിനാശംസ | noun | birthday wish | V
ഭാഷ | noun | language | V
വീട് | noun | house | T
പുസ്തകം | noun | book | M
രാജ്യം | noun | country | M
നഗരം | noun | city | M
ദിവസം | noun | day | M
സമയം | noun | time | M
ഭക്ഷണം | noun | food | M
സ്നേഹം | noun | love | M
സുഖം | noun | well-being | M
ആശുപത്രി | noun | hospital | V
രാത്രി | noun | night | V
സന്ധ്യ | noun | evening | V
വില | noun | price | V
പേര് | noun | name | C
സുഹൃത്ത് | noun | friend | C
നല്ലത് | noun | good thing | C
വെള്ളം | noun | water | M
സന്തുഷ്ടൻ | noun | happy man | N
സൂര്യൻ | noun | sun | N
ചന്ദ്രൻ | noun | moon | N
"""

# verb | gloss | spec ; spec = root+marker ; `pres` takes ഉന്നു, `past` takes marker + ഉ
VERBS = """
ആഗ്രഹിക്കുക | want | pres=ആഗ്രഹിക്ക്+ഉന്നു
സ്നേഹിക്കുക | love | pres=സ്നേഹിക്ക്+ഉന്നു
പോകുക | go | pres=പോക്+ഉന്നു
എങ്ങനെയിരിക്കുക | be how | pres=എങ്ങനെ+യിരിക്ക്+ഉന്നു
കഴിക്കുക | eat | past=കഴി+ച്ചു
കാണുക | see | opt=കാണ്+ആം
ചെയ്യുക | do | ptcp=ചെയ്യ്+ഉന്ന
സഹായിക്കുക | help | opt=സഹായിക്ക്+ആമ് imp=സഹായിക്ക്+ഊ
ശ്രദ്ധിക്കുക | pay attention | imp=ശ്രദ്ധിക്ക്+ഊ
പഠിക്കുക | study | inf=പഠിക്ക്+ആൻ
"""

CASES = [("ഇല്", "LOC"), ("ഉടെ", "GEN"), ("എ", "ACC"), ("ഇന്", "DAT"), ("ഓട്", "SOC")]
Q = P("ഓ")


def _noun_forms(lemma, pos, gloss, cls, flag=""):
    out = []
    Lm = P(lemma)

    def add(morphs, pos_=None):
        out.append(("".join(m for m, _ in morphs), Analysis(lemma, pos_ or pos, morphs, gloss, {}, "lexicon", 5)))

    if cls == "M":
        add([(Lm[:-1], ""), (P("ങ്ങൾ"), "PL")])
        sv = Lm[:-1] + P("മ്")
    elif cls == "N":
        sv = ms.unchillu(Lm)
    elif cls == "T":
        sv = Lm + Lm[-2:]
    else:
        sv = Lm
    if cls in ("V", "C", "T"):
        add([(Lm, ""), (P("കൾ"), "PL")])
    if cls in ("V",):
        for suf, tag in (("യിൽ", "LOC"), ("യുടെ", "GEN"), ("യെ", "ACC")):
            add([(Lm, ""), (P(suf), tag)])
        add([(Lm, ""), (P("യാണ്"), "COP")])
        add([(Lm, ""), (P("യാണ്"), "COP"), (Q, "Q")])
    else:
        for suf, tag in CASES:
            add([(sv, ""), (P(suf), tag)])
        add([(sv, ""), (P("ആണ്"), "COP")])
        add([(sv, ""), (P("ആണ്"), "COP"), (Q, "Q")])
    if cls == "T":
        add([(sv, ""), (P("ഇല്"), "LOC"), (P("ഏക്ക്"), "ALL")])
    return out


def _verb_forms(lemma, gloss, spec):
    out = []

    def mk(morphs):
        return Analysis(lemma, "verb", morphs, gloss, {}, "lexicon", 5)

    def add(morphs, finite=False):
        out.append(("".join(m for m, _ in morphs), mk(morphs)))
        if finite:
            last, tag = morphs[-1]
            last = drop_u(last)
            if last.endswith(ANUSVARA):
                last = last[:-1] + P("മ്")
            q = morphs[:-1] + [(last, tag), (Q, "Q")]
            out.append(("".join(m for m, _ in q), mk(q)))

    def parts(s):
        return [P(x) for x in s.split("+")]

    if "pres" in spec:
        *roots, marker = parts(spec["pres"])
        add([(roots[0], "")] + ([(roots[1], "")] if len(roots) > 1 else []) + [(marker, "PRES")])
    if "past" in spec:
        root, marker = parts(spec["past"])
        add([(root, ""), (marker, "PAST")], True)
    if "opt" in spec:
        root, marker = parts(spec["opt"])
        add([(root, ""), (marker, "OPT")], True)
    if "ptcp" in spec:
        root, marker = parts(spec["ptcp"])
        add([(root, ""), (marker, "PTCP")])
        add([(root, ""), (marker, "PTCP"), (P("ത്"), "NMLZ")])
    if "imp" in spec:
        root, marker = parts(spec["imp"])
        add([(root, ""), (marker, "IMP")])
    if "inf" in spec:
        root, marker = parts(spec["inf"])
        add([(root, ""), (marker, "INF")])
    return out


def build():
    def gen():
        for row in lex_lines(NOUNS):
            yield from _noun_forms(row[0], row[1], row[2], row[3], row[4] if len(row) > 4 else "")
        for row in lex_lines(VERBS):
            yield from _verb_forms(row[0], row[1], kv(row[2]) if len(row) > 2 else {})
    return finish_build(L, WORDS, FIXED, gen())


def heuristic_chains():
    chains = []
    for suf, tag in CASES:
        chains.append((P(suf), [(P(suf), tag)], "noun"))
    for suf in ("കൾ", "ങ്ങൾ"):
        chains.append((P(suf), [(P(suf), "PL")], "noun"))
    chains.append((P("ഉന്നു"), [(P("ഉന്നു"), "PRES")], "verb"))
    chains.append((P("ആണ്"), [(P("ആണ്"), "COP")], "verb"))
    chains.append((P("യാണ്"), [(P("യാണ്"), "COP")], "verb"))
    chains.append((P("ആയ"), [(P("ആയ"), "ADJZ")], "adjective"))
    chains.append((P("ആയി"), [(P("ആയി"), "ADVZ")], "adverb"))
    chains.sort(key=lambda c: -len(c[0]))
    return chains
