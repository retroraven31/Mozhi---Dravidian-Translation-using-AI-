"""Morphological analysis engine for Tamil, Telugu, Kannada, Malayalam and English.

How it works
------------
1. Dravidian words are converted to a phoneme-level form (``morph_script``) so that
   morpheme boundaries can fall *inside* an akshara (வீடு + இல் = வீட்டில்).
2. Each language module (``morph_tam`` ...) holds a lexicon, a paradigm generator and
   a table of irregular forms. Every regular inflected form of every lexicon entry is
   generated and indexed, so analysis is an exact lookup that returns the lemma, part of
   speech, the segmentation and the grammatical tags of each morpheme.
3. A word that is not in the index is analysed by suffix stripping and is reported with
   ``confidence = "heuristic"`` - the analyser never presents a guess as a certainty.

The /api/morph response keeps the original fields (token, stem, pos, suffixes,
grammatical_features, char_breakdown) and adds gloss, segments, morphs, confidence
and alternatives.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any

from . import morph_script as ms
from .morph_common import TAGS, Analysis, tag_features

# ─────────────────────────────────────────────────────────────────────────────
# 1. SCRIPT UNICODE RANGES & SETS (used for the character breakdown / statistics)
# ─────────────────────────────────────────────────────────────────────────────
# 1. SCRIPT UNICODE RANGES & SETS
# ─────────────────────────────────────────────────────────────────────────────
_TAM_VOWELS     = set(range(0x0B85, 0x0B95))
_TAM_CONSONANTS = set(range(0x0B95, 0x0BC0))
_TAM_MATRAS     = set(range(0x0BBE, 0x0BCC + 1))
_TAM_VIRAMA     = {0x0BCD}
_TAM_DIGITS     = set(range(0x0BE6, 0x0BF0))

_TEL_VOWELS     = set(range(0x0C05, 0x0C15))
_TEL_CONSONANTS = set(range(0x0C15, 0x0C40))
_TEL_MATRAS     = set(range(0x0C3E, 0x0C4D))
_TEL_VIRAMA     = {0x0C4D}
_TEL_DIGITS     = set(range(0x0C66, 0x0C70))

_KAN_VOWELS     = set(range(0x0C85, 0x0C95))
_KAN_CONSONANTS = set(range(0x0C95, 0x0CC0))
_KAN_MATRAS     = set(range(0x0CBE, 0x0CCC + 1))
_KAN_VIRAMA     = {0x0CCD}
_KAN_DIGITS     = set(range(0x0CE6, 0x0CF0))

_MAL_VOWELS     = set(range(0x0D05, 0x0D15))
_MAL_CONSONANTS = set(range(0x0D15, 0x0D40))
_MAL_MATRAS     = set(range(0x0D3E, 0x0D4D))
_MAL_VIRAMA     = {0x0D4D}
_MAL_DIGITS     = set(range(0x0D66, 0x0D70))

_SCRIPT_SETS: dict[str, dict[str, set[int]]] = {
    "tam": {"vowel": _TAM_VOWELS, "consonant": _TAM_CONSONANTS, "matra": _TAM_MATRAS, "virama": _TAM_VIRAMA, "digit": _TAM_DIGITS},
    "tel": {"vowel": _TEL_VOWELS, "consonant": _TEL_CONSONANTS, "matra": _TEL_MATRAS, "virama": _TEL_VIRAMA, "digit": _TEL_DIGITS},
    "kan": {"vowel": _KAN_VOWELS, "consonant": _KAN_CONSONANTS, "matra": _KAN_MATRAS, "virama": _KAN_VIRAMA, "digit": _KAN_DIGITS},
    "mal": {"vowel": _MAL_VOWELS, "consonant": _MAL_CONSONANTS, "matra": _MAL_MATRAS, "virama": _MAL_VIRAMA, "digit": _MAL_DIGITS},
    "eng": {
        "vowel": {ord(c) for c in "aeiouAEIOU"},
        "consonant": {ord(c) for c in "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"},
        "matra": set(),
        "virama": set(),
        "digit": {ord(c) for c in "0123456789"}
    },
}

def _char_script_category(ch: str, lang: str) -> str:
    cp = ord(ch)
    sets = _SCRIPT_SETS.get(lang, {})
    for cat, s in sets.items():
        if cp in s:
            return cat
    if ch.isspace():
        return "space"
    if ch.isdigit():
        return "ascii_digit"
    if ch.isalpha() and ord(ch) < 128:
        if ch.lower() in "aeiou":
            return "vowel"
        return "consonant"
    ucat = unicodedata.category(ch)
    if ucat.startswith("P"):
        return "punctuation"
    if ucat.startswith("S"):
        return "symbol"
    return "other"

def _char_info(ch: str, lang: str) -> dict[str, Any]:
    cp = ord(ch)
    try:
        name = unicodedata.name(ch)
    except ValueError:
        name = "UNKNOWN"
    return {
        "char": ch,
        "codepoint": f"U+{cp:04X}",
        "codepoint_int": cp,
        "unicode_name": name,
        "script_category": _char_script_category(ch, lang),
    }


# ─────────────────────────────────────────────────────────────────────────────
# 2. LANGUAGE MODULES
# ─────────────────────────────────────────────────────────────────────────────
def _module(lang: str):
    if lang == "tam":
        from . import morph_tam as m
    elif lang == "tel":
        from . import morph_tel as m
    elif lang == "kan":
        from . import morph_kan as m
    elif lang == "mal":
        from . import morph_mal as m
    else:
        raise ValueError(lang)
    return m


@lru_cache(maxsize=None)
def _index(lang: str) -> dict[str, list[Analysis]]:
    idx = _module(lang).build()
    for forms in idx.values():
        forms.sort(key=lambda a: a.priority)
    return idx


@lru_cache(maxsize=None)
def _chains(lang: str):
    return _module(lang).heuristic_chains()


SUPPORTED = ("tam", "tel", "kan", "mal", "eng")
_SANDHI_CONS = {"tam": "கசதப", "tel": "కచతప", "kan": "ಕಚತಪ", "mal": "കചതപ"}


# ─────────────────────────────────────────────────────────────────────────────
# 3. TOKENISATION
# ─────────────────────────────────────────────────────────────────────────────
_STRIP = ".,!?;:\"'()[]{}…।॥—–-“”‘’"


def _tokenise(text: str) -> list[str]:
    tokens = []
    for tok in re.split(r"\s+", text.strip()):
        tok = tok.strip(_STRIP)
        if tok:
            tokens.append(tok)
    return tokens


# ─────────────────────────────────────────────────────────────────────────────
# 4. WORD ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────
def _heuristic(phon: str, lang: str) -> Analysis | None:
    """Suffix stripping for words that are not in the lexicon (flagged as a guess)."""
    for suffix, morphs, pos in _chains(lang):
        if phon.endswith(suffix) and len(phon) - len(suffix) >= 4:
            stem = phon[: -len(suffix)]
            lemma = ms.from_phon(stem, lang)
            return Analysis(lemma, pos, [(stem, "")] + morphs, "", {}, "heuristic", 9)
    return None


def _lookup(phon: str, lang: str) -> list[Analysis]:
    return _index(lang).get(phon, [])


def _analyse_dravidian(token: str, lang: str) -> list[Analysis]:
    phon = ms.to_phon(token, lang)
    found = _lookup(phon, lang)
    if found:
        return found
    # trailing sandhi consonant (word-final gemination copied from the next word's initial)
    vir = ms.virama(lang)
    if len(phon) > 3 and phon[-1] == vir and phon[-2] in _SANDHI_CONS[lang]:
        base = _lookup(phon[:-2], lang)
        if base:
            out = []
            for a in base:
                out.append(Analysis(a.lemma, a.pos, a.morphs + [(phon[-2:], "SANDHI")], a.gloss,
                                    dict(a.features), a.source, a.priority + 1))
            return out
    h = _heuristic(phon, lang)
    if h:
        return [h]
    return [Analysis(token, "noun", [(phon, "")], "", {}, "heuristic", 10)]


def _foreign_or_number(token: str) -> Analysis | None:
    if token.replace(",", "").replace(".", "").isdigit() or all(ch.isdigit() for ch in token):
        return Analysis(token, "numeral", [(token, "")], "number", {}, "fixed", 1)
    return None


def _render(token: str, lang: str, analyses: list[Analysis]) -> dict[str, Any]:
    best = analyses[0]
    is_drav = lang != "eng"

    def show(p: str) -> str:
        return ms.from_phon(p, lang) if is_drav else p

    sufs_tags, tag_feats = tag_features(best.morphs[1:] if len(best.morphs) > 1 else [])
    morph_rows = []
    for i, (surf, tag) in enumerate(best.morphs):
        role, feat = TAGS.get(tag, ("", "")) if tag else ("", "")
        morph_rows.append({
            "text": show(surf),
            "tag": tag or ("root" if i == 0 else ""),
            "role": role or ("root" if i == 0 else ""),
            "feature": feat,
        })
    suffixes = []
    for (surf, tag), s in zip([m for m in best.morphs[1:] if m[1]], sufs_tags):
        suffixes.append({"suffix": show(surf), "tag": tag, "gram_role": s["gram_role"],
                         "feature": s["feature"]})
    feats = dict(best.features)
    feats.update(tag_feats)
    alts = []
    seen = {(best.lemma, best.pos, tuple(best.morphs))}
    for a in analyses[1:4]:
        key = (a.lemma, a.pos, tuple(a.morphs))
        if key in seen:
            continue
        seen.add(key)
        alts.append({"stem": a.lemma, "pos": a.pos, "segments": [show(m) for m, _ in a.morphs]})
    return {
        "token": token,
        "stem": best.lemma,
        "pos": best.pos,
        "gloss": best.gloss,
        "segments": [r["text"] for r in morph_rows],
        "morphs": morph_rows,
        "suffixes": suffixes,
        "grammatical_features": feats,
        "confidence": "heuristic" if best.source == "heuristic" else "exact",
        "alternatives": alts,
        "char_breakdown": [_char_info(ch, lang) for ch in token],
    }


def analyse_token(token: str, lang: str, prev: str | None = None, nxt: str | None = None) -> dict[str, Any]:
    """Analyse one word and return the JSON-ready record.

    ``prev`` / ``nxt`` are the neighbouring words; they are only used to choose between
    English homographs (love/help/this/no) and never change Dravidian analyses.
    """
    num = _foreign_or_number(token)
    if num:
        return _render(token, lang, [num])
    if lang == "eng":
        from . import morph_eng
        readings = morph_eng.analyse(token)
        readings = morph_eng.disambiguate(readings, prev, nxt, token.lower())
        return _render(token, lang, readings)
    if token.isascii() and any(c.isalpha() for c in token):
        # Latin-script word inside Dravidian text (loan word / name / typo): do not guess.
        a = Analysis(token, "foreign", [(token, "")], "Latin-script word", {}, "fixed", 1)
        r = _render(token, lang, [a])
        r["char_breakdown"] = [_char_info(ch, "eng") for ch in token]
        return r
    return _render(token, lang, _analyse_dravidian(unicodedata.normalize("NFC", token), lang))

# 4. SCRIPT STATISTICS & METADATA
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class ScriptStats:
    total_chars: int = 0
    vowels: int = 0
    consonants: int = 0
    matras: int = 0
    viramas: int = 0
    digits: int = 0
    spaces: int = 0
    latin: int = 0
    punctuation: int = 0
    other: int = 0

def _compute_script_stats(text: str, lang: str) -> ScriptStats:
    st = ScriptStats()
    for ch in text:
        st.total_chars += 1
        cat = _char_script_category(ch, lang)
        if cat == "vowel":          st.vowels      += 1
        elif cat == "consonant":    st.consonants  += 1
        elif cat == "matra":        st.matras      += 1
        elif cat == "virama":       st.viramas     += 1
        elif cat in ("digit", "ascii_digit"): st.digits += 1
        elif cat == "space":        st.spaces      += 1
        elif cat == "latin":        st.latin       += 1
        elif cat == "punctuation":  st.punctuation += 1
        else:                       st.other       += 1
    return st

_LANG_FAMILY: dict[str, dict[str, Any]] = {
    "tam": {
        "family":          "Dravidian",
        "branch":          "South Dravidian I",
        "proto_root":      "Proto-South Dravidian",
        "oldest_attested": "3rd century BCE (Sangam literature)",
        "typology":        "Agglutinative, SOV, head-final",
        "notable_feature": "Diglossia (classical vs. colloquial registers); retroflex consonants",
    },
    "tel": {
        "family":          "Dravidian",
        "branch":          "South Dravidian II",
        "proto_root":      "Proto-South Dravidian",
        "oldest_attested": "7th century CE inscriptions",
        "typology":        "Agglutinative, SOV, head-final",
        "notable_feature": "Three-gender system (masculine/feminine/neuter); rich verbal morphology",
    },
    "kan": {
        "family":          "Dravidian",
        "branch":          "South Dravidian I",
        "proto_root":      "Proto-South Dravidian",
        "oldest_attested": "5th–6th century CE (Halmidi inscription)",
        "typology":        "Agglutinative, SOV, head-final",
        "notable_feature": "Shared script features with Telugu; extensive Tatsama borrowings from Sanskrit",
    },
    "mal": {
        "family":          "Dravidian",
        "branch":          "South Dravidian I",
        "proto_root":      "Proto-South Dravidian",
        "oldest_attested": "13th century CE (Ramacharitam)",
        "typology":        "Agglutinative, SOV, head-final",
        "notable_feature": "Extensive gemination; rich system of noun inflection; closest relative of Tamil",
    },
    "eng": {
        "family":          "Indo-European",
        "branch":          "Germanic",
        "proto_root":      "Proto-Germanic",
        "oldest_attested": "5th century CE (Old English runic inscriptions)",
        "typology":        "Analytic / Fusional, SVO, head-initial",
        "notable_feature": "Rigid SVO syntax contrasting with the agglutinative SOV structure of Dravidian languages",
    },
}

@dataclass
class MorphResult:
    tokens: list[dict[str, Any]]
    script_stats: dict[str, Any]
    lang_info: dict[str, Any]
    agglutination_score: float
    summary: str

# ─────────────────────────────────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────────
# 5. MAIN ANALYSIS PIPELINE
# ─────────────────────────────────────────────────────────────────────────────
def analyse(text: str, lang: str) -> MorphResult:
    if lang not in SUPPORTED:
        raise ValueError(f"Language '{lang}' is not supported. Supported: {sorted(SUPPORTED)}")

    tokens = _tokenise(text)
    total_tokens = len(tokens)
    token_results = [
        analyse_token(tok, lang,
                      tokens[i - 1] if i > 0 else None,
                      tokens[i + 1] if i + 1 < total_tokens else None)
        for i, tok in enumerate(tokens)
    ]
    tokens_with_suffixes = sum(1 for t in token_results if t["suffixes"])

    ss = _compute_script_stats(text, lang)
    script_stats = {
        "total_chars": ss.total_chars,
        "vowels": ss.vowels,
        "consonants": ss.consonants,
        "matras": ss.matras,
        "viramas": ss.viramas,
        "digits": ss.digits,
        "spaces": ss.spaces,
        "latin": ss.latin,
        "punctuation": ss.punctuation,
        "other": ss.other,
        "char_breakdown": [_char_info(ch, lang) for ch in text if not ch.isspace()],
    }

    agg_score = (tokens_with_suffixes / total_tokens) if total_tokens else 0.0
    lang_info = _LANG_FAMILY.get(lang, {})

    lang_names = {"tam": "Tamil", "tel": "Telugu", "kan": "Kannada", "mal": "Malayalam", "eng": "English"}
    pos_counts: dict[str, int] = {}
    for t in token_results:
        pos_counts[t["pos"]] = pos_counts.get(t["pos"], 0) + 1
    pos_summary = ", ".join(f"{cnt} {p}(s)" for p, cnt in sorted(pos_counts.items()))
    guessed = sum(1 for t in token_results if t["confidence"] == "heuristic")

    parts = [
        f"Analysed {total_tokens} token(s) in {lang_names.get(lang, lang)} ({pos_summary}).",
        f"Agglutination score: {agg_score:.0%} of tokens carry morphological affixes.",
        f"Typology: {lang_info.get('typology', 'agglutinative')} "
        f"({lang_info.get('family', 'Dravidian')} family, {lang_info.get('branch', '')} branch).",
    ]
    if guessed:
        parts.append(f"{guessed} token(s) are not in the lexicon and were analysed heuristically "
                     f"(marked 'guess').")

    return MorphResult(
        tokens=token_results,
        script_stats=script_stats,
        lang_info=lang_info,
        agglutination_score=round(agg_score, 4),
        summary=" ".join(parts),
    )
