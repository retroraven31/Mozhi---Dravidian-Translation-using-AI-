"""Audio helpers. ASR needs 16 kHz mono float PCM.

Decoding strategy (first that works wins), so a missing ``ffmpeg`` binary - the cause of
``[WinError 2] The system cannot find the file specified`` on Windows - never reaches the user:

1. RIFF/WAV  -> decoded in pure Python (``wave`` + numpy). The web app uploads WAV, so the
   normal recording path needs no external tool at all.
2. ``ffmpeg`` on PATH (webm/opus, mp4/aac, ogg, mp3 ...).
3. ``imageio-ffmpeg`` - a pip package that bundles an ffmpeg binary.
4. PyAV (``av``) - ffmpeg libraries as a wheel.

If none can decode the data, ``DecoderUnavailable`` carries a human-readable fix.
"""
from __future__ import annotations

import io
import shutil
import subprocess
import wave

import numpy as np

TARGET_RATE = 16000


class AudioDecodeError(ValueError):
    """The bytes are not decodable audio (corrupt, empty, unsupported)."""


class DecoderUnavailable(AudioDecodeError):
    """The data needs a decoder that is not installed on this machine."""


INSTALL_HINT = (
    "This audio format needs ffmpeg to decode, and ffmpeg was not found on the server. "
    "Fix: run `pip install imageio-ffmpeg` (no admin rights needed) or install ffmpeg and add it "
    "to PATH. WAV recordings work without it."
)


# ── helpers ──────────────────────────────────────────────────────────────────────
def _resample(x: np.ndarray, src_rate: int) -> np.ndarray:
    if src_rate == TARGET_RATE or x.size == 0:
        return x.astype(np.float32, copy=False)
    n_out = max(1, int(round(x.size * TARGET_RATE / src_rate)))
    t_out = np.linspace(0, x.size - 1, n_out)
    return np.interp(t_out, np.arange(x.size), x).astype(np.float32)


def _is_wav(data: bytes) -> bool:
    return len(data) > 12 and data[:4] == b"RIFF" and data[8:12] == b"WAVE"


def _decode_wav(data: bytes) -> np.ndarray:
    try:
        with wave.open(io.BytesIO(data), "rb") as w:
            ch, width, rate, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
            raw = w.readframes(n)
    except (wave.Error, EOFError) as e:
        raise AudioDecodeError(f"Not a valid WAV file ({e}).") from e
    if width == 1:
        x = (np.frombuffer(raw, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
    elif width == 2:
        x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    elif width == 3:
        b = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3).astype(np.int32)
        v = b[:, 0] | (b[:, 1] << 8) | (b[:, 2] << 16)
        v = np.where(v & 0x800000, v - 0x1000000, v)
        x = v.astype(np.float32) / 8388608.0
    elif width == 4:
        x = np.frombuffer(raw, dtype=np.int32).astype(np.float32) / 2147483648.0
    else:
        raise AudioDecodeError(f"Unsupported WAV sample width: {width} bytes.")
    if ch > 1:
        x = x[: x.size - x.size % ch].reshape(-1, ch).mean(axis=1)
    return _resample(x, rate)


def _ffmpeg_candidates() -> list[str]:
    found = []
    path = shutil.which("ffmpeg")
    if path:
        found.append(path)
    try:  # bundled binary from the imageio-ffmpeg wheel
        import imageio_ffmpeg
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        if exe and exe not in found:
            found.append(exe)
    except Exception:  # not installed / no binary for this platform
        pass
    return found


def _decode_with_ffmpeg(exe: str, data: bytes) -> np.ndarray:
    proc = subprocess.run(
        [exe, "-v", "error", "-i", "pipe:0", "-f", "s16le", "-ac", "1", "-ar", str(TARGET_RATE), "pipe:1"],
        input=data, capture_output=True, timeout=60,
    )
    if proc.returncode != 0 or not proc.stdout:
        raise AudioDecodeError("Could not decode audio: " + proc.stderr.decode(errors="ignore")[:200])
    return np.frombuffer(proc.stdout, dtype=np.int16).astype(np.float32) / 32768.0


def _decode_with_pyav(data: bytes) -> np.ndarray:
    import av  # type: ignore
    chunks = []
    with av.open(io.BytesIO(data)) as container:
        stream = next((s for s in container.streams if s.type == "audio"), None)
        if stream is None:
            raise AudioDecodeError("No audio track found.")
        resampler = av.AudioResampler(format="s16", layout="mono", rate=TARGET_RATE)
        for frame in container.decode(stream):
            for out in resampler.resample(frame) or []:
                chunks.append(out.to_ndarray().reshape(-1))
    if not chunks:
        raise AudioDecodeError("Audio track is empty.")
    return np.concatenate(chunks).astype(np.float32) / 32768.0


# ── public API ───────────────────────────────────────────────────────────────────
def to_pcm16k(data: bytes) -> np.ndarray:
    """Decode audio bytes to float32 mono at 16 kHz in [-1, 1]. Raises AudioDecodeError."""
    if not data:
        raise AudioDecodeError("The audio upload is empty.")
    if _is_wav(data):
        return _decode_wav(data)

    last_error: Exception | None = None
    for exe in _ffmpeg_candidates():
        try:
            return _decode_with_ffmpeg(exe, data)
        except (OSError, subprocess.SubprocessError, AudioDecodeError) as e:
            last_error = e            # e.g. WinError 2 / permission problems: try the next decoder
    try:
        return _decode_with_pyav(data)
    except ImportError:
        pass
    except AudioDecodeError as e:
        last_error = e
    except Exception as e:  # av.error.* etc.
        last_error = AudioDecodeError(f"Could not decode audio: {e}")

    if isinstance(last_error, AudioDecodeError) and not isinstance(last_error, DecoderUnavailable):
        raise last_error              # a decoder ran but the data was bad
    raise DecoderUnavailable(INSTALL_HINT)


def to_wav_bytes(samples: np.ndarray, sample_rate: int) -> bytes:
    pcm = (np.clip(samples, -1, 1) * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()
