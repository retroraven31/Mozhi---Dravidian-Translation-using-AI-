"""AI4Bharat IndicConformer multilingual ASR (CTC decoding)."""
import threading

import numpy as np

from .. import config, languages
from .device import pick_device


class IndicConformerAsr:
    def __init__(self):
        self._model = None
        self._lock = threading.Lock()
        self._device = pick_device()

    def _load(self):
        with self._lock:
            if self._model is None:
                from transformers import AutoModel
                self._model = AutoModel.from_pretrained(
                    config.ASR_MODEL, trust_remote_code=True
                ).to(self._device)
            return self._model

    def transcribe(self, samples: np.ndarray, lang: str) -> str:
        import torch

        model = self._load()
        wav = torch.from_numpy(samples).unsqueeze(0).to(self._device)  # [1, T], 16 kHz mono
        text = model(wav, languages.get(lang).asr, "ctc")
        return str(text).strip()
