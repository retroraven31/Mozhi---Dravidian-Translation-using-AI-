"""AI4Bharat Indic Parler-TTS. Speaker/style is controlled by a text description."""
import threading

from .. import config
from .base import TtsResult
from .device import pick_device

DESCRIPTION = ("A female speaker delivers a clear, moderately paced speech "
               "with a neutral tone and very clear audio, recorded in a quiet room.")


class IndicParlerTts:
    def __init__(self):
        self._state = None
        self._lock = threading.Lock()
        self._device = pick_device()

    def _load(self):
        with self._lock:
            if self._state is None:
                from parler_tts import ParlerTTSForConditionalGeneration
                from transformers import AutoTokenizer

                model = ParlerTTSForConditionalGeneration.from_pretrained(config.TTS_MODEL).to(self._device)
                tok = AutoTokenizer.from_pretrained(config.TTS_MODEL)
                desc_tok = AutoTokenizer.from_pretrained(model.config.text_encoder._name_or_path)
                self._state = (model, tok, desc_tok)
            return self._state

    def speak(self, text: str, lang: str) -> TtsResult:
        model, tok, desc_tok = self._load()
        d = desc_tok(DESCRIPTION, return_tensors="pt").to(self._device)
        p = tok(text, return_tensors="pt").to(self._device)
        gen = model.generate(input_ids=d.input_ids, attention_mask=d.attention_mask,
                             prompt_input_ids=p.input_ids, prompt_attention_mask=p.attention_mask)
        return TtsResult(samples=gen.cpu().numpy().squeeze().astype("float32"),
                         sample_rate=model.config.sampling_rate)
