"""Tesseract OCR with OpenCV preprocessing.

Quality note: works well on printed, high-contrast text (signboards, documents).
It is weak on handwriting, stylised fonts and low-light photos, so the UI lets
the user correct the recognised text before translating.
"""
import io

import cv2
import numpy as np
import pytesseract
from PIL import Image, ImageOps

from .. import languages
from .base import OcrResult

ALL_LANGS = "+".join(languages.get(c).tess for c in ("tam", "tel", "kan", "mal", "eng"))


def preprocess(image_bytes: bytes) -> np.ndarray:
    img = ImageOps.exif_transpose(Image.open(io.BytesIO(image_bytes))).convert("L")
    arr = np.array(img)
    h, w = arr.shape
    if max(h, w) < 1500:  # small text: upscale so glyph detail survives
        scale = 1500 / max(h, w)
        arr = cv2.resize(arr, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    arr = cv2.fastNlMeansDenoising(arr, None, h=10)
    return cv2.adaptiveThreshold(arr, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                 cv2.THRESH_BINARY, 31, 15)


class TesseractOcr:
    def read(self, image_bytes: bytes, lang: str | None) -> OcrResult:
        tess_lang = f"{languages.get(lang).tess}+eng" if lang and lang != "eng" else (
            "eng" if lang == "eng" else ALL_LANGS)
        img = preprocess(image_bytes)
        data = pytesseract.image_to_data(img, lang=tess_lang, config="--psm 6",
                                         output_type=pytesseract.Output.DICT)
        words, confs, lines = [], [], {}
        for i, word in enumerate(data["text"]):
            if not word.strip():
                continue
            conf = float(data["conf"][i])
            if conf < 0:
                continue
            key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
            lines.setdefault(key, []).append(word)
            confs.append(conf)
        text = "\n".join(" ".join(ws) for _, ws in sorted(lines.items()))
        return OcrResult(text=text.strip(), confidence=round(float(np.mean(confs)), 1) if confs else 0.0)
