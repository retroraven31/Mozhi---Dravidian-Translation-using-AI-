"""IndicTrans2 translator (AI4Bharat). Models load lazily, one per direction.

Directions:
  Dravidian -> English   : indic-en  model
  English   -> Dravidian : en-indic  model
  Dravidian -> Dravidian : indic-indic model (direct, no English pivot)
"""
import threading

from .. import config, languages
from .device import pick_device


class IndicTrans2Translator:
    def __init__(self):
        self._models = {}
        self._lock = threading.Lock()
        self._device = pick_device()
        self._processor = None

    def _direction(self, src: str, tgt: str) -> tuple[str, str]:
        if src == "eng":
            return "en-indic", config.MT_EN_INDIC
        if tgt == "eng":
            return "indic-en", config.MT_INDIC_EN
        return "indic-indic", config.MT_INDIC_INDIC

    def _load(self, key: str, model_id: str):
        with self._lock:
            if key not in self._models:
                import torch
                from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

                tok = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
                model = AutoModelForSeq2SeqLM.from_pretrained(
                    model_id, trust_remote_code=True,
                    torch_dtype=torch.float16 if self._device == "cuda" else torch.float32,
                ).to(self._device).eval()
                self._models[key] = (tok, model)
            if self._processor is None:
                from IndicTransToolkit.processor import IndicProcessor
                self._processor = IndicProcessor(inference=True)
            return self._models[key]

    def translate(self, sentences: list[str], src: str, tgt: str) -> list[str]:
        import torch

        key, model_id = self._direction(src, tgt)
        tok, model = self._load(key, model_id)
        src_f, tgt_f = languages.get(src).flores, languages.get(tgt).flores

        out: list[str] = []
        for i in range(0, len(sentences), 8):  # small batches keep CPU memory low
            batch = self._processor.preprocess_batch(sentences[i:i + 8], src_lang=src_f, tgt_lang=tgt_f)
            inputs = tok(batch, truncation=True, padding="longest",
                         return_tensors="pt", return_attention_mask=True).to(self._device)
            with torch.no_grad():
                gen = model.generate(**inputs, use_cache=True, min_length=0,
                                     max_length=256, num_beams=config.NUM_BEAMS,
                                     num_return_sequences=1)
            decoded = tok.batch_decode(gen.detach().cpu().tolist(),
                                       skip_special_tokens=True,
                                       clean_up_tokenization_spaces=True)
            out.extend(self._processor.postprocess_batch(decoded, lang=tgt_f))
        return out
