from .. import config


def pick_device() -> str:
    if config.DEVICE != "auto":
        return config.DEVICE
    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"
