"""Engine interfaces. The API only depends on these, so engines are swappable."""
from dataclasses import dataclass
from typing import Protocol

import numpy as np


@dataclass
class OcrResult:
    text: str
    confidence: float  # 0-100, mean word confidence reported by the engine


@dataclass
class TtsResult:
    samples: np.ndarray
    sample_rate: int


class Translator(Protocol):
    def translate(self, sentences: list[str], src: str, tgt: str) -> list[str]: ...


class Asr(Protocol):
    def transcribe(self, samples: np.ndarray, lang: str) -> str: ...


class Ocr(Protocol):
    def read(self, image_bytes: bytes, lang: str | None) -> OcrResult: ...


class Tts(Protocol):
    def speak(self, text: str, lang: str) -> TtsResult: ...
