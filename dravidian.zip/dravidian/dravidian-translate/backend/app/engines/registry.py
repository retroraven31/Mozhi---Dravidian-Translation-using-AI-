"""Builds engines once. Real engines import heavy deps lazily on first use."""
from functools import lru_cache

from .. import config


@lru_cache
def translator():
    if config.ENGINE_MODE == "mock":
        from .mock import MockTranslator
        return MockTranslator()
    from .translate import IndicTrans2Translator
    return IndicTrans2Translator()


@lru_cache
def asr():
    if config.ENGINE_MODE == "mock":
        from .mock import MockAsr
        return MockAsr()
    from .asr import IndicConformerAsr
    return IndicConformerAsr()


@lru_cache
def ocr():
    if config.ENGINE_MODE == "mock":
        from .mock import MockOcr
        return MockOcr()
    from .ocr import TesseractOcr
    return TesseractOcr()


@lru_cache
def tts():
    if config.ENGINE_MODE == "mock":
        from .mock import MockTts
        return MockTts()
    from .tts import IndicParlerTts
    return IndicParlerTts()
