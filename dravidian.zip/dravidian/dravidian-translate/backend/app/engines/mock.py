"""Deterministic and Knowledge-Dataset-backed engines for instant, high-accuracy
testing, demos, and conversational translations without heavy model downloads.
"""
import numpy as np
from .base import OcrResult, TtsResult
from .. import knowledge_dataset


class MockTranslator:
    def translate(self, sentences, src, tgt):
        results = []
        for s in sentences:
            translated = knowledge_dataset.translate_phrase(s, src, tgt)
            if translated:
                results.append(translated)
            else:
                # Word-level fallback translation
                words = s.split()
                translated_words = []
                for w in words:
                    cw = knowledge_dataset._clean_str(w)
                    if cw in knowledge_dataset.LEXICON and tgt in knowledge_dataset.LEXICON[cw]:
                        translated_words.append(knowledge_dataset.LEXICON[cw][tgt])
                    else:
                        translated_words.append(w)
                
                if translated_words != words:
                    results.append(" ".join(translated_words))
                else:
                    results.append(f"[{src}->{tgt}] {s}")
        return results


class MockAsr:
    def transcribe(self, samples, lang):
        return f"(mock transcript, {len(samples) / 16000:.1f}s, lang={lang})"


class MockOcr:
    def read(self, image_bytes, lang):
        return OcrResult(text=f"(mock ocr, {len(image_bytes)} bytes, lang={lang})", confidence=50.0)


class MockTts:
    def speak(self, text, lang):
        sr = 16000
        t = np.linspace(0, 0.4, int(sr * 0.4), endpoint=False)
        return TtsResult(samples=(0.2 * np.sin(2 * np.pi * 440 * t)).astype(np.float32), sample_rate=sr)

