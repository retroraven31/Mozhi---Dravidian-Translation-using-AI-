"""Telugu morphology: lexicon, paradigm generators, irregular forms, OOV fallback.

Same architecture as ``morph_tam``: regular forms are generated from the lexicon and indexed
by surface form; irregular, pronominal and compound forms are listed in FIXED; unknown words
fall back to suffix chains and are flagged ``confidence = heuristic``.
"""
from __future__ import annotations

from .morph_common import Analysis, kv, lex_lines
from .morph_gen import drop_final, finish_build, make_P, with_question

L = "tel"
P = make_P(L)


def drop_u(p: str) -> str:
    return drop_final(p, L, "ఉ")


# invariant words: word | pos | gloss | feats
WORDS = """
అతను | pronoun | he | person=3rd;gender=masculine
అది | pronoun | it | type=demonstrative-distal
అర్థం | noun | 
అవును | particle | 
ఆమె | pronoun | she | person=3rd;gender=feminine
ఆసుపత్రి | noun | 
ఆహారం | noun | food
ఇది | pronoun |  | type=demonstrative-proximal
ఇప్పుడు | adverb | 
ఇల్లు | noun | house
ఈరోజు | adverb | 
ఊరు | noun | 
ఎంత | adverb |  | type=interrogative
ఎందుకు | adverb | why | type=interrogative
ఎక్కడ | adverb | where | type=interrogative
ఎప్పుడు | adverb | when | type=interrogative
ఎలా | adverb | how | type=interrogative
ఎవరు | pronoun | who | type=interrogative
ఏ | determiner |  | type=interrogative
ఏమి | pronoun |  | type=interrogative
ఏమిటి | pronoun | what | type=interrogative
కాదు | verb |  | polarity=negative
కొత్త | adjective | new
చంద్రుడు | noun | moon
చాలా | adverb | 
చిన్న | adjective | small
చెడు | adjective | bad
దయచేసి | interjection | 
దేశం | noun | country
ద్రావిడ | adjective | 
ధన్యవాదాలు | interjection | 
ధర | noun | 
నగరం | noun | city
నమస్కారం | interjection | 
నీరు | noun | water
నేను | pronoun | i | person=1st;number=singular
పాఠశాల | noun | school
పాత | adjective | old
పుట్టినరోజు | noun | 
పుస్తకం | noun | book
పెద్ద | adjective | big
పేరు | noun | name
ప్రేమ | noun | love
భాష | noun | language
మంచి | adjective | good
మధ్యాహ్నం | noun | 
మళ్ళీ | adverb | 
మీరు | pronoun | you | person=2nd
మేము | pronoun | we | person=1st;number=plural
రాత్రి | noun | night
రైల్వే | noun | 
రోజు | noun | day
వారు | pronoun | they | person=3rd;number=plural
శుభ | adjective | 
శుభరాత్రి | interjection | 
శుభోదయం | interjection | 
సమయం | noun | time
సహాయం | noun | 
సాయంత్రం | noun | 
సూర్యుడు | noun | sun
స్టేషన్ | noun | 
స్నేహితుడు | noun | friend
స్వాగతం | interjection | 
"""

# irregular / suppletive / closed-class forms: token | lemma | pos | morphs | feats | gloss
FIXED = """
అర్థమైంది | అర్థమవు | verb | అర్థమ్ ఐ:PAST ంది:3SGN
ఇంటికి | ఇల్లు | noun | ఇంటి కి:DAT
ఉన్నాను | ఉండు | verb | ఉన్న్ ఆను:1SG | tense=present
ఉన్నారు | ఉండు | verb | ఉన్న్ ఆరు:2/3PL | tense=present
ఎక్కడికి | ఎక్కడ | adverb | ఎక్కడి కి:DAT
కాలేదు | అవు | verb | కా లేదు:NEG
దీని | ఇది | pronoun | దీని | type=demonstrative-proximal;case=genitive
నా | నేను | pronoun | నా | person=1st;case=genitive
నాకు | నేను | pronoun | నా కు:DAT | person=1st;case=dative
నిన్ను | నీవు | pronoun | నిన్ ను:ACC | person=2nd
నీళ్ళు | నీరు | noun | నీళ్ళు | number=plural
నేర్చుకోవాలనుకుంటున్నాను | నేర్చుకోవాలనుకో | verb | నేర్చుకో వాల్:OBLIG అనుకుంటున్న్:AUX ఆను:1SG
పేరేమిటి | పేరు | phrase | పేర్ ఏమిటి:WORD
మా | మేము | pronoun | మా | person=1st;number=plural;case=genitive
మీ | మీరు | pronoun | మీ | person=2nd;case=genitive
మీది | మీరు | pronoun | మీ ది:NMLZ | person=2nd
"""

# noun | pos | gloss | class   (V = vowel-final, M = final -ం)
NOUNS = """
అభినందన | noun | congratulation | V
శుభాకాంక్ష | noun | good wish | V
భాష | noun | language | V
ఆసుపత్రి | noun | hospital | V
పాఠశాల | noun | school | V
రాత్రి | noun | night | V
ధర | noun | price | V
ప్రేమ | noun | love | V
పుస్తకం | noun | book | M
దేశం | noun | country | M
నగరం | noun | city | M
సమయం | noun | time | M
సహాయం | noun | help | M
జాగ్రత్త | noun | care | V | adv
సంతోషం | noun | happiness | M | adv
అందం | noun | beauty | M | adj
ఆహారం | noun | food | M
సాయంత్రం | noun | evening | M
మధ్యాహ్నం | noun | afternoon | M
"""

# verb | gloss | spec ...  (spec = root+marker; Q and person endings are generated)
VERBS = """
చేయు | do | pcont=చేస్+తున్న్ abil=చేయ+గల్
వెళ్ళు | go | pcont=వెళ్+తున్న్
ప్రేమించు | love | pcont=ప్రేమిస్+తున్న్
తిను | eat | past=తిన్+న్ pcont=తింటూ+ఉన్న్
ఇవ్వు | give | imp=ఇవ్వ్+అండి
ఉండు | be | imp=ఉండ్+అండి n3=ఉ+ంది
చూడు | see | imp=చూడ్+అండి
బాగుండు | be good | pres=బాగు+న్న్ n3=బాగు+ంది
కలుసు | meet | hort=కలు+ద్దాం
"""

PNG = [("ఆను", "1SG"), ("ఆవు", "2SG"), ("ఆడు", "3SGM"), ("ఆము", "1PL"), ("ఆరు", "2/3PL")]
PNG_ABIL = [("అను", "1SG"), ("అవు", "2SG"), ("అడు", "3SGM"), ("అము", "1PL"), ("అరు", "2/3PL")]
CASES = [("ను", "ACC"), ("కు", "DAT"), ("లో", "LOC"), ("తో", "SOC"), ("యొక్క", "GEN")]
Q = P("ఆ")


def _noun_forms(lemma, pos, gloss, cls, flag=""):
    out = []

    def add(morphs):
        out.append(("".join(m for m, _ in morphs), Analysis(lemma, pos, morphs, gloss, {}, "lexicon", 5)))

    Lm = P(lemma)
    if flag == "adv":
        add([(Lm, ""), (P("గా"), "ADVZ")])
        out[-1][1].pos = "adverb"
    if flag == "adj":
        add([(Lm[:-1] + "మ్", ""), (P("ఐన"), "ADJZ")])
        out[-1][1].pos = "adjective"
    if cls == "M":
        stem = Lm[:-2]                      # పుస్తక్
        add([(stem, ""), (P("ఆలు"), "PL")])
        add([(Lm, ""), (P("లో"), "LOC")])
        return out
    add([(Lm, ""), (P("లు"), "PL")])
    for suf, tag in CASES:
        add([(Lm, ""), (P(suf), tag)])
        add([(Lm, ""), (P("ల"), "PL"), (P(suf), tag)])
    return out


def _verb_forms(lemma, gloss, spec):
    out = []

    def mk(morphs):
        return Analysis(lemma, "verb", morphs, gloss, {}, "lexicon", 5)

    def add(morphs, finite=False):
        out.append(("".join(m for m, _ in morphs), mk(morphs)))
        if finite:
            q = with_question(morphs, Q, L, drop_u)
            out.append(("".join(m for m, _ in q), mk(q)))

    def split(s):
        a, _, b = s.partition("+")
        return P(a), P(b)

    for key, tag, pngs in (("pcont", "PRS.CONT", PNG), ("past", "PAST", PNG)):
        if key in spec:
            root, marker = split(spec[key])
            for png, ptag in pngs:
                add([(root, ""), (marker, tag), (P(png), ptag)], True)
    if "abil" in spec:
        root, marker = split(spec["abil"])
        for png, ptag in PNG_ABIL:
            add([(root, ""), (marker, "ABIL"), (P(png), ptag)], True)
    if "pres" in spec:
        root, marker = split(spec["pres"])
        for png, ptag in PNG:
            add([(root, ""), (marker, "PRES"), (P(png), ptag)], True)
    if "n3" in spec:
        root, marker = split(spec["n3"])
        add([(root, ""), (marker, "3SGN")])
    if "hort" in spec:
        root, marker = split(spec["hort"])
        add([(root, ""), (marker, "HORT")])
    if "imp" in spec:
        root, marker = split(spec["imp"])
        add([(root, ""), (marker, "IMP.HON")])
    return out


def build():
    def gen():
        for row in lex_lines(NOUNS):
            yield from _noun_forms(row[0], row[1], row[2], row[3], row[4] if len(row) > 4 else "")
        for row in lex_lines(VERBS):
            lemma, gloss = row[0], row[1]
            spec = kv(row[2]) if len(row) > 2 else {}
            yield from _verb_forms(lemma, gloss, spec)
    return finish_build(L, WORDS, FIXED, gen())


def heuristic_chains():
    chains = []
    for suf, tag in CASES:
        chains.append((P(suf), [(P(suf), tag)], "noun"))
    chains.append((P("లు"), [(P("లు"), "PL")], "noun"))
    for marker, tag in (("తున్న్", "PRS.CONT"),):
        for png, ptag in PNG:
            chains.append((P(marker) + P(png), [(P(marker), tag), (P(png), ptag)], "verb"))
    chains.append((P("అండి"), [(P("అండి"), "IMP.HON")], "verb"))
    chains.append((P("గా"), [(P("గా"), "ADVZ")], "adverb"))
    chains.sort(key=lambda c: -len(c[0]))
    return chains
