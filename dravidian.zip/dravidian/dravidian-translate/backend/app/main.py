import logging

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import BaseModel, Field

from . import audio, config, languages, langid, morph, knowledge_dataset, continuous_trainer
from .engines import registry
from .textutil import split_sentences

log = logging.getLogger("dravidian")
app = FastAPI(title="Dravidian Translate", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=config.CORS_ORIGINS,
                   allow_methods=["*"], allow_headers=["*"])


# ---------- helpers ----------
def _lang(code: str) -> languages.Language:
    try:
        return languages.get(code)
    except ValueError as e:
        raise HTTPException(422, str(e))


def _engine_call(fn, *args):
    """Map engine failures to clean HTTP errors instead of leaking stack traces."""
    try:
        return fn(*args)
    except HTTPException:
        raise
    except ImportError as e:
        log.exception("engine dependency missing")
        raise HTTPException(503, f"Engine not installed on server: {e.name}")
    except Exception:
        log.exception("engine failure")
        raise HTTPException(500, "Processing failed. Check server logs.")


async def _read_upload(f: UploadFile) -> bytes:
    data = await f.read()
    if not data:
        raise HTTPException(422, "Empty file.")
    if len(data) > config.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"File larger than {config.MAX_UPLOAD_MB} MB.")
    return data


# ---------- schemas ----------
class TranslateIn(BaseModel):
    text: str = Field(min_length=1)
    src: str = "auto"
    tgt: str


class TranslateOut(BaseModel):
    translation: str
    src: str
    tgt: str
    detected_confidence: float | None = None
    warning: str | None = None
    romanization: str | None = None
    original_script: str | None = None


class TtsIn(BaseModel):
    text: str = Field(min_length=1, max_length=1000)
    lang: str


class MorphIn(BaseModel):
    text: str = Field(min_length=1, max_length=2000)
    lang: str


class MorphOut(BaseModel):
    tokens: list
    script_stats: dict
    lang_info: dict
    agglutination_score: float
    summary: str


class TrainIn(BaseModel):
    src_text: str = Field(min_length=1)
    src_lang: str
    tgt_text: str = Field(min_length=1)
    tgt_lang: str
    romanization: str | None = None


# ---------- routes ----------
@app.get("/api/health")
def health():
    return {"status": "ok", "engine_mode": config.ENGINE_MODE}


@app.get("/api/dataset/stats")
def dataset_stats():
    return continuous_trainer.manager.get_stats()


@app.post("/api/dataset/train")
def train_dataset(req: TrainIn):
    _lang(req.src_lang)
    _lang(req.tgt_lang)
    res = continuous_trainer.manager.train_pair(
        req.src_text, req.src_lang, req.tgt_text, req.tgt_lang, req.romanization
    )
    return res


@app.get("/api/languages")
def list_languages():
    return [{"code": l.code, "name": l.name, "native": l.native} for l in languages.LANGUAGES.values()]


@app.post("/api/translate", response_model=TranslateOut)
def translate(req: TranslateIn):
    text = req.text.strip()
    if not text:
        raise HTTPException(422, "Text is empty.")
    if len(text) > config.MAX_TEXT_CHARS:
        raise HTTPException(413, f"Text longer than {config.MAX_TEXT_CHARS} characters.")
    _lang(req.tgt)

    det = langid.detect(text)
    warning, conf = None, None
    original_script = None
    rom_detected = knowledge_dataset.detect_romanized_dravidian(text)

    if rom_detected and (det.lang == "eng" or req.src in ("auto", "eng", rom_detected["lang"])):
        # Input is Romanized Dravidian (Tanglish, Tenglish, etc.)
        src = rom_detected["lang"]
        original_script = rom_detected["native"]
        conf = 0.95
        warning = f"Detected colloquial English communication form ({languages.get(src).name} in Latin letters / {src.title()}glish)."
        
        if req.tgt == "eng":
            out = [rom_detected["en"]]
            return TranslateOut(
                translation="\n".join(out),
                src=src,
                tgt="eng",
                detected_confidence=conf,
                warning=warning,
                romanization=None,
                original_script=original_script
            )
        elif req.tgt == src:
            # Transliterate colloquial English directly into native script
            return TranslateOut(
                translation=rom_detected["native"],
                src=src,
                tgt=src,
                detected_confidence=conf,
                warning=warning,
                romanization=text,
                original_script=original_script
            )
    elif req.src == "auto":
        if det.lang is None:
            raise HTTPException(422, "Could not detect the language of this text.")
        src, conf = det.lang, round(det.confidence, 2)
    else:
        src = _lang(req.src).code
        if det.lang and det.lang != src and det.confidence > 0.8:
            warning = (f"Text looks like {languages.get(det.lang).name} "
                       f"but source was set to {languages.get(src).name}.")

    if src == req.tgt and not (rom_detected and req.tgt == rom_detected["lang"]):
        raise HTTPException(422, "Source and target language are the same.")

    # 100% Precision Continuous Learning Dataset Memory
    trained_match = continuous_trainer.manager.find_translation(text, src, req.tgt)
    if trained_match:
        translation_str, trained_roman = trained_match
        if not trained_roman and req.tgt in ("tam", "tel", "kan", "mal"):
            trained_roman = knowledge_dataset.romanize_dravidian(translation_str, req.tgt)
        return TranslateOut(
            translation=translation_str,
            src=src,
            tgt=req.tgt,
            detected_confidence=1.0,
            warning=warning,
            romanization=trained_roman,
            original_script=original_script
        )

    sentences = split_sentences(text)
    out = _engine_call(registry.translator().translate, sentences, src, req.tgt)
    translation_str = "\n".join(out)

    # Compute English communicative version (Romanization) for Dravidian targets
    romanization = None
    if req.tgt in ("tam", "tel", "kan", "mal"):
        romanization = knowledge_dataset.romanize_dravidian(translation_str, req.tgt)

    return TranslateOut(
        translation=translation_str,
        src=src,
        tgt=req.tgt,
        detected_confidence=conf,
        warning=warning,
        romanization=romanization,
        original_script=original_script
    )


@app.post("/api/asr")
async def asr(file: UploadFile = File(...), lang: str = Form(...)):
    _lang(lang)
    data = await _read_upload(file)
    try:
        samples = audio.to_pcm16k(data)
    except audio.DecoderUnavailable as e:
        raise HTTPException(415, str(e))
    except audio.AudioDecodeError as e:
        raise HTTPException(422, str(e))
    except Exception:  # never leak raw OS errors such as "[WinError 2] ..." to the browser
        log.exception("audio decoding failed")
        raise HTTPException(422, "Could not read this audio. Please record again.")
    seconds = len(samples) / 16000
    if seconds > config.MAX_AUDIO_SECONDS:
        raise HTTPException(413, f"Audio longer than {config.MAX_AUDIO_SECONDS}s.")
    if seconds < 0.3:
        raise HTTPException(422, "Audio too short.")
    text = _engine_call(registry.asr().transcribe, samples, lang)
    return {"text": text, "lang": lang, "seconds": round(seconds, 1)}


@app.post("/api/ocr")
async def ocr(file: UploadFile = File(...), lang: str | None = Form(None)):
    if lang and lang != "auto":
        _lang(lang)
    else:
        lang = None
    data = await _read_upload(file)
    try:
        res = _engine_call(registry.ocr().read, data, lang)
    except HTTPException:
        raise
    det = langid.detect(res.text)
    return {"text": res.text, "confidence": res.confidence,
            "detected_lang": det.lang, "lang": lang}


@app.post("/api/tts")
def tts(req: TtsIn):
    _lang(req.lang)
    lang_code_map = {
        "tam": "ta",
        "tel": "te",
        "kan": "kn",
        "mal": "ml",
        "eng": "en",
    }
    short_lang = lang_code_map.get(req.lang, "en")

    if config.ENGINE_MODE != "mock":
        # High-fidelity Neural AI Voice (Siri / Google Assistant studio quality)
        try:
            import urllib.request
            import urllib.parse
            encoded_q = urllib.parse.quote(req.text.strip()[:300])
            tts_url = f"https://translate.google.com/translate_tts?ie=UTF-8&tl={short_lang}&client=tw-ob&q={encoded_q}"
            req_obj = urllib.request.Request(tts_url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            })
            with urllib.request.urlopen(req_obj, timeout=5) as resp:
                audio_bytes = resp.read()
                if len(audio_bytes) > 500:
                    return Response(content=audio_bytes, media_type="audio/mpeg")
        except Exception as e:
            log.warning(f"Neural TTS remote fetch failed, falling back to local: {e}")

    res = _engine_call(registry.tts().speak, req.text, req.lang)
    return Response(content=audio.to_wav_bytes(res.samples, res.sample_rate), media_type="audio/wav")


@app.get("/api/tts/stream")
def tts_stream(text: str, lang: str):
    return tts(TtsIn(text=text, lang=lang))


@app.post("/api/morph", response_model=MorphOut)
def morphological_analysis(req: MorphIn):
    """Perform rule-based morphological analysis on Dravidian text.

    Accepts a text and a Dravidian language code (tam / tel / kan / mal).
    Returns per-token analysis (stem, POS, suffixes, grammatical features,
    Unicode char breakdown), script statistics, language family metadata, and
    an agglutination score.
    """
    text = req.text.strip()
    if not text:
        raise HTTPException(422, "Text is empty.")
    try:
        result = morph.analyse(text, req.lang)
    except ValueError as e:
        raise HTTPException(422, str(e))
    return MorphOut(
        tokens=result.tokens,
        script_stats=result.script_stats,
        lang_info=result.lang_info,
        agglutination_score=result.agglutination_score,
        summary=result.summary,
    )
