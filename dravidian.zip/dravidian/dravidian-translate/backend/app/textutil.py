"""Sentence splitting so long inputs are translated sentence-by-sentence."""
import re

# Splits after . ? ! । ॥ and newlines, keeping the delimiter with the sentence.
_SPLIT = re.compile(r"(?<=[.!?।॥])\s+|\n+")


def split_sentences(text: str, max_len: int = 400) -> list[str]:
    parts = [p.strip() for p in _SPLIT.split(text) if p and p.strip()]
    out: list[str] = []
    for p in parts:
        while len(p) > max_len:  # hard wrap on whitespace for run-on text
            cut = p.rfind(" ", 0, max_len)
            cut = cut if cut > 0 else max_len
            out.append(p[:cut].strip())
            p = p[cut:].strip()
        if p:
            out.append(p)
    return out
