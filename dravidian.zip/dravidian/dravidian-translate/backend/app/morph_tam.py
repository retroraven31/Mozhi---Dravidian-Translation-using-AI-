"""Tamil morphology: lexicon, paradigm generator, irregular forms, OOV fallback.

Design: every regular inflected form of every lexicon entry is *generated* (stem x
suffix chain) and indexed by its surface form, so analysis is an exact, auditable
lookup. Irregular / closed-class forms live in FIXED. Words that are not in the index
fall back to suffix stripping and are flagged ``confidence = heuristic``.
"""
from __future__ import annotations

from . import morph_script as ms
from .morph_common import Analysis, kv, lex_lines, parse_fixed

L = "tam"
VIR = "்"


def P(s: str) -> str:
    return ms.to_phon(s, L)


def drop_u(p: str) -> str:
    return p[:-1] if p.endswith("உ") and len(p) > 1 and p[-2] == VIR else p


def glide_for(stem: str, suffix: str) -> str:
    """Tamil inserts ய் after front vowels and வ் after other vowels (vowel + vowel hiatus)."""
    if stem and suffix and ms.ends_with_vowel(stem, L) and ms.starts_with_vowel(suffix, L):
        return P("ய்") if ms.is_front_vowel(stem[-1], L) else P("வ்")
    return ""


def glued(stem: str, suffix: str) -> str:
    return glide_for(stem, suffix) + suffix


# ── lexicon ──────────────────────────────────────────────────────────────────────
# noun | lemma | gloss | class   (U = drop final u before a vowel, TTU = வீடு>வீட்டு,
#                                 M = ...ம் nouns (மரம்>மரத்தை), V/C = vowel / consonant final)
NOUNS = """
அன்பு | noun | love | U
இரவு | noun | night | U
உடம்பு | noun | body | U
உணவு | noun | food | U
ஊர் | noun | town / village | C
காலை | noun | morning | V
சூரியன் | noun | sun | C
தண்ணீர் | noun | water | C
தமிழ் | noun | Tamil (language) | C
தெலுங்கு | noun | Telugu (language) | U
நகரம் | noun | city | M
நண்பன் | noun | friend | C
நாடு | noun | country | TTU
நாள் | noun | day | C
நிலா | noun | moon | V
நிலையம் | noun | station | M
பள்ளி | noun | school | V
பிறந்தநாள் | noun | birthday | C
புத்தகம் | noun | book | M
பெயர் | noun | name | C
மணி | noun | bell / hour | V
மருத்துவமனை | noun | hospital | V
மாலை | noun | evening | V
மொழி | noun | language | V
ரயில் | noun | train | C
வாழ்த்து | noun | greeting / wish | U
விலை | noun | price | V
வீடு | noun | house | TTU
மகிழ்ச்சி | noun | happiness | V | adv
நலம் | noun | well-being | M | adv
நன்று | noun | goodness | U | adv
அழகு | noun | beauty | U | adj
நேரம் | noun | time | M
பணம் | noun | money | M
மரம் | noun | tree | M
கடை | noun | shop | V
பேருந்து | noun | bus | U
மனிதன் | noun | man / human | C
குழந்தை | noun | child | V
"""

# verb | lemma | gloss | params ; params are space separated key=value, parts joined by '+'
#   pres/past/fut = stem-allomorph+tense-marker   inf = stem+marker   imp = stem+honorific
#   vbp = stem+marker   fut3n = stem+marker (3rd neuter future in -um)
VERBS = """
இரு | verb | be | pres=இரு+க்கிற் past=இரு+ந்த் fut=இரு+ப்ப் inf=இரு+க்க fut3n=இரு+க்கும்
காதலி | verb | love | pres=காதலி+க்கிற் past=காதலி+த்த் fut=காதலி+ப்ப் inf=காதலி+க்க
செய் | verb | do / make | pres=செய்+கிற் past=செய்+த் fut=செய்+வ் inf=செய்+ய imp=செய்+ய்உங்கள்
சாப்பிடு | verb | eat | pres=சாப்பிடு+கிற் past=சாப்பிட்+ட் fut=சாப்பிடு+வ் inf=சாப்பிட்+அ imp=சாப்பிட்+உங்கள்
சந்தி | verb | meet | pres=சந்தி+க்கிற் past=சந்தி+த்த் fut=சந்தி+ப்ப் inf=சந்தி+க்க
போ | verb | go | pres=போ+கிற் past=போ+ன் fut=போ+வ் inf=போ+க vbp=போ+ய் imp=போ+ங்கள் fut3n=போ+கும்
பேசு | verb | speak | pres=பேசு+கிற் past=பேசி+ன் fut=பேசு+வ் inf=பேச்+அ imp=பேசு+ங்கள்
புரி | verb | understand | pres=புரி+கிற் past=புரிந்+த் inf=புரி+அ fut3n=புரி+யும்
விரும்பு | verb | like / want | pres=விரும்பு+கிற் past=விரும்பி+ன் fut=விரும்பு+வ் inf=விரும்ப்+அ imp=விரும்பு+ங்கள்
வரவேற்கு | verb | welcome | pres=வரவேற்+கிற் past=வரவேற்+ற் fut=வரவேற்+ப்ப் inf=வரவேற்+க
உதவு | verb | help | pres=உதவு+கிற் past=உதவி+ன் fut=உதவு+வ் inf=உதவ்+அ imp=உதவு+ங்கள்
கல் | verb | learn | pres=கற்+கிற் past=கற்+ற் fut=கற்+ப்ப் inf=கற்+க
கொடு | verb | give | pres=கொடு+க்கிற் past=கொடு+த்த் fut=கொடு+ப்ப் inf=கொடு+க்க imp=கொட்+உங்கள்
வா | verb | come | pres=வரு+கிற் past=வந்+த் fut=வரு+வ் inf=வர்+அ imp=வார்+உங்கள் vbp=வந்+து
பார் | verb | see / look | pres=பார்+க்கிற் past=பார்+த்த் fut=பார்+ப்ப் inf=பார்+க்க vbp=பார்+த்து
தெரி | verb | know / be visible | pres=தெரி+கிற் past=தெரிந்+த் inf=தெரி+அ fut3n=தெரி+யும்
முடி | verb | be able / finish | pres=முடி+கிற் past=முடிந்+த் fut3n=முடி+யும்
கொள் | verb | take / hold | pres=கொள்+கிற் past=கொண்+ட் fut=கொள்+வ்
எழுது | verb | write | pres=எழுது+கிற் past=எழுதி+ன் fut=எழுது+வ் inf=எழுத்+அ imp=எழுது+ங்கள்
படி | verb | read / study | pres=படி+க்கிற் past=படி+த்த் fut=படி+ப்ப் inf=படி+க்க
"""

# invariant words (no inflection)
WORDS = """
அது | pronoun | that | type=demonstrative-distal
இது | pronoun | this | type=demonstrative-proximal
என்ன | pronoun | what | type=interrogative
யார் | pronoun | who | type=interrogative
எங்கே | adverb | where | type=interrogative
எப்படி | adverb | how | type=interrogative
எப்போது | adverb | when | type=interrogative
ஏன் | adverb | why | type=interrogative
எந்த | determiner | which | type=interrogative
இன்று | adverb | today
இப்போது | adverb | now
மீண்டும் | adverb | again
மிக | adverb | very
மிக்க | adjective | much / great
மற்றும் | conjunction | and
ஆம் | particle | yes | type=affirmative
இல்லை | verb | is not / no | polarity=negative;type=negative-existential
இனிய | adjective | sweet / pleasant
கெட்ட | adjective | bad
சிறிய | adjective | small
திராவிட | adjective | Dravidian
நல்ல | adjective | good
பழைய | adjective | old
புதிய | adjective | new
பெரிய | adjective | big
மதிய | adjective | noon / midday
வணக்கம் | interjection | hello / greetings | type=greeting
நன்றி | interjection | thank you | type=gratitude
தயவுசெய்து | interjection | please | type=courtesy
"""

# irregular & suppletive forms (pronoun paradigms, compounds): token | lemma | pos | morphs | feats | gloss
FIXED = """
நான் | நான் | pronoun | நான் | person=1st;number=singular;case=nominative | I
என் | நான் | pronoun | என் | person=1st;number=singular;case=genitive | my
எனக்கு | நான் | pronoun | என க்கு:DAT | person=1st;number=singular;case=dative | to me
என்னை | நான் | pronoun | என்ன் ஐ:ACC | person=1st;number=singular;case=accusative | me
நாங்கள் | நாங்கள் | pronoun | நாங்கள் | person=1st;number=plural;case=nominative | we
எங்கள் | நாங்கள் | pronoun | எங்கள் | person=1st;number=plural;case=genitive | our
எங்களுக்கு | நாங்கள் | pronoun | எங்கள் உக்கு:DAT | person=1st;number=plural;case=dative | to us
நாம் | நாம் | pronoun | நாம் | person=1st;number=plural-inclusive;case=nominative | we (incl.)
நீ | நீ | pronoun | நீ | person=2nd;number=singular;case=nominative | you (familiar)
உன் | நீ | pronoun | உன் | person=2nd;number=singular;case=genitive | your (familiar)
உனக்கு | நீ | pronoun | உன க்கு:DAT | person=2nd;number=singular;case=dative | to you (familiar)
உன்னை | நீ | pronoun | உன்ன் ஐ:ACC | person=2nd;number=singular;case=accusative | you (familiar)
நீங்கள் | நீங்கள் | pronoun | நீங்கள் | person=2nd;number=plural/honorific;case=nominative | you
உங்கள் | நீங்கள் | pronoun | உங்கள் | person=2nd;number=plural/honorific;case=genitive | your
உங்களுக்கு | நீங்கள் | pronoun | உங்கள் உக்கு:DAT | person=2nd;number=plural/honorific;case=dative | to you
உங்களை | நீங்கள் | pronoun | உங்கள் ஐ:ACC | person=2nd;number=plural/honorific;case=accusative | you
அவன் | அவன் | pronoun | அவன் | person=3rd;gender=masculine;number=singular | he
அவள் | அவள் | pronoun | அவள் | person=3rd;gender=feminine;number=singular | she
அவர் | அவர் | pronoun | அவர் | person=3rd;number=singular/honorific | he / she (respectful)
அவர்கள் | அவர் | pronoun | அவர் கள்:PL | person=3rd;number=plural | they
இதன் | இது | pronoun | இத் அன்:GEN | type=demonstrative-proximal;case=genitive | of this
அதன் | அது | pronoun | அத் அன்:GEN | type=demonstrative-distal;case=genitive | of that
இதை | இது | pronoun | இத் ஐ:ACC | type=demonstrative-proximal;case=accusative | this (acc.)
அதை | அது | pronoun | அத் ஐ:ACC | type=demonstrative-distal;case=accusative | that (acc.)
உள்ளது | உள் | verb | உள்ள் அது:3SGN | tense=present;type=existential | there is / exists
மிகவும் | மிக | adverb | மிக வும்:EMPH | | very much
பார்த்துக்கொள்ளுங்கள் | பார்த்துக்கொள் | verb | பார் த்து:VBP க்:SANDHI கொள்ள்:AUX உங்கள்:IMP.HON | | take care (polite)
"""

PNG = [("ஏன்", "1SG"), ("ஆய்", "2SG"), ("ஆன்", "3SGM"), ("ஆள்", "3SGF"), ("ஆர்", "3SGH"),
       ("ஓம்", "1PL"), ("ஈர்கள்", "2PL"), ("ஆர்கள்", "3PL"), ("அது", "3SGN"), ("அன", "3PLN")]

CASES = [("ஐ", "ACC"), ("இல்", "LOC"), ("இன்", "GEN"), ("ஆல்", "INS"), ("உடன்", "SOC"),
         ("இலிருந்து", "ABL")]


# ── generators ───────────────────────────────────────────────────────────────────
def _noun_forms(lemma: str, pos: str, gloss: str, cls: str, flag: str):
    Lm = P(lemma)

    def mk(morphs, pos_=None):
        return Analysis(lemma, pos_ or pos, morphs, gloss, {}, "lexicon", 5)

    # stem allomorph before a vowel-initial suffix
    if cls == "U":
        sv = drop_u(Lm)
    elif cls == "TTU":
        sv = Lm[:-1] + Lm[-3] + VIR if Lm.endswith("உ") else Lm
    elif cls == "M":
        sv = Lm[:-2] + P("த்த்")
    else:
        sv = Lm

    out: list[tuple[str, Analysis]] = []

    def add(morphs, pos_=None):
        out.append(("".join(m for m, _ in morphs), mk(morphs, pos_)))

    add([(Lm, "")])

    # plural
    if cls == "M":
        pl_stem, pl_morph = Lm[:-2], P("ங்கள்")
    else:
        pl_stem, pl_morph = Lm, P("கள்")
    plural = [(pl_stem, ""), (pl_morph, "PL")]
    add(plural)
    plstem_full = pl_stem + pl_morph            # ends in ள் -> behaves as consonant-final

    def case_forms(stem_v, stem_c, prefix_morphs, vowel_stem_is_vowel):
        # vowel-initial case suffixes
        for suf, tag in CASES:
            sp = P(suf)
            add(prefix_morphs(stem_v) + [(glued(stem_v, sp), tag)])
        # dative
        if prefix_morphs is _bare:
            if cls in ("TTU", "M"):
                add(prefix_morphs(stem_v) + [(P("இற்கு"), "DAT")])
                add(prefix_morphs(stem_v) + [(P("உக்கு"), "DAT")])
            elif cls == "U":
                add([(stem_c, "")] + [(P("க்கு"), "DAT")])
                add(prefix_morphs(stem_v) + [(P("இற்கு"), "DAT")])
            elif cls == "V":
                add([(stem_c, "")] + [(P("க்கு"), "DAT")])
            else:
                add([(stem_c, "")] + [(P("உக்கு"), "DAT")])
        else:
            add(prefix_morphs(stem_v) + [(P("உக்கு"), "DAT")])

    def _bare(stem):
        return [(stem, "")]

    case_forms(sv, Lm, _bare, True)
    # plural + case (the plural ends in a consonant, so cases attach directly)
    def _pl(stem):
        return [(pl_stem, ""), (pl_morph, "PL")]
    case_forms(plstem_full, plstem_full, _pl, False)

    # clitics
    sd = drop_u(Lm)
    add([(sd, ""), (glued(sd, P("உம்")), "EMPH")])
    add([(sd, ""), (glued(sd, P("ஆ")), "Q")])
    if "adv" in flag:
        add([(sd, ""), (glued(sd, P("ஆக")), "ADVZ")], "adverb")
    if "adj" in flag:
        add([(sd, ""), (glued(sd, P("ஆன")), "ADJZ")], "adjective")
    return out


def _verb_forms(lemma: str, gloss: str, params: dict[str, str]):
    out: list[tuple[str, Analysis]] = []

    def mk(morphs, feats=None):
        return Analysis(lemma, "verb", morphs, gloss, feats or {}, "lexicon", 5)

    def add(morphs):
        out.append(("".join(m for m, _ in morphs), mk(morphs)))
        # question clitic (finite and non-finite alike)
        q = morphs + [(glued(morphs[-1][0], P("ஆ")), "Q")]
        out.append(("".join(m for m, _ in q), mk(q)))

    def split(spec: str):
        root, _, marker = spec.partition("+")
        return P(root), P(marker)

    for tense, tag in (("pres", "PRES"), ("past", "PAST"), ("fut", "FUT")):
        if tense in params:
            root, marker = split(params[tense])
            for png, ptag in PNG:
                ps = P(png)
                add([(root, ""), (marker, tag), (glued(marker, ps), ptag)])
    if "inf" in params:
        root, marker = split(params["inf"])
        add([(root, ""), (glued(root, marker), "INF")])
        add([(root, ""), (glued(root, marker), "INF"), (P("வில்லை"), "NEG")])
        add([(root, ""), (glued(root, marker), "INF"), (P("வில்லை"), "NEG"), (glued(P("வில்லை"), P("ஆ")), "Q")])
    if "imp" in params:
        root, marker = split(params["imp"])
        add([(root, ""), (glued(root, marker), "IMP.HON")])
    if "vbp" in params:
        root, marker = split(params["vbp"])
        add([(root, ""), (marker, "VBP")])
    if "fut3n" in params:
        root, marker = split(params["fut3n"])
        add([(root, ""), (marker, "FUT")])
    return out


def build() -> dict[str, list[Analysis]]:
    idx: dict[str, list[Analysis]] = {}

    def put(form: str, a: Analysis):
        idx.setdefault(form, []).append(a)

    for row in lex_lines(NOUNS):
        lemma, pos, gloss, cls = row[0], row[1], row[2], row[3]
        flag = row[4] if len(row) > 4 else ""
        for form, a in _noun_forms(lemma, pos, gloss, cls, flag):
            put(form, a)
    for row in lex_lines(VERBS):
        lemma, _, gloss, params = row
        for form, a in _verb_forms(lemma, gloss, kv(params)):
            put(form, a)
    for row in lex_lines(WORDS):
        word, pos, gloss = row[0], row[1], row[2]
        feats = {}
        if len(row) > 3:
            from .morph_common import parse_feats
            feats = parse_feats(row[3])
        put(P(word), Analysis(word, pos, [(P(word), "")], gloss, feats, "fixed", 2))
    for row in lex_lines(FIXED):
        form, a = parse_fixed(" | ".join(row), L)
        put(form, a)
    return idx


# ── OOV fallback ────────────────────────────────────────────────────────────────
def heuristic_chains() -> list[tuple[str, list[tuple[str, str]], str]]:
    """(suffix phon, [(morph phon, tag)...], pos) from the same inventories, longest first."""
    chains = []
    markers = [("கிற்", "PRES"), ("க்கிற்", "PRES"), ("ந்த்", "PAST"), ("த்த்", "PAST"),
               ("ட்", "PAST"), ("ன்", "PAST"), ("ப்ப்", "FUT"), ("வ்", "FUT")]
    for m, t in markers:
        for png, ptag in PNG:
            mp, pp = P(m), P(png)
            chains.append((mp + glued(mp, pp), [(mp, t), (glued(mp, pp), ptag)], "verb"))
    for suf, tag in CASES + [("கள்", "PL")]:
        sp = P(suf)
        chains.append((sp, [(sp, tag)], "noun"))
    chains.append((P("க்கு"), [(P("க்கு"), "DAT")], "noun"))
    chains.append((P("இற்கு"), [(P("இற்கு"), "DAT")], "noun"))
    chains.append((P("உங்கள்"), [(P("உங்கள்"), "IMP.HON")], "verb"))
    chains.append((P("ஆக"), [(P("ஆக"), "ADVZ")], "adverb"))
    chains.append((P("ஆன"), [(P("ஆன"), "ADJZ")], "adjective"))
    chains.sort(key=lambda c: -len(c[0]))
    return chains
