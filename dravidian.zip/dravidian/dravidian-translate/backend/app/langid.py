"""Script-based language identification.

Each Dravidian language has its own Unicode block, so counting characters per
block identifies the language reliably for text written in native script.

Extended in v2 to also *report* Tulu (tcy) and Konkani (kok) when their
respective scripts appear in the input, even though those languages are not
in the translation pipeline.

Known limitation: romanised text (e.g. "Tanglish", "Telugu in English letters")
is detected as English. Transliteration input is out of scope for v1.
"""
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Script → language-code mapping
# ---------------------------------------------------------------------------
# Primary translatable languages: each gets its own range.
_PRIMARY_RANGES: dict[str, tuple[int, int]] = {
    "tam": (0x0B80, 0x0BFF),   # Tamil
    "tel": (0x0C00, 0x0C7F),   # Telugu
    "kan": (0x0C80, 0x0CFF),   # Kannada
    "mal": (0x0D00, 0x0D7F),   # Malayalam
}

# Detection-only ranges: reported but not passed to the translation engine.
# Tulu is written in the Kannada script (same Unicode block as Kannada) so it
# cannot be distinguished from Kannada by Unicode ranges alone; we flag the
# block as "kan/tcy (ambiguous)".
# Konkani is typically written in Devanagari; a small community uses Latin.
_DETECT_ONLY_RANGES: dict[str, tuple[int, int]] = {
    "kok": (0x0900, 0x097F),   # Konkani (Devanagari)
    # Tulu: same block as Kannada (0x0C80-0x0CFF), handled separately via flag
}

_ALL_RANGES: dict[str, tuple[int, int]] = {
    **_PRIMARY_RANGES,
    **_DETECT_ONLY_RANGES,
}


@dataclass
class Detection:
    lang: str | None   # None when there is nothing to classify; uses primary codes
    confidence: float  # share of letters that belong to the detected script

    # Detection-only extras (not necessarily translatable)
    extra_scripts: dict[str, int] = field(default_factory=dict)
    """Mapping of extra-detected language codes → character counts.
    E.g. {"kok": 12} when Devanagari characters are present.
    Tulu (tcy) is flagged here if only Kannada-block chars are found and the
    caller wants to surface the ambiguity."""


def detect(text: str) -> Detection:
    # Count per-script characters for primary languages
    primary_counts: dict[str, int] = {k: 0 for k in _PRIMARY_RANGES}
    # Count for detection-only scripts
    detect_counts: dict[str, int] = {k: 0 for k in _DETECT_ONLY_RANGES}
    latin: int = 0

    for ch in text:
        cp = ord(ch)
        matched = False
        for lang, (lo, hi) in _PRIMARY_RANGES.items():
            if lo <= cp <= hi:
                primary_counts[lang] += 1
                matched = True
                break
        if not matched:
            for lang, (lo, hi) in _DETECT_ONLY_RANGES.items():
                if lo <= cp <= hi:
                    detect_counts[lang] += 1
                    matched = True
                    break
        if not matched and ch.isascii() and ch.isalpha():
            latin += 1

    primary_counts["eng"] = latin
    total = sum(primary_counts.values()) + sum(detect_counts.values())

    if total == 0:
        return Detection(None, 0.0)

    # Best primary language
    best = max(primary_counts, key=primary_counts.get)  # type: ignore[arg-type]
    best_count = primary_counts[best]
    confidence = best_count / total if total else 0.0

    # Build extra_scripts: detection-only hits plus Tulu ambiguity note
    extra: dict[str, int] = {}
    for k, v in detect_counts.items():
        if v > 0:
            extra[k] = v
    # Tulu (tcy) uses the same Kannada Unicode block; if Kannada characters
    # are dominant, flag the ambiguity so callers can surface it.
    if best == "kan" and best_count > 0:
        extra["tcy"] = best_count  # ambiguous: Kannada script may be Tulu

    if best_count == 0:
        # Only detection-only scripts found
        return Detection(None, 0.0, extra_scripts=extra)

    return Detection(best, round(confidence, 4), extra_scripts=extra)
