"""English morphology: closed-class words, irregular forms, spelling-rule inflection.

Every regular inflection is accepted only when the stem it produces is a known word in
the lexicon below (so ``houses`` -> house + s, never ``hou`` + ``ses``). Words outside the
lexicon are analysed with conservative suffix rules and flagged as heuristic.
"""
from __future__ import annotations

from .morph_common import Analysis

# ── closed classes ───────────────────────────────────────────────────────────────
_PRON = {
    "i": ("I", "person=1st;number=singular;case=nominative"),
    "me": ("I", "person=1st;number=singular;case=accusative"),
    "you": ("you", "person=2nd"),
    "he": ("he", "person=3rd;gender=masculine;case=nominative"),
    "him": ("he", "person=3rd;gender=masculine;case=accusative"),
    "she": ("she", "person=3rd;gender=feminine;case=nominative"),
    "it": ("it", "person=3rd;gender=neuter"),
    "we": ("we", "person=1st;number=plural;case=nominative"),
    "us": ("we", "person=1st;number=plural;case=accusative"),
    "they": ("they", "person=3rd;number=plural;case=nominative"),
    "them": ("they", "person=3rd;number=plural;case=accusative"),
    "mine": ("I", "person=1st;case=possessive"),
    "yours": ("you", "person=2nd;case=possessive"),
    "hers": ("she", "person=3rd;case=possessive"),
    "ours": ("we", "person=1st;case=possessive"),
    "theirs": ("they", "person=3rd;case=possessive"),
    "what": ("what", "type=interrogative"),
    "who": ("who", "type=interrogative"),
    "whom": ("who", "type=interrogative;case=accusative"),
    "myself": ("I", "type=reflexive"),
    "yourself": ("you", "type=reflexive"),
}
_DET_POSS = {
    "my": ("I", "case=possessive"), "your": ("you", "case=possessive"),
    "his": ("he", "case=possessive"), "her": ("she", "case=possessive"),
    "its": ("it", "case=possessive"), "our": ("we", "case=possessive"),
    "their": ("they", "case=possessive"),
}
_DET = {
    "the": "type=definite", "a": "type=indefinite", "an": "type=indefinite",
    "this": "distance=proximal;number=singular", "that": "distance=distal;number=singular",
    "these": "distance=proximal;number=plural", "those": "distance=distal;number=plural",
    "which": "type=interrogative", "some": "", "any": "", "every": "", "each": "",
    "all": "", "no": "", "both": "", "many": "", "few": "", "several": "",
}
_PREP = set("from to in on at of for with by about into over after before between under "
            "through during without within against among around near across behind "
            "beside beyond toward towards until up down off out".split())
_CONJ = set("and or but because if while although so than that as nor yet".split())
_PART = {"yes": "type=affirmative", "no": "type=negative", "not": "type=negative"}
_INTERJ = set("hello hi hey bye goodbye please thanks welcome congratulations sorry oh wow ok okay".split())
_ADV = set(("how where when why again very much today now here there always never often "
            "just also too well soon still already only almost quite really together tomorrow "
            "yesterday tonight maybe perhaps ever once twice quickly slowly").split())

# ── open-class lexicon (stems) ───────────────────────────────────────────────────
_NOUNS = set("""
name water food book house home friend school city country language sun moon day night morning
afternoon evening time birthday station hospital care love help work money family mother father
brother sister child man woman boy girl people person world life year week month hour minute
town village road street market shop store room door window table chair bed car bus train
bike phone computer game music song film movie picture story word letter number question answer
problem idea reason way place thing part example list team group class teacher student doctor
nurse farmer driver office company government problem hand head eye face heart body foot tooth
fruit vegetable rice bread milk tea coffee juice sugar salt egg meat fish chicken cake lunch
dinner breakfast price cost rate health weather rain wind fire light sound voice dream hope
fear joy happiness peace war news paper pen pencil bag box key gift present party festival
temple church river sea mountain tree flower garden field farm animal dog cat bird horse cow
today tomorrow yesterday trip journey ticket passport hotel flight airport river bridge
""".split())
_VERBS = set("""
be have do can will shall may must go come see take give know learn understand want like love
help thank eat drink sleep run walk talk speak say tell ask answer call meet make get put read
write play work live stay live buy sell pay bring carry open close start stop finish begin
wait watch look listen hear feel think believe remember forget need use try find lose win
teach study visit travel send receive keep hold show move turn change cook clean wash wear
sit stand fall fly grow draw drive ride sing dance laugh cry smile wake rise leave enter
build break choose cut hit throw catch push pull join invite welcome care thank hope wish
miss enjoy prefer decide agree speak shout whisper count add share fix prepare order book
""".split())
_ADJ = set("""
good bad big small new old fine happy sad beautiful pretty ugly hot cold warm cool fast slow
easy hard difficult simple clean dirty rich poor young long short tall high low near far late
early free busy tired hungry thirsty sick well ready sure right wrong true false full empty
open closed dear kind nice great little large huge strong weak sweet sour bitter dravidian
tamil telugu kannada malayalam indian english important special different same other next last
first second third real main whole dark bright quiet loud safe dangerous
""".split())

# irregular verbs: base -> (past, past participle)
_IRREG_V = {
    "be": ("was/were", "been"), "have": ("had", "had"), "do": ("did", "done"), "go": ("went", "gone"),
    "eat": ("ate", "eaten"), "take": ("took", "taken"), "give": ("gave", "given"),
    "see": ("saw", "seen"), "know": ("knew", "known"), "come": ("came", "come"),
    "say": ("said", "said"), "make": ("made", "made"), "get": ("got", "gotten"),
    "think": ("thought", "thought"), "buy": ("bought", "bought"), "bring": ("brought", "brought"),
    "speak": ("spoke", "spoken"), "write": ("wrote", "written"), "read": ("read", "read"),
    "run": ("ran", "run"), "sit": ("sat", "sat"), "stand": ("stood", "stood"), "tell": ("told", "told"),
    "find": ("found", "found"), "leave": ("left", "left"), "meet": ("met", "met"), "keep": ("kept", "kept"),
    "begin": ("began", "begun"), "drink": ("drank", "drunk"), "drive": ("drove", "driven"),
    "fall": ("fell", "fallen"), "feel": ("felt", "felt"), "hear": ("heard", "heard"),
    "hold": ("held", "held"), "pay": ("paid", "paid"), "sleep": ("slept", "slept"),
    "win": ("won", "won"), "wear": ("wore", "worn"), "understand": ("understood", "understood"),
    "sing": ("sang", "sung"), "teach": ("taught", "taught"), "send": ("sent", "sent"),
    "build": ("built", "built"), "lose": ("lost", "lost"), "sell": ("sold", "sold"),
    "forget": ("forgot", "forgotten"), "choose": ("chose", "chosen"), "break": ("broke", "broken"),
    "fly": ("flew", "flown"), "grow": ("grew", "grown"), "draw": ("drew", "drawn"),
    "throw": ("threw", "thrown"), "wake": ("woke", "woken"), "rise": ("rose", "risen"),
    "ride": ("rode", "ridden"), "put": ("put", "put"), "cut": ("cut", "cut"), "hit": ("hit", "hit"),
    "let": ("let", "let"), "set": ("set", "set"), "shut": ("shut", "shut"),
}
# words whose bare form is read as a verb unless the context says noun
_VERB_FIRST = {"help"}
_IRREG_PL = {"children": "child", "men": "man", "women": "woman", "people": "person",
             "feet": "foot", "teeth": "tooth", "mice": "mouse", "geese": "goose"}
_NEG_SPECIAL = {"can't": ("can", ["can", "'t"]), "won't": ("will", ["wo", "n't"]),
                "cannot": ("can", ["can", "not"])}
_AUX_NEG = {"do", "does", "did", "is", "are", "was", "were", "have", "has", "had", "could", "would",
            "should", "must", "need", "ai"}
_AUX_FORMS = {  # surface -> (lemma, features)
    "am": ("be", "person=1st;number=singular;tense=present"),
    "is": ("be", "person=3rd;number=singular;tense=present"),
    "are": ("be", "tense=present"),
    "was": ("be", "tense=past;number=singular"),
    "were": ("be", "tense=past;number=plural"),
    "been": ("be", "form=past-participle"),
    "being": ("be", "form=present-participle"),
    "has": ("have", "person=3rd;number=singular;tense=present"),
    "does": ("do", "person=3rd;number=singular;tense=present"),
    "could": ("can", "type=modal;tense=past/conditional"),
    "would": ("will", "type=modal;mood=conditional"),
    "should": ("shall", "type=modal"),
    "might": ("may", "type=modal"),
    "can": ("can", "type=modal"),
    "will": ("will", "type=modal;tense=future"),
    "shall": ("shall", "type=modal"),
    "may": ("may", "type=modal"),
    "must": ("must", "type=modal"),
}


def _feats(s: str) -> dict[str, str]:
    from .morph_common import parse_feats
    return parse_feats(s)


def _A(lemma, pos, morphs, feats="", prio=5, src="lexicon", gloss=""):
    return Analysis(lemma, pos, morphs, gloss, _feats(feats) if isinstance(feats, str) else feats, src, prio)


def _vowelish(c: str) -> bool:
    return c in "aeiou"


def _candidates_s(w: str) -> list[str]:
    out = []
    if w.endswith("ies") and len(w) > 4:
        out.append(w[:-3] + "y")
    if w.endswith("es") and len(w) > 3:
        out.append(w[:-2])
        out.append(w[:-1])          # houses -> house, boxes handled by -es
    if w.endswith("s") and not w.endswith("ss") and len(w) > 2:
        out.append(w[:-1])
    seen, res = set(), []
    for c in out:
        if c not in seen:
            seen.add(c)
            res.append(c)
    return res


def _candidates_ed(w: str) -> list[str]:
    out = []
    if w.endswith("ied") and len(w) > 4:
        out.append(w[:-3] + "y")
    if w.endswith("ed") and len(w) > 3:
        base = w[:-2]
        out += [base, base + "e"]
        if len(base) > 2 and base[-1] == base[-2] and not _vowelish(base[-1]):
            out.append(base[:-1])
    return out


def _candidates_ing(w: str) -> list[str]:
    out = []
    if w.endswith("ing") and len(w) > 4:
        base = w[:-3]
        out += [base, base + "e"]
        if len(base) > 2 and base[-1] == base[-2] and not _vowelish(base[-1]):
            out.append(base[:-1])
        if base.endswith("y") is False and w.endswith("ying"):
            pass
    if w.endswith("ying") and len(w) > 5:
        out.append(w[:-4] + "ie")      # lying -> lie
    return out


def _candidates_er(w: str, suf: str) -> list[str]:
    out = []
    if w.endswith(suf) and len(w) > len(suf) + 1:
        base = w[: -len(suf)]
        out += [base, base + "e"]
        if base.endswith("i"):
            out.append(base[:-1] + "y")
        if len(base) > 2 and base[-1] == base[-2]:
            out.append(base[:-1])
    return out


def _past_segment(base: str, form: str) -> list[tuple[str, str]] | None:
    """Segment an irregular -en / -n participle on the longest common prefix with its base."""
    k = 0
    while k < min(len(base), len(form)) and base[k] == form[k]:
        k += 1
    if k >= 3 and k >= 0.6 * len(base) and form[k:] in ("en", "n", "ten", "ne"):
        return [(form[:k], ""), (form[k:], "PASTPTCP")]
    return None


def _irregular_forms() -> dict[str, list[Analysis]]:
    idx: dict[str, list[Analysis]] = {}

    def put(form, a):
        idx.setdefault(form, []).append(a)

    for base, (past, pp) in _IRREG_V.items():
        for p in past.split("/"):
            put(p, _A(base, "verb", [(p, "")], "tense=past", 3, "fixed"))
        if pp not in past.split("/"):
            seg = _past_segment(base, pp)
            if seg:
                put(pp, _A(base, "verb", seg, "", 3, "fixed"))
            else:
                put(pp, _A(base, "verb", [(pp, "")], "form=past-participle", 3, "fixed"))
    for plural, singular in _IRREG_PL.items():
        put(plural, _A(singular, "noun", [(plural, "")], "number=plural", 3, "fixed"))
    for surface, (lemma, feats) in _AUX_FORMS.items():
        put(surface, _A(lemma, "verb", [(surface, "")], feats, 2, "fixed"))
    return idx


_IRREGULAR = _irregular_forms()


def _lemma_pos(word: str) -> list[Analysis] | None:
    """Exact base-form analyses (closed class + open class)."""
    w = word
    res: list[Analysis] = []
    if w in _PRON:
        lemma, f = _PRON[w]
        res.append(_A(lemma, "pronoun", [(w, "")], f, 1, "fixed"))
    if w in _DET_POSS:
        lemma, f = _DET_POSS[w]
        res.append(_A(lemma, "determiner", [(w, "")], f, 1, "fixed"))
    if w in _DET:
        res.append(_A(w, "determiner", [(w, "")], _DET[w], 2 if w == "no" else 1, "fixed"))
    if w in ("this", "that", "these", "those"):
        res.append(_A(w, "pronoun", [(w, "")], _DET[w], 3, "fixed"))
    if w in _PREP:
        res.append(_A(w, "preposition", [(w, "")], "", 1, "fixed"))
    if w in _CONJ:
        res.append(_A(w, "conjunction", [(w, "")], "", 1, "fixed"))
    if w in _PART:
        res.append(_A(w, "particle", [(w, "")], _PART[w], 1, "fixed"))
    if w in _INTERJ:
        res.append(_A(w, "interjection", [(w, "")], "", 1, "fixed"))
    if w in _ADV:
        res.append(_A(w, "adverb", [(w, "")], "type=interrogative" if w in ("how", "where", "when", "why") else "", 2, "fixed"))
    if w in _AUX_FORMS:
        pass  # produced by the irregular table
    if w in _ADJ:
        res.append(_A(w, "adjective", [(w, "")], "", 4))
    if w in ("beautiful",):
        pass
    if w in _NOUNS:
        res.append(_A(w, "noun", [(w, "")], "number=singular", 5))
    if w in _VERBS:
        res.append(_A(w, "verb", [(w, "")], "form=base", 4 if w in _VERB_FIRST else 6))
    return res or None


def _inflected(w: str) -> list[Analysis]:
    out: list[Analysis] = []
    # plural nouns / 3sg verbs
    for stem in _candidates_s(w):
        if stem in _NOUNS:
            out.append(_A(stem, "noun", [(stem, ""), (w[len(stem):], "PLURAL")], "", 5))
        if stem in _VERBS:
            out.append(_A(stem, "verb", [(stem, ""), (w[len(stem):], "3SG.PRES")], "", 6))
    # -ing
    for stem in _candidates_ing(w):
        if stem in _VERBS:
            cut = len(w) - 3
            seg = [(w[:cut], ""), ("ing", "PRESPTCP")] if w[:cut] == stem else [(stem if stem == w[:len(stem)] else w[:cut], ""), ("ing", "PRESPTCP")]
            out.append(_A(stem, "verb", seg, "", 6))
    # -ed
    for stem in _candidates_ed(w):
        if stem in _VERBS and stem not in _IRREG_V:
            cut = len(w) - 2
            out.append(_A(stem, "verb", [(w[:cut] if not w.endswith("ied") else w[:-3] + "i", ""), ("ed", "PAST.EN")], "", 6))
    # comparative / superlative
    for suf, tag in (("er", "COMP"), ("est", "SUPER")):
        for stem in _candidates_er(w, suf):
            if stem in _ADJ:
                out.append(_A(stem, "adjective", [(w[: -len(suf)], ""), (suf, tag)], "", 4))
    # -ly adverbs
    if w.endswith("ly") and len(w) > 4:
        for stem in (w[:-2], w[:-3] + "y" if w.endswith("ily") else w[:-2], w[:-2] + "e"):
            if stem in _ADJ:
                out.append(_A(stem, "adverb", [(w[:-2], ""), ("ly", "ADVL")], "", 4))
                break
    # possessive 's
    if w.endswith("'s") and len(w) > 3:
        base = w[:-2]
        for a in _lemma_pos(base) or []:
            if a.pos == "noun":
                out.append(_A(base, "noun", [(base, ""), ("'s", "POSS")], "", 5))
    return out


def _negated(w: str) -> list[Analysis]:
    if w in _NEG_SPECIAL:
        lemma, parts = _NEG_SPECIAL[w]
        morphs = [(parts[0], "")] + [(p, "NEG") for p in parts[1:]]
        return [_A(lemma, "verb", morphs, "polarity=negative", 2, "fixed")]
    if w.endswith("n't") and len(w) > 4:
        stem = w[:-3]
        lemma = _AUX_FORMS.get(stem, (stem, ""))[0] if stem not in _IRREG_V else stem
        if stem in _AUX_NEG or stem in _AUX_FORMS or stem in _VERBS:
            return [_A(lemma, "verb", [(stem, ""), ("n't", "NEG")], "polarity=negative", 2, "fixed")]
    return []


def _heuristic(w: str) -> Analysis:
    if w.endswith("ing") and len(w) > 5:
        return _A(w[:-3], "verb", [(w[:-3], ""), ("ing", "PRESPTCP")], "", 9, "heuristic")
    if w.endswith("ed") and len(w) > 4:
        return _A(w[:-2], "verb", [(w[:-2], ""), ("ed", "PAST.EN")], "", 9, "heuristic")
    if w.endswith("ly") and len(w) > 4:
        return _A(w[:-2], "adverb", [(w[:-2], ""), ("ly", "ADVL")], "", 9, "heuristic")
    if w.endswith("ies") and len(w) > 4:
        return _A(w[:-3] + "y", "noun", [(w[:-3] + "y", ""), ("", "")][:1], "", 9, "heuristic")
    if w.endswith("s") and not w.endswith("ss") and len(w) > 3:
        return _A(w[:-1], "noun", [(w[:-1], ""), ("s", "PLURAL")], "", 9, "heuristic")
    return _A(w, "noun", [(w, "")], "", 10, "heuristic")


def analyse(token: str) -> list[Analysis]:
    """All readings of one English word, best first."""
    w = token.replace("’", "'").lower()
    out: list[Analysis] = []
    out += _negated(w)
    out += _IRREGULAR.get(w, [])
    out += _lemma_pos(w) or []
    out += _inflected(w)
    if not out:
        out = [_heuristic(w)]
    # keep the token's own spelling for the first (stem) morph of base forms: lowercase compare only
    out.sort(key=lambda a: a.priority)
    return [_restore_case(a, token.replace("\u2019", "'")) for a in out]


def _restore_case(a: Analysis, original: str) -> Analysis:
    """Surfaces are lower-cased except the pronoun I."""
    if original != "I":
        return a
    if "".join(m for m, _ in a.morphs).lower() != original.lower() or len(original) != sum(len(m) for m, _ in a.morphs):
        return a
    pos, morphs = 0, []
    for m, t in a.morphs:
        morphs.append((original[pos:pos + len(m)], t))
        pos += len(m)
    a.morphs = morphs
    return a


# ── context disambiguation ───────────────────────────────────────────────────────
_VERB_CTX = {"i", "you", "we", "they", "he", "she", "it", "to", "can", "could", "will", "would", "shall",
             "should", "may", "might", "must", "do", "does", "did", "don't", "doesn't", "didn't", "let",
             "please", "who"}
_NOUN_CTX = set(_DET) | set(_DET_POSS) | {"a", "an", "the", "some", "any", "good", "bad", "big", "small",
                                         "new", "old", "great", "little", "of", "for", "with"}
_AUX_NEXT = {"is", "are", "was", "were", "am", "can", "will", "has", "have", "had", "does", "do", "did",
             "means", "looks", "seems", "should", "would", "could"}


def disambiguate(readings: list[Analysis], prev: str | None, nxt: str | None, word: str) -> list[Analysis]:
    if len(readings) < 2 or (prev is None and nxt is None):
        return readings          # isolated token: default reading
    p = (prev or "").replace("’", "'").lower()
    n = (nxt or "").lower()
    pos_prefs: list[str] = []
    if word == "no":
        pos_prefs = ["determiner", "particle"] if n and n.isalpha() else ["particle", "determiner"]
    elif word in ("this", "that", "these", "those"):
        pos_prefs = ["pronoun", "determiner"] if (not n or n in _AUX_NEXT or n in _CONJ or n in _PREP) \
            else ["determiner", "pronoun"]
    elif p in _VERB_CTX:
        pos_prefs = ["verb"]
    elif p in _NOUN_CTX:
        pos_prefs = ["noun", "adjective"]
    if not pos_prefs:
        return readings
    ranked = sorted(readings, key=lambda a: (pos_prefs.index(a.pos) if a.pos in pos_prefs else len(pos_prefs), a.priority))
    return ranked
