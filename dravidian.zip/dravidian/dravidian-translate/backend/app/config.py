"""Central configuration. Everything is overridable through environment variables."""
import os

# "real" loads the AI4Bharat / Tesseract engines. "mock" uses lightweight fakes
# so the API, tests and the frontend can be exercised without model downloads.
ENGINE_MODE = os.getenv("ENGINE_MODE", "real").lower()

DEVICE = os.getenv("DEVICE", "auto")  # auto | cpu | cuda

# Model ids (Hugging Face). Distilled variants run on CPU.
MT_INDIC_EN = os.getenv("MT_INDIC_EN", "ai4bharat/indictrans2-indic-en-dist-200M")
MT_EN_INDIC = os.getenv("MT_EN_INDIC", "ai4bharat/indictrans2-en-indic-dist-200M")
MT_INDIC_INDIC = os.getenv("MT_INDIC_INDIC", "ai4bharat/indictrans2-indic-indic-dist-320M")
ASR_MODEL = os.getenv("ASR_MODEL", "ai4bharat/indic-conformer-600m-multilingual")
TTS_MODEL = os.getenv("TTS_MODEL", "ai4bharat/indic-parler-tts")

MAX_TEXT_CHARS = int(os.getenv("MAX_TEXT_CHARS", "5000"))
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "10"))
MAX_AUDIO_SECONDS = int(os.getenv("MAX_AUDIO_SECONDS", "60"))
NUM_BEAMS = int(os.getenv("NUM_BEAMS", "4"))

CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
