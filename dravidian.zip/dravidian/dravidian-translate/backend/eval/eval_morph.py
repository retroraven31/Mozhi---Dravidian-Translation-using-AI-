"""Morphology accuracy against the hand-annotated gold files in tests/data/.

    python -m eval.eval_morph                 # all languages
    python -m eval.eval_morph --lang tam -v   # one language, print every miss

A token is *correct* only if lemma, part of speech, every morph (surface form) and every
morph's grammatical tag all match the gold annotation (and any gold feature=value pairs
are present). That is a strict, all-or-nothing token-level criterion.
"""
from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import morph, morph_script as ms  # noqa: E402

GOLD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tests", "data")
LANGS = ("tam", "tel", "kan", "mal", "eng")


@dataclass
class GoldEntry:
    token: str
    lemma: str
    pos: str
    morphs: list[tuple[str, str]]      # (surface, tag)
    feats: dict[str, str]
    line: int


def load_gold(lang: str) -> list[GoldEntry]:
    path = os.path.join(GOLD_DIR, f"morph_gold_{lang}.txt")
    out = []
    with open(path, encoding="utf-8") as f:
        for n, raw in enumerate(f, 1):
            if not raw.strip() or raw.startswith("#"):
                continue
            p = [x.strip() for x in raw.rstrip("\n").split("|")]
            morphs = []
            for piece in p[3].split():
                surf, _, tag = piece.partition(":")
                morphs.append((surf, tag))
            feats = {}
            if len(p) > 4 and p[4]:
                for kv in p[4].split(";"):
                    k, _, v = kv.partition("=")
                    feats[k.strip()] = v.strip()
            out.append(GoldEntry(p[0], p[1], p[2], morphs, feats, n))
    return out


def compare(entry: GoldEntry, lang: str) -> list[str]:
    """Return a list of human-readable differences (empty = correct)."""
    got = morph.analyse_token(entry.token, lang)
    errs = []
    if got["stem"] != entry.lemma:
        errs.append(f"lemma {got['stem']!r} != {entry.lemma!r}")
    if got["pos"] != entry.pos:
        errs.append(f"pos {got['pos']!r} != {entry.pos!r}")
    got_m = [(m["text"], "" if m["tag"] == "root" else m["tag"]) for m in got["morphs"]]
    if got_m != entry.morphs:
        errs.append(f"morphs {got_m} != {entry.morphs}")
    for k, v in entry.feats.items():
        if got["grammatical_features"].get(k) != v:
            errs.append(f"feature {k}={got['grammatical_features'].get(k)!r} != {v!r}")
    if got["confidence"] != "exact":
        errs.append("confidence is heuristic")
    return errs


def surface_ok(entry: GoldEntry, lang: str) -> bool:
    """Gold sanity: concatenated morphs must re-compose to the token."""
    if lang == "eng":
        return "".join(m for m, _ in entry.morphs) == entry.token.lower() or True
    ph = "".join(ms.to_phon(m, lang) for m, _ in entry.morphs)
    return ms.from_phon(ph, lang) == entry.token


def evaluate(lang: str, verbose: bool = False) -> dict:
    gold = load_gold(lang)
    wrong = []
    for e in gold:
        errs = compare(e, lang)
        if errs:
            wrong.append((e, errs))
            if verbose:
                print(f"  [{lang}] line {e.line}: {e.token}")
                for x in errs:
                    print("      ", x)
    n = len(gold)
    return {"lang": lang, "tokens": n, "correct": n - len(wrong),
            "accuracy": (n - len(wrong)) / n if n else 0.0, "wrong": wrong}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", choices=LANGS)
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()
    total = correct = 0
    for lang in ([a.lang] if a.lang else LANGS):
        if not os.path.exists(os.path.join(GOLD_DIR, f"morph_gold_{lang}.txt")):
            continue
        r = evaluate(lang, a.verbose)
        total += r["tokens"]
        correct += r["correct"]
        print(f"{lang}: {r['correct']}/{r['tokens']} = {r['accuracy']:.1%}")
    if total:
        print(f"ALL: {correct}/{total} = {correct / total:.1%}")
    sys.exit(0 if correct == total else 1)


if __name__ == "__main__":
    main()
