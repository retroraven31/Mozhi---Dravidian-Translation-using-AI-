"""ASR quality: WER and CER (jiwer).

Manifest TSV (path relative to the manifest, then reference transcript):
    clips/ta_001.wav<TAB>இன்று வானிலை நன்றாக உள்ளது
Record ~50-100 clips per language from several speakers; include noisy-room clips
and report them separately - noise is where real-world ASR degrades.

    python -m eval.eval_asr --lang tam --manifest data/asr_tam/manifest.tsv
"""
import argparse
import os

import jiwer

from app import audio
from app.engines import registry
from eval.common import normalize, read_pairs, save_result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", required=True)
    ap.add_argument("--manifest", required=True)
    a = ap.parse_args()

    base = os.path.dirname(os.path.abspath(a.manifest))
    refs, hyps = [], []
    for rel, ref in read_pairs(a.manifest):
        with open(os.path.join(base, rel), "rb") as f:
            samples = audio.to_pcm16k(f.read())
        hyps.append(normalize(registry.asr().transcribe(samples, a.lang)))
        refs.append(normalize(ref))

    result = {"lang": a.lang, "n": len(refs),
              "wer": round(jiwer.wer(refs, hyps) * 100, 2),
              "cer": round(jiwer.cer(refs, hyps) * 100, 2)}
    print(result)
    print("saved:", save_result(f"asr_{a.lang}", result))


if __name__ == "__main__":
    main()
