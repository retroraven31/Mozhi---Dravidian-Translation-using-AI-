"""Translation quality: BLEU and chrF++ (sacrebleu).

Input: two line-aligned UTF-8 files (one sentence per line), e.g. FLORES-200 devtest:
    python -m eval.eval_translation --src tam --tgt eng \
        --src-file flores200/devtest/tam_Taml.devtest --ref-file flores200/devtest/eng_Latn.devtest

chrF++ is the primary metric for Dravidian targets: they are agglutinative, so
word-level BLEU under-scores correct translations.
Run once per direction and report all 20 pairs (5 languages x 4) in the thesis table.
"""
import argparse
import time

import sacrebleu

from app.engines import registry
from eval.common import save_result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--tgt", required=True)
    ap.add_argument("--src-file", required=True)
    ap.add_argument("--ref-file", required=True)
    ap.add_argument("--limit", type=int, default=0, help="Use first N sentences (0 = all)")
    a = ap.parse_args()

    src = [l.strip() for l in open(a.src_file, encoding="utf-8")]
    ref = [l.strip() for l in open(a.ref_file, encoding="utf-8")]
    if len(src) != len(ref):
        raise SystemExit(f"Line count mismatch: {len(src)} vs {len(ref)}")
    if a.limit:
        src, ref = src[:a.limit], ref[:a.limit]

    t0 = time.time()
    hyp = registry.translator().translate(src, a.src, a.tgt)
    secs = time.time() - t0

    bleu = sacrebleu.corpus_bleu(hyp, [ref], tokenize="none" if a.tgt != "eng" else "13a")
    chrf = sacrebleu.corpus_chrf(hyp, [ref], word_order=2)  # chrF++
    result = {
        "pair": f"{a.src}->{a.tgt}", "n": len(src),
        "bleu": round(bleu.score, 2), "chrf++": round(chrf.score, 2),
        "sec_per_sentence": round(secs / len(src), 3),
        "sacrebleu_signature": str(chrf),
    }
    print(result)
    print("saved:", save_result(f"translation_{a.src}_{a.tgt}", result))


if __name__ == "__main__":
    main()
