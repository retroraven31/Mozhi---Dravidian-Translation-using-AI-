"""OCR quality: character error rate (jiwer).

Manifest TSV (image path relative to the manifest, then the exact text in the image;
use \\n for line breaks inside the reference):
    imgs/sign_01.jpg<TAB>பேருந்து நிலையம்

Build the set from real conditions: printed documents, signboards, phone photos
at an angle, low light. Report each condition separately.

    python -m eval.eval_ocr --lang tam --manifest data/ocr_tam/manifest.tsv
"""
import argparse
import os

import jiwer

from app.engines import registry
from eval.common import normalize, read_pairs, save_result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", required=True)
    ap.add_argument("--manifest", required=True)
    a = ap.parse_args()

    base = os.path.dirname(os.path.abspath(a.manifest))
    refs, hyps = [], []
    for rel, ref in read_pairs(a.manifest):
        with open(os.path.join(base, rel), "rb") as f:
            res = registry.ocr().read(f.read(), a.lang)
        hyps.append(normalize(res.text))
        refs.append(normalize(ref.replace("\\n", " ")))

    result = {"lang": a.lang, "n": len(refs), "cer": round(jiwer.cer(refs, hyps) * 100, 2)}
    print(result)
    print("saved:", save_result(f"ocr_{a.lang}", result))


if __name__ == "__main__":
    main()
