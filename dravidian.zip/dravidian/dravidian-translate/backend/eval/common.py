import json
import os
import re
import sys
import unicodedata
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

_PUNCT = re.compile(r"[^\w\s]", re.UNICODE)


def normalize(text: str) -> str:
    """NFC + strip punctuation + collapse whitespace, so scores reflect words, not punctuation."""
    text = unicodedata.normalize("NFC", text)
    return " ".join(_PUNCT.sub(" ", text).split())


def read_pairs(path: str) -> list[tuple[str, str]]:
    """TSV with two columns (input<TAB>reference); lines starting with # are skipped."""
    pairs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            a, _, b = line.partition("\t")
            if not b:
                raise ValueError(f"Expected 2 tab-separated columns: {line[:60]!r}")
            pairs.append((a, b))
    return pairs


def save_result(name: str, result: dict) -> str:
    os.makedirs(os.path.join(os.path.dirname(__file__), "results"), exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = os.path.join(os.path.dirname(__file__), "results", f"{name}_{stamp}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"timestamp_utc": stamp, **result}, f, ensure_ascii=False, indent=2)
    return path
