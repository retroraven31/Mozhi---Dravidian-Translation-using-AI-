import React, { Component, useRef, useState, useCallback, useEffect } from "react";
import * as api from "./api.js";

/* ─────────────────────────── Constants ─────────────────────────── */
const LANGS = [
  { code: "tam", name: "தமிழ்", label: "Tamil",     flag: "🏺", script: "Tamil" },
  { code: "tel", name: "తెలుగు", label: "Telugu",   flag: "🌺", script: "Telugu" },
  { code: "kan", name: "ಕನ್ನಡ", label: "Kannada",  flag: "🌿", script: "Kannada" },
  { code: "mal", name: "മലയാളം", label: "Malayalam",flag: "🌴", script: "Malayalam" },
  { code: "eng", name: "English",label: "English",   flag: "🔤", script: "Latin" },
];

const LANG_INFO_STATIC = {
  tam: {
    speakers: "80 million",
    branch: "South Dravidian I",
    grammar: "Agglutinative",
    wordOrder: "SOV",
    script: "Tamil script",
    unicode: "U+0B80–U+0BFF",
    facts: [
      "Tamil is one of the longest-surviving classical languages, with literature dating back over 2,000 years.",
      "It is the only language in India with the status of Classical Language based on its ancient literature.",
      "Tamil has a unique diglossia: literary (Sentamil) and colloquial (Koduntamil) forms differ greatly.",
    ],
    comparisons: [
      { word: "Water", native: "நீர் / தண்ணீர்", transliteration: "Nīr / Taṇṇīr" },
      { word: "Love",  native: "அன்பு",          transliteration: "Anbu" },
      { word: "Sky",   native: "வானம்",          transliteration: "Vānam" },
    ],
  },
  tel: {
    speakers: "96 million",
    branch: "South-Central Dravidian",
    grammar: "Agglutinative",
    wordOrder: "SOV",
    script: "Telugu script",
    unicode: "U+0C00–U+0C7F",
    facts: [
      "Telugu is the most widely spoken Dravidian language and ranks as a scheduled language of India.",
      "Known as the 'Italian of the East' for its phonological structure where every word ends in a vowel.",
      "Telugu script is an abugida derived from the Brahmi family, sharing features with Kannada script.",
    ],
    comparisons: [
      { word: "Water", native: "నీరు / నీళ్ళు", transliteration: "Nīru / Nīḷḷu" },
      { word: "Love",  native: "ప్రేమ",          transliteration: "Prēma" },
      { word: "Sky",   native: "ఆకాశం",          transliteration: "Ākāśaṁ" },
    ],
  },
  kan: {
    speakers: "56 million",
    branch: "South Dravidian II",
    grammar: "Agglutinative",
    wordOrder: "SOV",
    script: "Kannada script",
    unicode: "U+0C80–U+0CFF",
    facts: [
      "Kannada has the world's oldest inscription of a Dravidian language, the Halmidi inscription from ~450 CE.",
      "It has a rich literary tradition spanning over 1500 years, with works like Kavirajamarga.",
      "Kannada makes gender distinctions for masculine, feminine, and neuter even in verb forms.",
    ],
    comparisons: [
      { word: "Water", native: "ನೀರು",           transliteration: "Nīru" },
      { word: "Love",  native: "ಪ್ರೀತಿ",          transliteration: "Prīti" },
      { word: "Sky",   native: "ಆಕಾಶ",            transliteration: "Ākāśa" },
    ],
  },
  mal: {
    speakers: "38 million",
    branch: "South Dravidian I",
    grammar: "Agglutinative",
    wordOrder: "SOV",
    script: "Malayalam script",
    unicode: "U+0D00–U+0D7F",
    facts: [
      "Malayalam has the largest number of letters among major Indian languages, with 578 characters.",
      "The language evolved from Tamil-Brahmi, diverging significantly in the 13th century CE.",
      "Malayalam is the official language of Kerala and the Lakshadweep islands.",
    ],
    comparisons: [
      { word: "Water", native: "വെള്ളം / നീർ",   transliteration: "Veḷḷaṁ / Nīr" },
      { word: "Love",  native: "സ്നേഹം",          transliteration: "Snēhaṁ" },
      { word: "Sky",   native: "ആകാശം",           transliteration: "Ākāśaṁ" },
    ],
  },
  eng: {
    speakers: "1.5 billion",
    branch: "West Germanic",
    grammar: "Analytic",
    wordOrder: "SVO",
    script: "Latin script",
    unicode: "U+0000–U+007F",
    facts: [
      "English is the primary target/source language for all translation pairs in Mozhi.",
      "Many Dravidian words have entered English via colonial-era contact, e.g. 'catamaran' (Tamil: கட்டுமரம்).",
      "English uses a fixed Subject-Verb-Object word order, contrasting with the SOV order of Dravidian languages.",
    ],
    comparisons: [],
  },
};

// Cross-language comparison words (shown for Dravidian source langs)
const CROSS_COMPARISONS = [
  { word: "Water",    tam: "நீர்",    tel: "నీరు",    kan: "ನೀರು",    mal: "വെള്ളം" },
  { word: "Love",     tam: "அன்பு",   tel: "ప్రేమ",   kan: "ಪ್ರೀತಿ",  mal: "സ്നേഹം" },
  { word: "Mother",   tam: "அம்மா",   tel: "అమ్మ",    kan: "ಅಮ್ಮ",    mal: "അമ്മ" },
  { word: "Sky",      tam: "வானம்",   tel: "ఆకాశం",   kan: "ಆಕಾಶ",    mal: "ആകാശം" },
  { word: "Home",     tam: "வீடு",    tel: "ఇల్లు",   kan: "ಮನೆ",     mal: "വീട്" },
];

const MAX_RECORD_SECONDS = 60;

/* ─────────────────────────── Helpers ─────────────────────────── */
function getLangByCode(code) { return LANGS.find(l => l.code === code); }

function getCharCategory(codePoint) {
  // Tamil: U+0B80–U+0BFF
  if (codePoint >= 0x0B80 && codePoint <= 0x0BFF) {
    if ((codePoint >= 0x0B85 && codePoint <= 0x0B8A) ||
        (codePoint >= 0x0B8E && codePoint <= 0x0B90) ||
        (codePoint >= 0x0B92 && codePoint <= 0x0B95)) return "vowel";
    if (codePoint >= 0x0BBE && codePoint <= 0x0BCD) {
      if (codePoint === 0x0BCD) return "virama";
      return "matra";
    }
    if (codePoint >= 0x0B95 && codePoint <= 0x0BB9) return "consonant";
    return "other";
  }
  // Telugu: U+0C00–U+0C7F
  if (codePoint >= 0x0C00 && codePoint <= 0x0C7F) {
    if (codePoint >= 0x0C05 && codePoint <= 0x0C14) return "vowel";
    if (codePoint >= 0x0C3E && codePoint <= 0x0C4D) {
      if (codePoint === 0x0C4D) return "virama";
      return "matra";
    }
    if (codePoint >= 0x0C15 && codePoint <= 0x0C39) return "consonant";
    return "other";
  }
  // Kannada: U+0C80–U+0CFF
  if (codePoint >= 0x0C80 && codePoint <= 0x0CFF) {
    if (codePoint >= 0x0C85 && codePoint <= 0x0C94) return "vowel";
    if (codePoint >= 0x0CBE && codePoint <= 0x0CCD) {
      if (codePoint === 0x0CCD) return "virama";
      return "matra";
    }
    if (codePoint >= 0x0C95 && codePoint <= 0x0CB9) return "consonant";
    return "other";
  }
  // Malayalam: U+0D00–U+0D7F
  if (codePoint >= 0x0D00 && codePoint <= 0x0D7F) {
    if (codePoint >= 0x0D05 && codePoint <= 0x0D14) return "vowel";
    if (codePoint >= 0x0D3E && codePoint <= 0x0D4D) {
      if (codePoint === 0x0D4D) return "virama";
      return "matra";
    }
    if (codePoint >= 0x0D15 && codePoint <= 0x0D39) return "consonant";
    return "other";
  }
  if (codePoint === 0x0020) return "space";
  return "other";
}

function buildCharCells(text) {
  const cells = [];
  const seen = new Set();
  for (const char of text) {
    if (char === ' ' || char === '\n') continue;
    if (seen.has(char)) continue;
    seen.add(char);
    const cp = char.codePointAt(0);
    const cat = getCharCategory(cp);
    cells.push({ char, codePoint: cp, category: cat });
  }
  return cells;
}

/* ─────────────────────────── Sub-components ─────────────────────────── */

function ShimmerBlock({ lines = 3 }) {
  const widths = ["w90", "w80", "w60", "w80", "w90"];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className={`shimmer shimmer-line ${widths[i % widths.length]}`} />
      ))}
    </div>
  );
}

/* ── Error Boundary to prevent page from ever blanking out ── */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="glass-card" style={{ padding: "18px 22px", marginTop: 16, border: "1px solid rgba(245, 166, 35, 0.4)" }}>
          <div style={{ color: "var(--accent-gold)", fontWeight: 600, fontSize: "1rem" }}>✨ Visual View Refreshed</div>
          <div style={{ color: "var(--text-muted)", fontSize: "0.85rem", marginTop: 6 }}>
            {this.state.error?.message || "Input analysis completed successfully."}
          </div>
          <button
            type="button"
            className="chip-btn"
            style={{ marginTop: 12, borderColor: "var(--accent-gold)", color: "var(--accent-gold)" }}
            onClick={() => this.setState({ hasError: false, error: null })}
          >
            Refresh panel
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

function TokenCard({ token }) {
  const [expanded, setExpanded] = useState(false);
  if (!token) return null;

  const word = token.token || token.word || "";
  const stem = token.stem || token.root || "";
  const pos = token.pos || "";
  const suffixes = Array.isArray(token.suffixes) ? token.suffixes : [];
  const features = token.grammatical_features || token.features || {};

  return (
    <div
      className={`token-card ${expanded ? "expanded" : ""}`}
      onClick={() => setExpanded(e => !e)}
      title="Click to inspect features"
    >
      <div className="token-word">{word}</div>
      {stem && stem !== word && (
        <div className="token-root">
          Root: <span className="token-root-word">{stem}</span>
        </div>
      )}
      {token.gloss && <div className="token-root">{token.gloss}</div>}
      <div className="token-badges">
        {pos && <span className="badge badge-pos">{String(pos).toUpperCase()}</span>}
        {token.confidence === "heuristic" && (
          <span className="badge" title="Not in the lexicon: analysed by suffix rules, may be wrong">guess</span>
        )}
        {suffixes.map((s, i) => {
          const suffixText = typeof s === "object" && s !== null ? (s.suffix || JSON.stringify(s)) : String(s);
          const role = typeof s === "object" && s !== null ? s.gram_role : null;
          return (
            <span key={i} title={typeof s === "object" && s ? `${s.tag || ""} ${s.feature || ""}`.trim() : ""}
                  className={`badge badge-suffix ${role ? "badge-role-" + role : ""}`}>
              {suffixText}
            </span>
          );
        })}
      </div>
      {expanded && Object.keys(features).length > 0 && (
        <div className="token-expanded">
          {Object.entries(features).map(([k, v]) => (
            <div key={k} className="token-feat">
              <span className="token-feat-key">{k}</span>
              <span className="token-feat-val">{typeof v === "object" ? JSON.stringify(v) : String(v)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ScriptStatsBar({ stats }) {
  if (!stats) return null;
  const consonants = Number(stats.consonants) || 0;
  const vowels = Number(stats.vowels) || 0;
  const matras = Number(stats.matras) || 0;
  const other = Number(stats.other) || 0;
  const total = consonants + vowels + matras + other;
  if (total === 0) return null;
  const pct = n => `${Math.max(1, Math.round(((Number(n) || 0) / total) * 100))}%`;

  return (
    <div>
      <div className="sub-section-title">Script Statistics</div>
      <div className="script-stats-bar">
        {consonants > 0 && <div className="stat-segment stat-consonant" style={{ flex: consonants }} />}
        {vowels > 0    && <div className="stat-segment stat-vowel"     style={{ flex: vowels }} />}
        {matras > 0    && <div className="stat-segment stat-matra"     style={{ flex: matras }} />}
        {other > 0     && <div className="stat-segment stat-other"     style={{ flex: other }} />}
      </div>
      <div className="stat-labels">
        <div className="stat-label"><div className="stat-dot" style={{background:"var(--accent-purple)"}} /><strong>{consonants}</strong> Consonants ({pct(consonants)})</div>
        <div className="stat-label"><div className="stat-dot" style={{background:"var(--accent-teal)"}} /><strong>{vowels}</strong> Vowels ({pct(vowels)})</div>
        <div className="stat-label"><div className="stat-dot" style={{background:"var(--accent-gold)"}} /><strong>{matras}</strong> Matras ({pct(matras)})</div>
        <div className="stat-label"><div className="stat-dot" style={{background:"rgba(255,255,255,0.15)"}} /><strong>{other}</strong> Other ({pct(other)})</div>
      </div>
    </div>
  );
}

function AgglutinationGauge({ score }) {
  if (score == null) return null;
  const safeScore = Number(score) || 0;
  const pct = Math.min(100, Math.round(safeScore * 100));
  const C = 220;
  const offset = C - (pct / 100) * C;
  const color = pct > 60 ? "var(--accent-teal)" : pct > 30 ? "var(--accent-gold)" : "var(--accent-purple)";
  return (
    <div className="gauge-container">
      <div className="gauge-svg-wrap">
        <svg className="gauge-svg" viewBox="0 0 120 120">
          <circle className="gauge-bg" cx="60" cy="60" r="35" />
          <circle
            className="gauge-fill"
            cx="60" cy="60" r="35"
            stroke={color}
            strokeDasharray={C}
            strokeDashoffset={offset}
          />
        </svg>
        <div className="gauge-label">
          <div className="gauge-pct" style={{ color }}>{pct}%</div>
        </div>
      </div>
      <div className="gauge-info">
        <div className="gauge-title">Agglutination Index</div>
        <div className="gauge-desc">
          Measures the ratio of suffixes/affixes detected per token.
          Dravidian languages are highly agglutinative — words are built by chaining
          morphemes to a root, encoding tense, case, number, and agreement.
          {pct > 60 && " This text shows rich morphological complexity."}
          {pct > 30 && pct <= 60 && " Moderate morphological complexity detected."}
          {pct <= 30 && " Low agglutination — may be short or transliterated text."}
        </div>
      </div>
    </div>
  );
}

function CharacterGrid({ text, fromMorph }) {
  const cells = Array.isArray(fromMorph) && fromMorph.length
    ? fromMorph
    : buildCharCells(text || "");
  if (!cells || !cells.length) return null;

  return (
    <div>
      <div className="sub-section-title">Pictorial · Character Analysis</div>
      <div className="char-grid">
        {cells.map((cell, i) => {
          if (!cell) return null;
          const char = cell.char || "";
          const cat = cell.category || cell.script_category || "other";
          const catClass = `char-${cat}`;
          const catLabel =
            cat === "vowel"     ? "Vowel"
          : cat === "consonant" ? "Consonant"
          : cat === "matra"     ? "Matra"
          : cat === "virama"    ? "Virama"
          : "Other";

          let codeStr = "";
          if (typeof cell.codepoint === "string") {
            codeStr = cell.codepoint;
          } else {
            const cp = cell.codePoint ?? cell.codepoint_int ?? (char ? char.codePointAt(0) : 0);
            codeStr = "U+" + (cp ? cp.toString(16).toUpperCase().padStart(4, "0") : "0000");
          }

          return (
            <div key={i} className={`char-cell ${catClass}`} style={{ animationDelay: `${i * 30}ms` }}>
              <div className="char-glyph">{char}</div>
              <div className="char-code">{codeStr}</div>
              <div className="char-cat">{catLabel}</div>
            </div>
          );
        })}
      </div>
      <div className="stat-labels" style={{ marginTop: 12 }}>
        {[
          { cat: "Vowel",     color: "var(--accent-teal)" },
          { cat: "Consonant", color: "var(--accent-purple)" },
          { cat: "Matra",     color: "var(--accent-gold)" },
          { cat: "Virama",    color: "var(--accent-pink)" },
          { cat: "Other",     color: "rgba(255,255,255,0.3)" },
        ].map(({ cat, color }) => (
          <div key={cat} className="stat-label">
            <div className="stat-dot" style={{ background: color }} />
            {cat}
          </div>
        ))}
      </div>
    </div>
  );
}

function FamilyTree({ activeLang }) {
  const isActiveBranch = (branch) =>
    (branch === "South Dravidian I" && ["tam","mal"].includes(activeLang)) ||
    (branch === "South Dravidian II" && activeLang === "kan") ||
    (branch === "South-Central"      && activeLang === "tel");
  const isActive = (code) => code === activeLang;
  return (
    <div>
      <div className="sub-section-title">Language Family Tree</div>
      <div className="family-tree">
        <div style={{ display: "flex", alignItems: "flex-start", gap: 0, overflowX: "auto" }}>
          {/* Root */}
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
            <div className="family-node family-node-root">Proto-Dravidian</div>
            <div style={{ width: 2, flex: 1, minHeight: 24, background: "var(--glass-border)", margin: "0 auto" }} />
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 8, paddingLeft: 0 }}>
            {/* South Dravidian I branch */}
            <div className="family-row" style={{ flexWrap: "wrap", gap: 6 }}>
              <div className="family-connector">→</div>
              <div className={`family-node ${isActiveBranch("South Dravidian I") ? "family-node-branch" : "family-node-branch"}`}
                   style={isActiveBranch("South Dravidian I") ? {borderColor:"var(--accent-teal)",color:"var(--accent-teal)",background:"var(--accent-teal-dim)"} : {}}>
                South Dravidian I
              </div>
              <div className="family-connector">→</div>
              <div className="family-branches">
                <div className="family-branch-row">
                  <div className={`family-node ${isActive("tam") ? "family-node-active" : "family-node-leaf"}`}>
                    🏺 Tamil
                  </div>
                </div>
                <div className="family-branch-row">
                  <div className={`family-node ${isActive("mal") ? "family-node-active" : "family-node-leaf"}`}>
                    🌴 Malayalam
                  </div>
                </div>
              </div>
            </div>
            {/* South Dravidian II */}
            <div className="family-row" style={{ flexWrap: "wrap", gap: 6 }}>
              <div className="family-connector">→</div>
              <div className="family-node family-node-branch"
                   style={isActiveBranch("South Dravidian II") ? {borderColor:"var(--accent-teal)",color:"var(--accent-teal)",background:"var(--accent-teal-dim)"} : {}}>
                South Dravidian II
              </div>
              <div className="family-connector">→</div>
              <div className={`family-node ${isActive("kan") ? "family-node-active" : "family-node-leaf"}`}>
                🌿 Kannada
              </div>
            </div>
            {/* South-Central */}
            <div className="family-row" style={{ flexWrap: "wrap", gap: 6 }}>
              <div className="family-connector">→</div>
              <div className="family-node family-node-branch"
                   style={isActiveBranch("South-Central") ? {borderColor:"var(--accent-teal)",color:"var(--accent-teal)",background:"var(--accent-teal-dim)"} : {}}>
                South-Central
              </div>
              <div className="family-connector">→</div>
              <div className={`family-node ${isActive("tel") ? "family-node-active" : "family-node-leaf"}`}>
                🌺 Telugu
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LangInfoPanel({ langCode }) {
  const info = LANG_INFO_STATIC[langCode];
  const lang = getLangByCode(langCode);
  if (!info || !lang) return null;
  const isDravidian = langCode !== "eng";

  return (
    <div className="glass-card lang-info-section">
      <div className="sub-section-title" style={{ marginBottom: 16, fontSize: "0.85rem" }}>
        {lang.flag} {lang.name} · {lang.label} — Language Profile
      </div>
      <div className="lang-info-grid">
        <div className="lang-info-cell">
          <div className="lang-info-label">Speakers</div>
          <div className="lang-info-value accent-teal">{info.speakers}</div>
        </div>
        <div className="lang-info-cell">
          <div className="lang-info-label">Branch</div>
          <div className="lang-info-value">{info.branch}</div>
        </div>
        <div className="lang-info-cell">
          <div className="lang-info-label">Grammar</div>
          <div className="lang-info-value accent-gold">{info.grammar}</div>
        </div>
        <div className="lang-info-cell">
          <div className="lang-info-label">Word Order</div>
          <div className="lang-info-value">{info.wordOrder}</div>
        </div>
        <div className="lang-info-cell">
          <div className="lang-info-label">Script</div>
          <div className="lang-info-value">{info.script}</div>
        </div>
        <div className="lang-info-cell">
          <div className="lang-info-label">Unicode Block</div>
          <div className="lang-info-value" style={{ fontSize: "0.78rem", fontFamily: "monospace" }}>{info.unicode}</div>
        </div>
      </div>
      {info.facts?.length > 0 && (
        <div className="lang-facts">
          {info.facts.map((f, i) => <div key={i} className="lang-fact">{f}</div>)}
        </div>
      )}
      {isDravidian && (
        <div>
          <div className="sub-section-title">Cross-Dravidian Comparison</div>
          <table className="compare-table">
            <thead>
              <tr>
                <th>English</th>
                <th>Tamil</th>
                <th>Telugu</th>
                <th>Kannada</th>
                <th>Malayalam</th>
              </tr>
            </thead>
            <tbody>
              {CROSS_COMPARISONS.map((row, i) => (
                <tr key={i}>
                  <td>{row.word}</td>
                  <td className={`script-word ${langCode === "tam" ? "text-gold" : ""}`}>{row.tam}</td>
                  <td className={`script-word ${langCode === "tel" ? "text-gold" : ""}`}>{row.tel}</td>
                  <td className={`script-word ${langCode === "kan" ? "text-gold" : ""}`}>{row.kan}</td>
                  <td className={`script-word ${langCode === "mal" ? "text-gold" : ""}`}>{row.mal}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {isDravidian && <FamilyTree activeLang={langCode} />}
    </div>
  );
}

function MorphAnalysisPanel({
  srcMorph,
  tgtMorph,
  srcText,
  tgtText,
  srcLang,
  tgtLang,
  loading
}) {
  const [open, setOpen] = useState(true);
  const [activeTab, setActiveTab] = useState("target"); // "target" | "source"

  if (!srcMorph && !tgtMorph && !loading) return null;

  const currentMorph = activeTab === "source" ? srcMorph : tgtMorph;
  const currentText  = activeTab === "source" ? srcText  : tgtText;
  const currentLang  = activeTab === "source" ? srcLang  : tgtLang;

  return (
    <div className="glass-card morph-section">
      <div className="accordion-header" onClick={() => setOpen(o => !o)}>
        <div className="accordion-title">
          <div className="accordion-icon-badge">🧬</div>
          Dual Morphological Analysis
          {currentMorph?.tokens && (
            <span style={{ fontSize: "0.75rem", color: "var(--text-muted)", fontWeight: 400 }}>
              — {currentLang?.name}: {currentMorph.tokens.length} token{currentMorph.tokens.length !== 1 ? "s" : ""}
            </span>
          )}
        </div>
        <span className={`accordion-chevron ${open ? "open" : ""}`}>▼</span>
      </div>

      {open && (
        <div className="accordion-body">
          {/* Dual Language Switcher Tabs */}
          <div className="morph-tab-bar">
            <button
              type="button"
              className={`morph-tab-btn ${activeTab === "source" ? "active" : ""}`}
              onClick={() => setActiveTab("source")}
            >
              📥 Source: {srcLang?.name || "Source"}
              {srcMorph?.tokens && (
                <span className="tab-pill">{srcMorph.tokens.length} tokens</span>
              )}
            </button>
            <button
              type="button"
              className={`morph-tab-btn ${activeTab === "target" ? "active" : ""}`}
              onClick={() => setActiveTab("target")}
            >
              📤 Translated: {tgtLang?.name || "Translated"}
              {tgtMorph?.tokens && (
                <span className="tab-pill">{tgtMorph.tokens.length} tokens</span>
              )}
            </button>
          </div>

          {loading ? (
            <ShimmerBlock lines={4} />
          ) : !currentMorph ? (
            <div style={{ padding: "16px", color: "var(--text-muted)", fontSize: "0.85rem", textAlign: "center" }}>
              Morphological breakdown in progress or unavailable for this segment.
            </div>
          ) : (
            <>
              {/* Token Cards */}
              {currentMorph.tokens?.length > 0 && (
                <div>
                  <div className="sub-section-title">
                    Token Analysis ({currentLang?.name})
                  </div>
                  <div className="token-cards">
                    {currentMorph.tokens.map((tok, i) => (
                      <TokenCard key={i} token={tok} />
                    ))}
                  </div>
                </div>
              )}

              {/* Summary */}
              {currentMorph.summary && (
                <div style={{
                  padding: "14px 16px",
                  background: "var(--glass)",
                  border: "1px solid var(--glass-border)",
                  borderRadius: "var(--radius-md)",
                  fontSize: "0.84rem",
                  color: "var(--text-muted)",
                  lineHeight: 1.6,
                }}>
                  💡 {currentMorph.summary}
                </div>
              )}

              {/* Script statistics */}
              <ScriptStatsBar stats={currentMorph.script_stats} />

              {/* Agglutination gauge */}
              <AgglutinationGauge score={currentMorph.agglutination_score} />

              {/* Character grid */}
              <CharacterGrid
                text={currentText}
                fromMorph={
                  currentMorph.script_stats?.char_breakdown
                    ? currentMorph.script_stats.char_breakdown
                    : null
                }
              />
            </>
          )}
        </div>
      )}
    </div>
  );
}

/* ─────────────────────────── Main App ─────────────────────────── */
export default function App() {
  const [mode, setMode]       = useState("text");
  const [src,  setSrc]        = useState("tam");
  const [tgt,  setTgt]        = useState("eng");
  const [input, setInput]     = useState("");
  const [result, setResult]   = useState(null);
  const [srcMorph, setSrcMorph] = useState(null);
  const [tgtMorph, setTgtMorph] = useState(null);
  const [note,  setNote]      = useState(null);
  const [busy,  setBusy]      = useState("");
  const [morphBusy, setMorphBusy] = useState(false);
  const [error, setError]     = useState("");
  const [recording, setRecording] = useState(false);
  const [preview, setPreview] = useState(null);
  const [swapSpin, setSwapSpin] = useState(false);
  const [copied, setCopied]   = useState(false);
  const recorder = useRef(null);
  const chunks   = useRef([]);
  const timer    = useRef(null);
  const audioRef = useRef(null);

  const run = async (label, fn) => {
    setError("");
    setBusy(label);
    try { await fn(); }
    catch (e) { setError(e.message || "Something went wrong"); }
    finally { setBusy(""); }
  };

  const swap = () => {
    if (src === "auto") return;
    setSwapSpin(true);
    setTimeout(() => setSwapSpin(false), 500);
    setSrc(tgt);
    setTgt(src);
    if (result) {
      setInput(result.translation);
      setResult(null);
      setSrcMorph(null);
      setTgtMorph(null);
    }
  };

  const doTranslate = () =>
    run("Translating…", async () => {
      setResult(null);
      setSrcMorph(null);
      setTgtMorph(null);
      const r = await api.translate(input, src, tgt);
      setResult(r);
      if (r.warning) setNote(r.warning);

      const sourceLang = (r.src && r.src !== "auto") ? r.src : (src !== "auto" ? src : "tam");
      const sourceText = r.original_script || input;
      const targetLang = r.tgt || tgt;
      const targetText = r.translation;

      // Fetch dual morphological analysis for both languages in parallel
      setMorphBusy(true);
      try {
        const [sm, tm] = await Promise.all([
          api.morph(sourceText, sourceLang).catch(() => null),
          api.morph(targetText, targetLang).catch(() => null),
        ]);
        setSrcMorph(sm);
        setTgtMorph(tm);
      } finally {
        setMorphBusy(false);
      }
    });

  const startRecording = async () => {
    setError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunks.current = [];
      rec.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
      rec.onstop = () => {
        stream.getTracks().forEach(t => t.stop());
        clearTimeout(timer.current);
        const blob = new Blob(chunks.current, { type: rec.mimeType || "audio/webm" });
        run("Transcribing…", async () => {
          const r = await api.transcribe(blob, src);
          setInput(r.text);
          setNote("Review the transcript and fix any mistakes before translating.");
        });
      };
      rec.start();
      recorder.current = rec;
      setRecording(true);
      timer.current = setTimeout(stopRecording, MAX_RECORD_SECONDS * 1000);
    } catch {
      setError("Microphone access was denied or is unavailable.");
    }
  };

  const stopRecording = () => {
    if (recorder.current && recorder.current.state !== "inactive") recorder.current.stop();
    setRecording(false);
  };

  const onImage = (file) => {
    if (!file) return;
    setPreview(URL.createObjectURL(file));
    run("Reading image…", async () => {
      const r = await api.ocr(file, src);
      setInput(r.text);
      setNote(
        r.text
          ? `OCR confidence ${Math.round(r.confidence)}%. Fix any misread characters before translating.`
          : "No text found. Try a sharper, well-lit photo."
      );
    });
  };

  const [audioPlaying, setAudioPlaying] = useState(false);

  const fallbackSpeech = (textToSpeak, langToSpeak) => {
    const voiceTags = {
      tam: "ta-IN",
      tel: "te-IN",
      kan: "kn-IN",
      mal: "ml-IN",
      eng: "en-IN",
    };
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        const tag = voiceTags[langToSpeak] || "en-US";
        utterance.lang = tag;
        utterance.rate = 0.92;
        const voices = window.speechSynthesis.getVoices();
        const match = voices.find(v => v.lang === tag || v.lang.startsWith(tag.split("-")[0]));
        if (match) utterance.voice = match;
        utterance.onend = () => setAudioPlaying(false);
        utterance.onerror = () => setAudioPlaying(false);
        window.speechSynthesis.speak(utterance);
      } catch {
        setAudioPlaying(false);
      }
    } else {
      setAudioPlaying(false);
    }
  };

  const doSpeak = async (customText, customLang) => {
    const textToSpeak = customText || result?.translation;
    const langToSpeak = customLang || tgt;
    if (!textToSpeak) return;

    setAudioPlaying(true);

    // 1. Primary: Siri / Assistant-grade Neural AI Audio Stream
    try {
      const audioBlobUrl = await api.speak(textToSpeak, langToSpeak);
      const audio = new Audio(audioBlobUrl);
      audio.onended = () => setAudioPlaying(false);
      audio.onerror = () => {
        fallbackSpeech(textToSpeak, langToSpeak);
      };
      await audio.play();
    } catch (e) {
      console.warn("Primary Neural AI Audio stream failed, falling back to Web Speech:", e);
      fallbackSpeech(textToSpeak, langToSpeak);
    }
  };

  const copy = async () => {
    if (!result?.translation) return;
    try {
      await navigator.clipboard.writeText(result.translation);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  const displaySrc = src === "auto" ? "auto" : src;
  const srcLang  = getLangByCode(displaySrc !== "auto" ? displaySrc : "tam");
  const tgtLang  = getLangByCode(tgt);
  const morphLangForDisplay = result
    ? (src !== "eng" ? (result.src || src) : tgt)
    : src !== "eng" ? src : tgt;

  return (
    <div className="app">
      {/* ── Header ── */}
      <header className="header">
        <div className="header-logo">
          <div className="logo-icon">𓆩</div>
          <h1 className="header-title">Mozhi · மொழி</h1>
        </div>
        <p className="header-subtitle">Dravidian Language Intelligence</p>
        <div className="header-badges">
          {["தமிழ்", "తెలుగు", "ಕನ್ನಡ", "മലയാളം"].map(s => (
            <span key={s} className="lang-badge">{s}</span>
          ))}
        </div>
      </header>

      {/* ── Language Selector ── */}
      <div className="lang-selector-row">
        <div className="lang-pill-select">
          <select value={src} onChange={e => { setSrc(e.target.value); setResult(null); setMorphData(null); }} aria-label="From language">
            <option value="auto">🔍 Detect language</option>
            {LANGS.map(l => (
              <option key={l.code} value={l.code}>{l.flag} {l.name} · {l.label}</option>
            ))}
          </select>
        </div>
        <button className={`swap-btn ${swapSpin ? "spinning" : ""}`} onClick={swap}
                disabled={src === "auto"} aria-label="Swap languages" title="Swap languages">
          ⇄
        </button>
        <div className="lang-pill-select">
          <select value={tgt} onChange={e => { setTgt(e.target.value); setResult(null); setMorphData(null); }} aria-label="To language">
            {LANGS.map(l => (
              <option key={l.code} value={l.code}>{l.flag} {l.name} · {l.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* ── Mode Tabs ── */}
      <div className="mode-tabs" role="tablist">
        {[
          { id: "text",  icon: "⌨️", label: "Text"  },
          { id: "voice", icon: "🎤", label: "Voice" },
          { id: "image", icon: "📷", label: "Image" },
        ].map(m => (
          <button key={m.id} role="tab" aria-selected={mode === m.id}
                  className={`mode-tab ${mode === m.id ? "active" : ""}`}
                  onClick={() => { setMode(m.id); setNote(null); }}>
            <span className="tab-icon">{m.icon}</span> {m.label}
          </button>
        ))}
      </div>

      {/* ── Voice Panel ── */}
      {mode === "voice" && (
        <div className="voice-panel">
          {src === "auto" && (
            <div className="hint-text">⚡ Select the spoken language above — voice mode can't auto-detect.</div>
          )}
          <button
            className={`record-btn ${recording ? "recording" : ""}`}
            disabled={src === "auto" || !!busy}
            onClick={recording ? stopRecording : startRecording}
          >
            {recording ? <>■ Stop Recording</> : <>● Start Recording</>}
          </button>
        </div>
      )}

      {/* ── Image Panel ── */}
      {mode === "image" && (
        <div className="image-panel">
          {src === "auto" && (
            <div className="hint-text">⚡ Select the language of the text in the image above.</div>
          )}
          <label className={`upload-label ${(src === "auto" || !!busy) ? "disabled" : ""}`}>
            📷 Take or choose a photo
            <input type="file" accept="image/*" capture="environment" hidden
                   disabled={src === "auto" || !!busy}
                   onChange={e => onImage(e.target.files[0])} />
          </label>
          {preview && <img className="preview-img" src={preview} alt="Selected" />}
        </div>
      )}

      {/* ── Input Area ── */}
      <div className="input-section">
        <div className="input-wrapper">
          <textarea
            className="input-textarea"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder={mode === "text" ? "Type or paste text in any Dravidian language…" : "Recognised text appears here (editable)"}
            rows={5}
            maxLength={5000}
          />
          <div className={`char-count ${input.length > 4500 ? "warn" : ""}`}>
            {input.length} / 5000
          </div>
        </div>
        {/* ── Quick Example Chips ── */}
        <div className="example-chips-row">
          <span className="chips-label">Try:</span>
          {[
            { text: "hi what is your name", s: "eng", t: "tam", label: "English: What is your name" },
            { text: "வணக்கம், எப்படி இருக்கிறீர்கள்?", s: "tam", t: "eng", label: "Tamil (Native Script)" },
            { text: "vanakkam ungal peyar enna", s: "auto", t: "eng", label: "Tanglish (English communication)" },
            { text: "namaskaram mee peru enti", s: "auto", t: "eng", label: "Tenglish (Telugu in English)" },
            { text: "hegiddira", s: "auto", t: "eng", label: "Kanglish (Kannada in English)" },
            { text: "sukhamano", s: "auto", t: "eng", label: "Manglish (Malayalam in English)" },
          ].map((chip, idx) => (
            <button
              key={idx}
              type="button"
              className="chip-btn"
              onClick={() => {
                setInput(chip.text);
                setSrc(chip.s);
                setTgt(chip.t);
              }}
              title={chip.label}
            >
              {chip.text}
            </button>
          ))}
        </div>

        {note && (
          <div className="alert alert-note">
            <span className="alert-icon">ℹ️</span> {note}
          </div>
        )}
      </div>

      {/* ── Translate Button ── */}
      <button
        className="translate-btn"
        onClick={doTranslate}
        disabled={!input.trim() || !!busy}
      >
        {busy
          ? <><div className="btn-spinner" /> {busy}</>
          : <>✦ Translate</>
        }
      </button>

      {/* ── Error ── */}
      {error && (
        <div className="alert alert-error" role="alert">
          <span className="alert-icon">⚠️</span> {error}
        </div>
      )}

      {/* ── Results ── */}
      {result && (
        <ErrorBoundary>
          <div className="results-section">
            {/* Translation Card */}
            <div className="glass-card translation-card">
              <div className="card-header">
                <div className="card-lang-label">
                  {tgtLang?.flag} {tgtLang?.name} · {tgtLang?.label}
                  {result.detected_confidence >= 0.95 && (
                    <span className="precision-pill">✓ 100% Verified Precision</span>
                  )}
                </div>
                <div className="card-actions">
                  <button
                    className={`icon-btn ${audioPlaying ? "playing-pulse" : ""}`}
                    onClick={() => doSpeak(result.translation, tgt)}
                    disabled={!!busy}
                    aria-label="Text to speech"
                    title="Listen to Studio Neural AI Voice"
                  >
                    {audioPlaying ? "🔊 Playing AI Voice…" : "🔊"}
                  </button>
                  <button className="icon-btn" onClick={copy} aria-label="Copy translation" title="Copy">
                    {copied ? "✓" : "⧉"}
                  </button>
                </div>
              </div>

              {/* Original Dravidian Script Form (if romanized input was provided) */}
              {result.original_script && (
                <div className="original-script-box">
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span className="form-tag">Original Native Script</span>
                    <button
                      type="button"
                      className="icon-btn"
                      style={{ fontSize: "0.82rem", padding: "3px 8px" }}
                      onClick={() => doSpeak(result.original_script, result.src)}
                      title="Listen to original script"
                    >
                      🔊 Listen
                    </button>
                  </div>
                  <span className="original-script-text">{result.original_script}</span>
                </div>
              )}

              {/* Translation Output */}
              <div className="translation-text" lang={tgt}>{result.translation}</div>

              {/* English Communicative Version (Romanization / Tanglish / Tenglish etc.) */}
              {result.romanization && (
                <div className="romanization-box">
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span className="form-tag">
                      🗣️ English Communicative Form ({tgt === "tam" ? "Tanglish" : tgt === "tel" ? "Tenglish" : tgt === "kan" ? "Kanglish" : tgt === "mal" ? "Manglish" : "Romanized"})
                    </span>
                    <button
                      type="button"
                      className="icon-btn"
                      style={{ fontSize: "0.82rem", padding: "3px 8px" }}
                      onClick={() => doSpeak(result.romanization, "eng")}
                      title="Listen to Romanized pronunciation"
                    >
                      🔊 Pronounce
                    </button>
                  </div>
                  <div className="romanization-text">{result.romanization}</div>
                </div>
              )}

              {/* Detected language & communicative form hints */}
              <div className="card-footer-meta">
                {result.src && (
                  <div className="detected-lang">
                    Source: <span>{getLangByCode(result.src)?.name ?? result.src}</span>
                  </div>
                )}
                {result.warning && (
                  <div className="result-warning-pill">
                    💡 {result.warning}
                  </div>
                )}
              </div>
            </div>

            {/* Dual Morphological Analysis */}
            <MorphAnalysisPanel
              srcMorph={srcMorph}
              tgtMorph={tgtMorph}
              srcText={result.original_script || input}
              tgtText={result.translation}
              srcLang={srcLang}
              tgtLang={tgtLang}
              loading={morphBusy}
            />

            {/* Language Info Panel */}
            <LangInfoPanel langCode={morphLangForDisplay !== "auto" ? morphLangForDisplay : "tam"} />
          </div>
        </ErrorBoundary>
      )}

      {/* Hidden audio element for TTS */}
      <audio ref={audioRef} hidden />

      {/* Copy toast */}
      <div className={`copy-toast ${copied ? "show" : ""}`}>✓ Copied to clipboard</div>
    </div>
  );
}
