import { blobToWav } from "./wav.js";
// Thin API client. Every call throws Error(message) with the server's detail text.
async function handle(res) {
  if (res.ok) return res;
  let detail = `Request failed (${res.status})`;
  try {
    const body = await res.json();
    if (body.detail) detail = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
  } catch {}
  throw new Error(detail);
}

export async function translate(text, src, tgt) {
  const res = await handle(
    await fetch("/api/translate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, src, tgt }),
    })
  );
  return res.json();
}

export async function transcribe(blob, lang) {
  const form = new FormData();
  // Prefer a 16 kHz WAV made in the browser: the server then needs no ffmpeg to read it.
  const wav = await blobToWav(blob);
  if (wav) form.append("file", wav, "speech.wav");
  else form.append("file", blob, "speech.webm");
  form.append("lang", lang);
  return (await handle(await fetch("/api/asr", { method: "POST", body: form }))).json();
}

export async function ocr(file, lang) {
  const form = new FormData();
  form.append("file", file);
  form.append("lang", lang);
  return (await handle(await fetch("/api/ocr", { method: "POST", body: form }))).json();
}

export async function speak(text, lang) {
  const res = await handle(
    await fetch("/api/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, lang }),
    })
  );
  return URL.createObjectURL(await res.blob());
}

export async function morph(text, lang) {
  const res = await handle(
    await fetch("/api/morph", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, lang }),
    })
  );
  return res.json();
}

export async function getDatasetStats() {
  const res = await handle(await fetch("/api/dataset/stats"));
  return res.json();
}

export async function trainDataset(src_text, src_lang, tgt_text, tgt_lang, romanization) {
  const res = await handle(
    await fetch("/api/dataset/train", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ src_text, src_lang, tgt_text, tgt_lang, romanization }),
    })
  );
  return res.json();
}
